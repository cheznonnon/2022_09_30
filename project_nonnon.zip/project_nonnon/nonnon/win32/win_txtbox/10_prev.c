// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_previous_calc( n_win_txtbox *p, n_type_int *ret__y, n_type_int *ret_sy )
{

	// [!] : this modulue is used for cascading like carrage-return


	// [!] : Slow Mode

	n_type_int  y = N_WIN_TXTBOX_NOT_SELECTED;
	n_type_int sy = N_WIN_TXTBOX_NOT_SELECTED;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_txt_sy, p->txt.sy );

	if ( p->prv_txt_sy > p->txt.sy )
	{
		//
	} else
	if (
		( p->prv_sel_y == p->select_cch_y )
		&&
		( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
	)
	{
		 y = p->select_cch_y;
		sy = 1;
	}


	if ( ret__y != NULL ) { (*ret__y) =  y; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}

void
n_win_txtbox_previous_calc_selected( n_win_txtbox *p, n_type_int *ret__y, n_type_int *ret_sy )
{

	// [!] : Slow Mode

	n_type_int  y = N_WIN_TXTBOX_NOT_SELECTED;
	n_type_int sy = N_WIN_TXTBOX_NOT_SELECTED;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_txt_sy, p->txt.sy );

	if ( p->prv_txt_sy > p->txt.sy )
	{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );

		//
	} else
	if (
		( p->prv_sel_y == p->select_cch_y )
		&&
		( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
	)
	{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );

		 y = p->select_cch_y;
		sy = 1;
	} else {
//n_win_txtbox_hwndprintf_literal( p, " 3 " );

		n_type_int fy = n_posix_min_n_type_int( p->prv_sel_y, p->select_cch_y );
		n_type_int ty = n_posix_min_n_type_int( p->prv_sel_y + p->prv_sel_sy, p->select_cch_y + p->select_cch_sy );

		 y = fy;
		sy = ty - fy + 1;
	}


	if ( ret__y != NULL ) { (*ret__y) =  y; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}



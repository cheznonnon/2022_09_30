// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_WIN_TXTBOX_NAMESPACE              n_posix_literal( "TxtBox" )
#define N_WIN_TXTBOX_NAMESPACE_FOCUS        n_posix_literal( "TxtBox.Focus" )

#define N_WIN_TXTBOX_ALL                    ( -1 )
#define N_WIN_TXTBOX_NOT_SELECTED           ( -1 )

#define N_WIN_TXTBOX_MENU_NONE              ( 0 )
#define N_WIN_TXTBOX_MENU_MAIN              ( 1 )
#define N_WIN_TXTBOX_MENU_LINE              ( 2 )

#define N_WIN_TXTBOX_SMALLBUTTON_MAX        ( 8 )

#define N_WIN_TXTBOX_OPTIMIZATION_NONE      ( 0 )
#define N_WIN_TXTBOX_OPTIMIZATION_SCROLL    ( 1 )
#define N_WIN_TXTBOX_OPTIMIZATION_SHIFT     ( 2 )
#define N_WIN_TXTBOX_OPTIMIZATION_DRAG      ( 3 )
#define N_WIN_TXTBOX_OPTIMIZATION_TYPING    ( 4 )
#define N_WIN_TXTBOX_OPTIMIZATION_CLICK     ( 5 )
#define N_WIN_TXTBOX_OPTIMIZATION_CARET     ( 6 )
#define N_WIN_TXTBOX_OPTIMIZATION_OTHERS    ( 7 )

#define N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE ( 0 )
#define N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL  ( 1 )
#define N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART ( 2 )

#define N_WIN_TXTBOX_DRAG_PHASE_NEUTRAL     ( 0 )
#define N_WIN_TXTBOX_DRAG_PHASE_CLICKED     ( 1 )
#define N_WIN_TXTBOX_DRAG_PHASE_STARTED     ( 2 )

#define N_WIN_TXTBOX_CARET_OUTBOUND_NONE    ( 0 )
#define N_WIN_TXTBOX_CARET_OUTBOUND_LEFT    ( 1 )
#define N_WIN_TXTBOX_CARET_OUTBOUND_RIGHT   ( 2 )


#define N_WIN_TXTBOX_STYLE_LISTBOX          ( 1 <<  0 )
#define N_WIN_TXTBOX_STYLE_ONELINE          ( 1 <<  1 )
#define N_WIN_TXTBOX_STYLE_EDITBOX          ( 1 <<  2 )
#define N_WIN_TXTBOX_STYLE_CMB_BOX          ( 1 <<  3 )
#define N_WIN_TXTBOX_STYLE_CMB_POP          ( 1 <<  4 )
#define N_WIN_TXTBOX_STYLE_HSCROLL          ( 1 <<  5 )
#define N_WIN_TXTBOX_STYLE_VSCROLL          ( 1 <<  6 )
#define N_WIN_TXTBOX_STYLE_NO_BRDR          ( 1 <<  7 )
#define N_WIN_TXTBOX_STYLE_NO_PDNG          ( 1 <<  8 )
#define N_WIN_TXTBOX_STYLE_STRIPED          ( 1 <<  9 )
#define N_WIN_TXTBOX_STYLE_VISIBLE          ( 1 << 10 )
#define N_WIN_TXTBOX_STYLE_TRANSBG          ( 1 << 11 )
#define N_WIN_TXTBOX_STYLE_LINEBDR          ( 1 << 12 )
#define N_WIN_TXTBOX_STYLE_FLATBDR          ( 1 << 13 )

#define N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS ( 1 <<  0 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL ( 1 <<  1 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL ( 1 <<  2 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC ( 1 <<  3 )
#define N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ( 1 <<  4 )
#define N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ( 1 <<  5 )
#define N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ( 1 <<  6 )
#define N_WIN_TXTBOX_OPTION_ONELINE_GRAY_ON ( 1 <<  7 )
#define N_WIN_TXTBOX_OPTION_ONELINE_ROUNDRC ( 1 <<  8 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ( 1 <<  9 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM ( 1 << 10 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET ( 1 << 11 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ( 1 << 12 )
#define N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ( 1 << 13 )
#define N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ( 1 << 14 )
#define N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX ( 1 << 15 )
#define N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF ( 1 << 16 )
#define N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY ( 1 << 17 )
#define N_WIN_TXTBOX_OPTION_STRICT_FOCUS_ON ( 1 << 18 )
#define N_WIN_TXTBOX_OPTION_DELAYEDFOCUS_ON ( 1 << 19 )
#define N_WIN_TXTBOX_OPTION_AUTO_FOCUS_RECT ( 1 << 20 )
#define N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON ( 1 << 21 )
#define N_WIN_TXTBOX_OPTION_COMBOBOX_SHADOW ( 1 << 22 )
#define N_WIN_TXTBOX_OPTION_PARENT_BACKGRND ( 1 << 23 )
#define N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE ( 1 << 24 )
#define N_WIN_TXTBOX_OPTION_ONELINE_RESIZER ( 1 << 25 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_KEYDOWN ( 1 << 26 )




typedef struct {

	// Instance : you can control via methods

	HWND    hwnd;
	WNDPROC pfunc;
	n_txt   txt, txt_undo;
	int     style, style_option;

	HBITMAP hbmp;
	n_bmp    bmp;
	n_bmp    bmp_oneline;
	n_bmp    bmp_desktop;
	n_bmp    bmp_roundfr;
	n_bmp    bmp_linebuf;
	n_bmp   *bmp_backbuffer;

	n_bmp    bmp_linenumber[ 10 ];

	n_posix_bool  cache_init_done;
	int           cache_limit;
	n_bmp        *cache_bmp_main;
	n_bmp        *cache_bmp_strp;
	n_bmp        *cache_bmp_hilt;
	n_bmp        *cache_bmp_gray;


	n_win_scrollbar vscr, hscr;

	n_type_int scroll_pxl_tabbed_x;
	n_type_int scroll_pxl_tabbed_y;
	n_type_int scroll_undo_pxl_tabbed_x;
	n_type_int scroll_undo_pxl_tabbed_y;
	n_type_int select_cch_x, select_cch_y, select_cch_sx, select_cch_sy;
	n_type_int   undo_cch_x,   undo_cch_y,   undo_cch_sx,   undo_cch_sy;
	n_type_gfx offset_pxl_y;

	n_posix_bool partial_selection_from_onoff, partial_selection_to___onoff;
	n_type_int   partial_selection_from_cch_x, partial_selection_to___cch_x;

	n_posix_bool undo_onoff;
	n_posix_bool undo_partial_selection_from_onoff, undo_partial_selection_to___onoff;
	n_type_int   undo_partial_selection_from_cch_x, undo_partial_selection_to___cch_x;

	n_posix_bool              smallbutton_is_used;
	n_win_smallbutton_direct *smallbutton[ N_WIN_TXTBOX_SMALLBUTTON_MAX ];
	n_type_gfx                smallbutton_margin;
	UINT                      smallbutton_timer;
	n_posix_bool              smallbutton_once;

	n_posix_bool listbox_is_selected;
	n_posix_bool oneline_placeholder_onoff;

	n_posix_bool grayed_onoff;
	n_posix_bool is_grayed;

	n_posix_bool metrics_changed;


	// Optional

	n_posix_char *placeholder;
	n_posix_char *tab_mark;
	n_posix_char *eol_mark;

	n_type_gfx    tabstop;

	n_posix_bool  mouse_input_stop_onoff;

	WNDPROC       scroll_callback;

	int           scrollbar_option;


	// Internal : auto-filled by the system

	HDC         hdc_printclient;
	POINT       ime, ime_prv;
	int         ime_outbound;
	int         vk_mouse;
	int         vk_key;
	n_type_gfx  scale;
	n_type_real scale_real;
	n_type_int      hover_cch_x,  hover_cch_y ;
	n_type_int      hover_under;
	n_type_gfx      font_pxl_sx,   font_pxl_sy;
	n_type_gfx                     cell_pxl_sy;
	n_type_gfx     caret_pxl_x ,  caret_pxl_y ;
	n_type_gfx     caret_pxl_sx,  caret_pxl_sy;
	n_type_gfx    canvas_pxl_sx, canvas_pxl_sy;
	n_type_gfx  canvas_real_pxl_sx;
	n_type_gfx  page_pxl_tabbed_sx;
	n_type_int  page_pxl_tabbed_sy;
	n_type_gfx  last_pxl_tabbed_sx;
	n_type_int  last_pxl_tabbed_sy;
	n_type_gfx  virtual_padding_pxl_sx;
	n_type_gfx  roundrect_pxl;
	n_type_gfx  shadow_u, shadow_d, shadow_l, shadow_r;
	n_type_gfx  corner_pxl_ox, corner_pxl_osx;

	n_type_int txt_maxwidth_y;

	n_posix_bool is_captured;
	n_posix_bool is_dragging;
	n_posix_bool is_caret_tail;
	n_posix_bool is_hovered_linenum;

	n_type_int   empty_line_selection;

	n_posix_bool is_carrage_return;
	n_type_int   carrage_return_cch_y;

	n_posix_bool is_backspace;
	n_type_int   backspace_cch_y;

	int          is_lr;
	n_posix_bool is_ud;

	n_posix_bool is_font_monospace;
	SIZE         size_halfwidth;
	SIZE         size_fullwidth;

	n_type_int   prv_scr_x,  prv_scr_y;
	n_type_int   prv_sel_x,  prv_sel_y;
	n_type_int   prv_sel_sx, prv_sel_sy;
	n_type_int   prv_txt_sy;
	n_type_int   prv_drag;
	n_type_int   prv_caret_x, prv_caret_y;
	n_type_int   prv_oneline_scroll;

	n_win_simplemenu menu_editbox;
	n_win_simplemenu menu_linenum;
	n_posix_bool     menu_onoff;
	n_posix_bool     menu_delay;
	int              menu_type;

	n_uxtheme    uxtheme;

	int          drag_phase;
	UINT         drag_timer;
	DWORD        drag_msec;
	n_type_int   drag_cch_min;
	n_type_int   drag_cch_max;
	n_type_int   drag_cch_x;
	n_type_int   drag_cch_y;
	POINT        drag_pt;

	n_posix_bool global_fade_onoff;

	n_posix_bool ime_onoff;
	n_posix_bool ime_composition_onoff;

	UINT         ime_fade_timer;
	n_bmp        ime_fade_bmp_old;
	n_bmp        ime_fade_bmp_new;
	n_posix_bool ime_fade_is_running;
	n_type_real  ime_fade_percent;

	UINT         focus_fade_timer;
	n_bmp        focus_fade_bmp_old;
	n_bmp        focus_fade_bmp_new;
	n_type_int   focus_fade_prv_sel_sx;
	n_type_real  focus_fade_percent;
	n_posix_bool focus_fade_is_running;
	n_posix_bool focus_fade_is_set_prv;

	UINT         caret_timer;
	n_type_real  caret_blend;
	n_posix_bool caret_fade_in;
	n_type_gfx   caret_redraw_x;
	n_type_gfx   caret_redraw_sx;
	n_posix_bool caret_blend_override_onoff;
	n_type_real  caret_blend_override_value;

	n_posix_bool input_onoff;
	UINT         input_timer;
	DWORD        input_msec;

	n_posix_bool aero_combo_onoff;
	UINT         aero_combo_timer;
	n_bmp_fade   aero_combo_fade;
	n_posix_bool aero_combo_fade_in;
	n_posix_bool aero_combo_init;
	n_posix_bool aero_combo_focus_only;

	n_type_real  text_fade_ratio;

	n_posix_bool bitblt_stop;

	n_posix_bool typing_only;

	n_type_int   shift_dragging;
	n_type_int   shift_dragging_start_x;
	n_type_int   shift_dragging_start_pxl_x;
	n_type_int   shift_dragging_last_left;

	n_posix_bool optimization_click_onoff;
	n_posix_bool optimization_caret_onoff;

	n_posix_bool delayed_focus;

	n_posix_bool selection_onoff;
	RECT         selection_rect;

	n_posix_bool selected_border_onoff;

	n_posix_bool combo_popup_slide_onoff;
	n_posix_bool combo_popup_slide_no_scroll;
	n_type_gfx   combo_popup_slide_parameter;
	n_type_gfx   combo_popup_slide_index;

	n_posix_bool input_resizer_onoff;
	UINT         input_resizer_timer_id;
	n_type_gfx   input_resizer_cursor_x_prv;
	n_type_gfx   input_resizer_icon_sx;
	n_type_gfx   input_resizer_max;

	RECT         highlight_rect;

	n_posix_bool line_buffer_make_onoff;
	n_type_gfx   line_buffer_pxl_sy;

	n_posix_bool dibsection_stop_onoff;

	n_win_grab_n_drag grab_n_drag;

	n_type_gfx   maclike_offset;


	// Metrics : once per session

	n_posix_bool is_9x;
	n_posix_bool is_nt;
	n_posix_bool is_2k_or_later;
	n_posix_bool is_classic;

	n_type_gfx    number_pxl_sx, number_pad_pxl_sx, number_offset;
	n_type_gfx    client_pxl_sx,     client_pxl_sy;
	n_type_gfx    client_prv_sx,     client_prv_sy;
	n_type_gfx    border_pxl_sx,     border_pxl_sy;
	n_type_gfx       pad_pxl_sx,        pad_pxl_sy;
	n_type_gfx scrollbar_pxl_sx,  scrollbar_pxl_sy;

	COLORREF color_base__padding;
	COLORREF color_base_selected;
	COLORREF color_back_selected;
	COLORREF color_text_selected;
	COLORREF color_back_noselect;
	COLORREF color_text_noselect;
	COLORREF color_back_striping;
	COLORREF color_text_tab_mark;
	COLORREF color_text_eol_mark;
	COLORREF color_text_backgrnd;
	COLORREF color_back_linenum1;
	COLORREF color_back_linenum2;
	COLORREF color_back_linenum3;
	COLORREF color_text_linenum1;
	COLORREF color_text_linenum2;
	COLORREF color___placeholder;
	COLORREF color___dwm_contour;
	COLORREF color___dwm_textclr;
	COLORREF color___ime_watcher;
	COLORREF color_sel_focus__on;
	COLORREF color_sel_focus_off;
	COLORREF color_back_disabled;
	COLORREF color_back__enabled;
	COLORREF color_border_normal;
	COLORREF color_border__focus;
	COLORREF color_border___flat;
	UINT     drawtext_modes;


	// Debug Center

	n_posix_bool  optimization_onoff;
	n_posix_bool  optimization_stop;
	int           optimization_type;
	int           optimization_sync;

	n_posix_bool  debug_onoff;
	n_bmp        *debug_bmp;

	n_posix_bool  debug_draw_onoff;

} n_win_txtbox;

#define n_win_txtbox_zero( p ) n_memory_zero( p, sizeof( n_win_txtbox ) )


static n_posix_bool n_win_txtbox_printclient = n_posix_false;



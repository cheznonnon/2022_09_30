// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@implementation NonnonTxtbox (NonnonTxtboxMouse)


- (n_caret) n_detect_cursor
{

	NSPoint local_point = n_mac_cursor_position_get( self );

	n_focus = trunc( scroll + trunc( ( local_point.y - offset ) / font_size.height ) );
	if ( n_focus >= n_txt->sy ) { n_focus = n_txt->sy - 1; }
//NSLog( @"%f", n_focus );

	NSRect r = NSMakeRect( padding - font_size.width, offset, [self frame].size.width - ( offset * 2 ), font_size.height );

	n_caret caret = n_txtbox_caret_detect_pixel2caret
	(
		n_txt,
		n_focus,
		r,
		font,
		font_size,
		local_point
	);

	caret = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		caret.cch.x
	);


	return caret;
}




- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );

	thumb_is_captured = FALSE;

	if ( thumb_is_hovered ) { return; }
	if ( shaft_is_hovered ) { return; }

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	pt               = [NSEvent mouseLocation];
	thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_thumb );
	shaft_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_shaft );
//if ( thumb_is_hovered ) { NSLog( @"!" ); }

	NSPoint pt_cur   = n_mac_cursor_position_get( self );
	thumb_offset     = scroller_rect_thumb.origin.y - pt_cur.y;
//NSLog( @"%f : %f %f", thumb_offset, scroller_rect_thumb.origin.y, pt_cur.y );

	if ( thumb_is_hovered )
	{
		thumb_is_captured = TRUE;
	} else
	if ( shaft_is_hovered )
	{

		CGFloat sy               = [self frame].size.height;
		CGFloat csy              = sy - ( offset * 2 );
		CGFloat items_per_canvas = csy / font_size.height;

		if ( pt_cur.y < scroller_rect_thumb.origin.y )
		{
//NSLog( @"upper" );
			scroll -= items_per_canvas;
		} else {
//NSLog( @"lower" );
			scroll += items_per_canvas;
		}

		[self display];

	} else {

		if ( [theEvent clickCount] == 3 )
		{
			[self n_detect_tripleclick];
		} else
		if ( [theEvent clickCount] == 2 )
		{
			[self n_detect_doubleclick];
		} else {
			caret_fr = caret_to = [self n_detect_cursor];
		}

		thumb_is_hovered = n_posix_false;

		[self display];

	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog( @"mouseDragged" );

	CGPoint pt_cur = [NSEvent mouseLocation];

	CGFloat dy = pt.y - pt_cur.y;
//NSLog( @"%f %f", dy, [theEvent deltaY] );

	pt = pt_cur;

//scroll -= dy / font_size.height;

	if ( thumb_is_captured )
	{
//NSLog( @"1" ); 
		CGFloat max_count  = (CGFloat) n_txt->sy;
		CGFloat correction = client_sy / ( max_count * font_size.height );

		scroll += dy / ( font_size.height * correction );

	} else {

		if ( thumb_is_hovered ) { return; }
		if ( shaft_is_hovered ) { return; }

//NSLog( @"%lld", caret_fr.cch.y );
		caret_to = [self n_detect_cursor];
//NSLog( @"%@", n_mac_txtbox_copy( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y ) );

		if ( caret_fr.cch.x < caret_to.cch.x )
		{
			shift_selection_is_tail = TRUE;
		} else {
			shift_selection_is_tail = FALSE;
		}

		thumb_is_hovered = n_posix_false;

		[self display];

	}


	[self display];

}

- (void)scrollWheel:(NSEvent *)theEvent
{
//NSLog( @"%lu : %0.2f %0.2f", [theEvent phase], [theEvent deltaY], [theEvent scrollingDeltaY] );

	if ( thumb_is_hovered ) { return; }
	if ( shaft_is_hovered ) { return; }


//NSLog( @"%f", [theEvent scrollingDeltaY] );
//return;

	const CGFloat boost = 2;

	CGFloat delta = [theEvent scrollingDeltaY] / font_size.height;
	if ( delta < 0 )
	{
		delta = delta * boost;
	} else {
		delta = delta * boost;
	}

	scroll -= delta;
//NSLog( @"%f", scroll );

	[self display];

}



- (void) otherMouseUp:(NSEvent*) theEvent
{
//NSLog( @"otherMouseUp : %ld", (long) [theEvent buttonNumber] );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		[[NSCursor arrowCursor] set];

	}

}

- (void) otherMouseDown:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDown : %ld", (long) [theEvent buttonNumber] );

	// [!] : Grab N Drag

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		pt             = [NSEvent mouseLocation];
		pt_grag_n_drag = [theEvent locationInWindow];

		[[NSCursor closedHandCursor] set];

	}

}

- (void) otherMouseDragged:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDragged" );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		CGPoint pt_cur = [NSEvent mouseLocation];

		CGFloat dy = pt.y - pt_cur.y;
//NSLog( @"%f %f", dy, [theEvent deltaY] );

		pt = pt_cur;


		const CGFloat axl = 2;

		scroll -= dy / font_size.height * axl;


		[self display];

	}

}


@end


// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonTxtbox
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonTxtbox"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_txtbox display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_TXTBOX
#define _H_NONNON_MAC_NONNON_TXTBOX




#import <Cocoa/Cocoa.h>


#include "../neutral/bmp/ui/rectframe.c"
#include "../neutral/bmp/ui/roundframe.c"

#include "../neutral/txt.c"

#include "../game/helper.c"


#include "_mac.c"
#include "draw.c"
#include "image.c"
#include "window.c"


#include "n_txtbox/00_codec.c"
#include "n_txtbox/01_character.c"
#include "n_txtbox/02_caret.c"
#include "n_txtbox/03_selection.c"
#include "n_txtbox/04_edit.c"
#include "n_txtbox/05_date.c"
#include "n_txtbox/06_undo.c"




#define N_TXTBOX_IME_ENABLE




#define N_MAC_TXTBOX_DRAW_LINENUMBER_NONE            ( 0 << 0 )
#define N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX ( 1 << 0 )

// internal
void
n_mac_txtbox_draw_linenumber
(
	      NSFont *font,
	  n_type_int  index,
	  n_type_int  offset,
	  n_type_int  txt_sy,
	  n_type_int  focus_f,
	  n_type_int  focus_t,
	  n_type_gfx   x,
	  n_type_gfx   y,
	  n_type_gfx  sx,
	  n_type_gfx  sy,
	     NSColor *color_back,
	     NSColor *color_text,
	         int  option
)
{
//return;

	n_type_int cch_y = index + offset;

	if ( option & N_MAC_TXTBOX_DRAW_LINENUMBER_ZEROBASED_INDEX )
	{
		//
	} else {
		cch_y++;
	}

	n_posix_bool over_ten_thousand = n_posix_false;
	if ( cch_y >= 10000 ) { over_ten_thousand = n_posix_true; }

	if ( cch_y >= 10000 ) { cch_y = cch_y % 10000; }

	//n_posix_char str[ 6 + 1 ];
	NSString *nsstr;

	// [Patch] : not working accurately

	if ( cch_y < 1000 )
	{
		if ( over_ten_thousand )
		{
			//n_posix_sprintf_literal( str, " %04d ", (int) cch_y );
			nsstr = [[NSString alloc] initWithFormat:@" %04d ", (int) cch_y];
		} else {
			//n_posix_sprintf_literal( str, " % 4d ", (int) cch_y );
			nsstr = [[NSString alloc] initWithFormat:@" % 4d ", (int) cch_y];
		}
	} else {
		//n_posix_sprintf_literal( str, " %d "  , (int) cch_y );
		nsstr = [[NSString alloc] initWithFormat:@" %d ", (int) cch_y];
	}


	NSColor *color_stripe;
	if ( ( index + offset ) & 1 )
	{
		color_stripe = [color_text blendedColorWithFraction:0.90 ofColor:color_back];
	} else {
		color_stripe = [color_text blendedColorWithFraction:0.95 ofColor:color_back];
	}

	NSRect rect = NSMakeRect( x,y,sx,sy );

	n_mac_draw_box( color_stripe, rect );

	if ( ( index + offset ) < txt_sy )
	{

		NSColor *color_txt;
		if ( ( ( index + offset ) >= focus_f )&&( ( index + offset ) <= focus_t ) )
		{
			// [!] : indicator

			n_type_gfx size = 2;

			NSRect r = NSMakeRect( x,y,size,sy );

			n_mac_draw_box( [NSColor controlAccentColor], r );

			color_txt = [color_text blendedColorWithFraction:0.33 ofColor:color_back];
		} else {
			color_txt = [color_text blendedColorWithFraction:0.66 ofColor:color_back];
		}


		NSMutableDictionary *attr = [NSMutableDictionary dictionary];
		[attr setObject:font      forKey:NSFontAttributeName           ];
		[attr setObject:color_txt forKey:NSForegroundColorAttributeName];

		[nsstr drawInRect:rect withAttributes:attr];

	}


	return;
}




@protocol NonnonTxtbox_delegate

- (void) NonnonTxtbox_delegate_edited : (BOOL) onoff;
- (void) NonnonTxtbox_delegate_dropped;
- (void) NonnonTxtbox_delegate_find;

@optional

- (void) NonnonTxtbox_delegate_listbox_edited : (n_type_int) i;

@end




#ifdef N_TXTBOX_IME_ENABLE
@interface NonnonTxtbox : NSView <NSTextInputClient>
#else
@interface NonnonTxtbox : NSView
#endif

@property (nonatomic,assign) id delegate;

@end


@interface NonnonTxtbox ()

@property CGFloat   n_focus;
@property n_txt    *n_txt_data;
@property NSString *n_path;
@property BOOL      n_edited;
@property NSString *n_query;
@property int       n_option_linenumber;
@property BOOL      n_listbox_onoff;
@property BOOL      n_listbox_edit_onoff;
@property BOOL      n_decoration_onoff;

@end


@implementation NonnonTxtbox {

	n_bmp       canvas;
	NSFont     *font;
	CGSize      font_size;
	CGFloat     scroll;
	CGPoint     pt;
	CGPoint     pt_grag_n_drag;
	NSRect      scroller_rect_thumb;
	NSRect      scroller_rect_shaft;
	CGFloat     offset;
	CGFloat     margin;
	CGFloat     padding;
	BOOL        thumb_is_captured;
	BOOL        thumb_is_hovered;
	BOOL        shaft_is_hovered;
	CGFloat     thumb_offset;
	n_bmp_fade  fade;
	CGFloat     client_sy;
	n_type_int  redraw_fy;
	n_type_int  redraw_ty;

	NSFont     *linenumber_font;
	CGSize      linenumber_size;
	u32         linenumber_color_back;
	u32         linenumber_color_text;

	CGPoint     caret_pt;
	n_caret     caret_fr;
	n_caret     caret_to;
	BOOL        caret_blink_onoff;
	BOOL        caret_blink_force_onoff;
	n_bmp_fade  caret_blink_fade;

	BOOL        shift_selection_is_tail;

	n_undo      undo;
	n_undo      undo_tmp;
	BOOL        undo_timer_queue;
	u32         undo_timer;

#ifdef N_TXTBOX_IME_ENABLE

	NSTextInputContext *ime;
	n_caret             ime_caret_fr;
	n_caret             ime_caret_to;
	NSString           *ime_nsstr;
	BOOL                ime_onoff;
	BOOL                ime_freed;
	NSRange             ime_focus;
	
#endif

}




@synthesize delegate;

@synthesize n_focus;
@synthesize n_txt_data;
@synthesize n_path;
@synthesize n_edited;
@synthesize n_query;
@synthesize n_option_linenumber;
@synthesize n_listbox_onoff;
@synthesize n_listbox_edit_onoff;
@synthesize n_decoration_onoff;




- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{

		n_bmp_safemode = n_posix_false;

		n_bmp_transparent_onoff_default = n_posix_false;


		{
			NSArray      *paths   = NSSearchPathForDirectoriesInDomains( NSDesktopDirectory, NSUserDomainMask, YES );
			NSString     *desktop = [paths objectAtIndex:0];
			n_posix_char  tmpname[ 100 ]; n_string_path_tmpname( tmpname );

	    		n_path = [NSString stringWithFormat:@"%@/%s.txt", desktop, tmpname];
//NSLog( @"%@", path );
		}


		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];


		// [x] : monospacedSystemFontOfSize : CJK unified idiogram
		//
		//	non-japanese glyphs will be used

		//font      = [NSFont monospacedSystemFontOfSize:15 weight:NSFontWeightRegular];
		font      = [NSFont userFixedPitchFontOfSize:15];
		//font      = [NSFont systemFontOfSize:15 weight:NSFontWeightRegular];
		//font      = [NSFont fontWithName:@"Menlo" size:15];

		font_size = n_mac_image_text_pixelsize( @" ", font );

		linenumber_font = [NSFont userFixedPitchFontOfSize:14];
		linenumber_size = n_mac_image_text_pixelsize( @"000000", font );

		offset    = 6;
		margin    = 3;
		padding   = offset + linenumber_size.width + margin;

		[self n_reset];

		n_bmp_fade_init( &fade, n_bmp_black );

		//n_undo_zero( &undo );
		//n_txt_zero( &undo.txt ); n_txt_utf8_new( &undo.txt );

		n_edited = FALSE;

		n_mac_timer_init( self, @selector( n_undo_timer        ), 500 );
		n_mac_timer_init( self, @selector( n_scroll_timer      ),  33 );
		n_mac_timer_init( self, @selector( n_caret_blink_timer ),  33 );

	}
	
	return self;
}




- (void) n_font_change:(NSFont*)font_new
{

	font = font_new;

}




- (void) n_reset
{

	scroll  = 0;
	n_focus = 0;

	scroller_rect_thumb = NSMakeRect( 0,0,0,0 );
	scroller_rect_shaft = NSMakeRect( 0,0,0,0 );

	thumb_is_hovered = FALSE;


	caret_pt = NSMakePoint( 0, 0 );

	caret_fr = NonnonMakeCaret( 0,0,0,0 );
	caret_to = NonnonMakeCaret( 0,0,0,0 );

	caret_blink_onoff       = TRUE;
	caret_blink_force_onoff = FALSE;

	n_bmp_fade_init( &caret_blink_fade, n_bmp_black );

	shift_selection_is_tail = TRUE;

#ifdef N_TXTBOX_IME_ENABLE

	ime_caret_fr = caret_fr;
	ime_caret_to = caret_to;

	ime_freed = FALSE;

#endif


	undo_timer_queue = FALSE;
	undo_timer       = n_posix_tickcount();

	n_edited = FALSE;
	[self.delegate NonnonTxtbox_delegate_edited:n_edited];


	redraw_fy = -1;
	redraw_ty = -1;

}

- (void) n_focus2caret
{

	n_posix_char *line = n_txt_get( n_txt_data, n_focus );
	n_type_int    cch  = n_posix_strlen( line );

	caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
	(
		n_txt_data,
		n_focus,
		font,
		font_size,
		cch
	);

}




- (void) n_scroll_timer
{

	if ( thumb_is_captured ) { return; }


	static BOOL prv = FALSE;

	thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, scroller_rect_thumb );

	if ( thumb_is_hovered != prv )
	{
//[self display];
		if ( thumb_is_hovered )
		{
			n_bmp_fade_go( &fade, n_bmp_white );
		} else {
			n_bmp_fade_go( &fade, n_bmp_black );
		}
	}

	n_bmp_fade_engine( &fade, n_posix_true );
//NSLog( @"%d", fade.percent );
	if ( fade.stop == n_posix_false )
	{
		[self display];
	}

	prv = thumb_is_hovered;

}


- (void) n_undo_timer
{

	if ( undo_timer_queue )
	{
		if ( n_game_timer( &undo_timer, 3000 ) )
		{
//NSLog( @"regsitered" );
			undo_timer_queue = FALSE;
			[self n_undo:N_TXTBOX_UNDO_REGISTER];
		}
	}

}

- (void) n_undo:(int) action
{

	if ( action == N_TXTBOX_UNDO_RESTORE )
	{
		n_txt_copy( &undo.txt, n_txt_data );

		scroll   = undo.scroll;
		n_focus  = undo.focus;
		caret_fr = undo.caret_fr;
		caret_to = undo.caret_to;
	} else
	if ( action == N_TXTBOX_UNDO_SUSPEND )
	{
		n_txt_copy( n_txt_data, &undo_tmp.txt );

		undo_tmp.scroll   = scroll;
		undo_tmp.focus    = n_focus;
		undo_tmp.caret_fr = caret_fr;
		undo_tmp.caret_to = caret_to;

		undo_timer_queue = TRUE;
		undo_timer       = n_posix_tickcount();
	} else
	if ( action == N_TXTBOX_UNDO_REGISTER )
	{
		n_txt_copy( &undo_tmp.txt, &undo.txt );

		undo.scroll   = undo_tmp.scroll;
		undo.focus    = undo_tmp.focus;
		undo.caret_fr = undo_tmp.caret_fr;
		undo.caret_to = undo_tmp.caret_to;
	} else
	if ( action == N_TXTBOX_UNDO_RESET )
	{
		n_txt_copy( n_txt_data, &undo_tmp.txt );

		undo_tmp.scroll   = scroll;
		undo_tmp.focus    = n_focus;
		undo_tmp.caret_fr = caret_fr;
		undo_tmp.caret_to = caret_to;

		n_txt_copy( &undo_tmp.txt, &undo.txt );

		undo.scroll   = undo_tmp.scroll;
		undo.focus    = undo_tmp.focus;
		undo.caret_fr = undo_tmp.caret_fr;
		undo.caret_to = undo_tmp.caret_to;
	}

}

- (void) n_caret_blink_timer
{

	static u32 caret_blink_timer = 0;

	if ( n_game_timer( &caret_blink_timer, 500 ) )
	{
		n_bmp_fade_init( &caret_blink_fade, n_bmp_black );
		if ( caret_blink_onoff )
		{
			n_bmp_fade_go( &caret_blink_fade, n_bmp_white );
			caret_blink_onoff = caret_blink_force_onoff = FALSE;
		} else {
			n_bmp_fade_go( &caret_blink_fade, n_bmp_white );
			caret_blink_onoff =  TRUE;
		}
	}

	n_bmp_fade_engine( &caret_blink_fade, n_posix_true );


	// [x] : partially redraw : too much hard to implement

	//[self display];

	{
//NSLog( @"%lld", caret_to.cch.y );
		redraw_fy = caret_to.cch.y;
		redraw_ty = redraw_fy + 1;

		//[self display];

		CGFloat  x = caret_pt.x;
		CGFloat  y = caret_pt.y;
		CGFloat sx = 1;
		CGFloat sy = font_size.height;
//NSLog( @"%0.2f", caret_to.pxl.y );

		[self displayRect:NSMakeRect( x,y,sx,sy )];
	}

}




- (void) n_detect_tripleclick
{
//NSLog( @"%f", n_focus );


	n_posix_char *line = n_txt_get( n_txt_data, n_focus );
	n_type_int    cch  = n_posix_strlen( line );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		n_txt_data,
		n_focus,
		font,
		font_size,
		cch
	);


	caret_fr = NonnonMakeCaret
	(
		0, n_focus * font_size.height,
		0, n_focus
	);

	caret_to = NonnonMakeCaret
	(
		caret.pxl.x, n_focus * font_size.height,
		cch, n_focus
	);

	shift_selection_is_tail = TRUE;


	return;
}

- (void) n_detect_doubleclick
{
//return;

	n_posix_char *line = n_txt_get( n_txt_data, n_focus );
//NSLog( @"%c", line[ caret_fr.cch.x ] );

	if (
		( line[ caret_fr.cch.x ] ==  ' ' )
		||
		( line[ caret_fr.cch.x ] == '\t' )
	)
	{
//NSLog( @"blank" );

		{

			n_type_int cch_fr = caret_fr.cch.x;
			n_posix_loop
			{
				if ( cch_fr <= 0 ) { break; }

//NSLog( @"%c", line[ cch_fr ] );

				if (
					( line[ cch_fr ] !=  ' ' )
					&&
					( line[ cch_fr ] != '\t' )
				)
				{
					cch_fr++;
					break;
				}

				cch_fr--;
			}


			caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				n_txt_data,
				n_focus,
				font,
				font_size,
				cch_fr
			);

		}

		{

			n_type_int cch_to = caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == '\0' ) { break; }

				if (
					( line[ cch_to ] !=  ' ' )
					&&
					( line[ cch_to ] != '\t' )
				)
				{
					break;
				}

				cch_to++;
			}


			caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt_data,
				n_focus,
				font,
				font_size,
				cch_to
			);

		}

	} else {
//NSLog( @"non-blank : %s", line );

		{

			n_type_int cch_fr = caret_fr.cch.x;
//NSLog( @"start %c", line[ cch_fr ] );

			n_posix_loop
			{
				if ( cch_fr < 0 ) { cch_fr = 0; break; }

				if (
					( line[ cch_fr ] ==  ' ' )
					||
					( line[ cch_fr ] == '\t' )
				)
				{
					cch_fr++;
//NSLog( @"found %c", line[ cch_fr ] );
					break;
				}

				cch_fr--;
			}

			caret_fr = n_txtbox_caret_detect_cch2pixel
			(
				n_txt_data,
				n_focus,
				font,
				font_size,
				cch_fr
			);

//NSLog( @"%c", line[ cch_fr ] );

		}

		{

			n_type_int cch_to = caret_to.cch.x;
			n_posix_loop
			{
				if ( line[ cch_to ] == '\0' ) { break; }

				if (
					( line[ cch_to ] ==  ' ' )
					||
					( line[ cch_to ] == '\t' )
				)
				{
					break;
				}

				cch_to++;
			}


			caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt_data,
				n_focus,
				font,
				font_size,
				cch_to
			);

		}

	}


	shift_selection_is_tail = TRUE;


//n_caret_debug_cch( caret_fr, caret_to );
	return;	
}




-(void) n_caret_out_of_canvas_ud
{

	CGFloat csy              = self.frame.size.height - ( offset * 2 );
	CGFloat items_per_canvas = csy / font_size.height;


	CGFloat minim = MIN( caret_fr.cch.y, caret_to.cch.y );
	CGFloat maxim = MAX( caret_fr.cch.y, caret_to.cch.y );

	if ( minim < scroll )
	{
//NSLog( @"up" );
		if ( ( minim - 1 ) == scroll )
		{
			scroll--;
		} else {
			scroll = minim - ( items_per_canvas / 2 );
		}
	} else
	if ( maxim >= ( scroll + items_per_canvas - 1 ) )
	{
//NSLog( @"down : %f %f", maxim, ( scroll + items_per_canvas - 1 ) );

		if ( ceil( maxim - 1 ) == ceil( scroll + items_per_canvas - 1 ) )
		{
			scroll++;
		} else {
			scroll = maxim - ( items_per_canvas / 2 );
		}
	}

}

-(void) n_caret_out_of_canvas_lr
{

	CGFloat csy              = self.frame.size.height - ( offset * 2 );
	CGFloat items_per_canvas = csy / font_size.height;


	CGFloat minim = MIN( caret_fr.cch.y, caret_to.cch.y );
	CGFloat maxim = MAX( caret_fr.cch.y, caret_to.cch.y );

	if ( minim < scroll )
	{
//NSLog( @"up" );
		scroll = minim - ( items_per_canvas / 2 );
	} else
	if ( maxim >= ( scroll + items_per_canvas - 1 ) )
	{
//NSLog( @"down : %f %f", maxim, ( scroll + items_per_canvas - 1 ) );
		scroll = maxim - ( items_per_canvas / 2 );
	}

}




#ifdef N_TXTBOX_IME_ENABLE

- (BOOL)hasMarkedText;
{
//NSLog( @"hasMarkedText" );

	return NO;
}

- (NSRange)markedRange
{
//NSLog( @"markedRange" );

	NSRange range = { NSNotFound, 0 };
	return range;
}

- (NSRange)selectedRange
{
//NSLog( @"selectedRange" );

	NSRange range = { NSNotFound, 0 };
	return range;
}

- (void)setMarkedText:(id)string 
        selectedRange:(NSRange)selectedRange 
     replacementRange:(NSRange)replacementRange
{
//NSLog( @"setMarkedText : %@", [string string] );

//NSLog( @"setMarkedText : Set     %lu %lu", selectedRange.location, selectedRange.length );
//NSLog( @"setMarkedText : Replace %lu %lu", replacementRange.location, replacementRange.length );

	BOOL prv_onoff = ime_onoff;

	ime_nsstr = [[string string] copy];
	ime_onoff = ( [ime_nsstr length] != 0 );
	ime_freed = FALSE;
	ime_focus = selectedRange;
//NSLog( @"NSString : %@", ime_nsstr );

	if ( ime_onoff )
	{
		if ( prv_onoff == FALSE ) { ime_caret_fr = caret_fr; }
		ime_caret_to = caret_fr;
	}


	return;
}

- (void)unmarkText
{
//NSLog( @"unmarkText" );

	return;
}

- (NSArray<NSAttributedStringKey> *)validAttributesForMarkedText
{
//NSLog( @"validAttributesForMarkedText" );

	return [[NSArray alloc] init];
}

- (NSAttributedString *)attributedSubstringForProposedRange:(NSRange)range 
                                                actualRange:(NSRangePointer)actualRange
{
//NSLog( @"attributedSubstringForProposedRange" );

	return nil;
}

- (void)insertText:(id)string 
  replacementRange:(NSRange)replacementRange
{
//NSLog( @"insertText" );

	// [x] ; crash when access to [string string]

	return;
}

- (NSUInteger)characterIndexForPoint:(NSPoint)point
{
//NSLog( @"characterIndexForPoint" );

	return 0;
}

- (NSRect)firstRectForCharacterRange:(NSRange)range 
                         actualRange:(NSRangePointer)actualRange
{
//NSLog( @"firstRectForCharacterRange" );
//NSLog( @"firstRectForCharacterRange : %@", NSStringFromRange( range ) );


	n_posix_char *str = n_mac_nsstring2str( ime_nsstr );
	//n_type_int    cch = n_posix_strlen( str );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		n_txt_data,
		n_focus,
		font,
		font_size,
		ime_caret_fr.cch.x// + cch
	);

	n_string_free( str );


	CGFloat ox = caret.pxl.x + padding;
	CGFloat oy = caret.pxl.y;
	
	if ( scroll )
	{
//NSLog( @" %0.2f %0.2f ", n_focus, scroll );
		oy -= ceil( scroll ) * font_size.height;
		oy += font_size.height;
	}

	oy += font_size.height;

	ox += offset;
	oy += offset;

	NSPoint point         = NSMakePoint( ox, oy );
	NSPoint pointInWindow = [self convertPoint:point toView:nil];
	NSRect  rect          = NSMakeRect( pointInWindow.x, pointInWindow.y, 0, 0 );
	NSRect  pointOnScreen = [[self window] convertRectToScreen:rect];

//NSLog( @" %0.2f %0.2f ", pointOnScreen.origin.x, pointOnScreen.origin.y );

	return pointOnScreen;
}

- (void)doCommandBySelector:(SEL)selector
{
//NSLog( @"doCommandBySelector" );

	return;
}
#endif




@end




#include "n_txtbox/07_dnd.c"
#include "n_txtbox/08_draw.c"
#include "n_txtbox/09_search.c"
#include "n_txtbox/10_keyboard.c"
#include "n_txtbox/11_mouse.c"




#endif // _H_NONNON_MAC_NONNON_TXTBOX



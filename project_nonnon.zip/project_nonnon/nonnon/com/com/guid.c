// COM GUID
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_COM_GUID
#define _H_NONNON_WIN32_COM_GUID




#include <objbase.h>




//#ifdef _CGUID_H


#define n_guid_GUID_NULL n_posix_literal( "{00000000-0000-0000-0000-000000000000}" )
#define n_GUID_NULL      n_com_guid( n_guid_GUID_NULL )


//#endif // #ifdef _CGUID_H




//#ifdef _DOCOBJ_H


#define n_guid_IID_IOleDocument n_posix_literal( "{b722bcc5-4e68-101b-a2bc-00aa00404770}" )
#define n_IID_IOleDocument      n_com_guid( n_guid_IID_IOleDocument )


#define n_guid_IID_IOleDocumentView n_posix_literal( "{b722bcc6-4e68-101b-a2bc-00aa00404770}" )
#define n_IID_IOleDocumentView      n_com_guid( n_guid_IID_IOleDocumentView )


#define n_guid_IID_IOleCommandTarget n_posix_literal( "{b722bccb-4e68-101b-a2bc-00aa00404770}" )
#define n_IID_IOleCommandTarget      n_com_guid( n_guid_IID_IOleCommandTarget )


//#endif // #ifdef _DOCOBJ_H




//#ifdef _EXDISP_H


#define n_guid_CLSID_InternetExplorer n_posix_literal( "{0002DF01-0000-0000-C000-000000000046}" )
#define n_CLSID_InternetExplorer      n_com_guid( n_guid_CLSID_InternetExplorer )


#define n_guid_CLSID_InternetExplorerMedium n_posix_literal( "{D5E8041D-920F-45e9-B8FB-B1DEB82C6E5E}" )
#define n_CLSID_InternetExplorerMedium      n_com_guid( n_guid_CLSID_InternetExplorerMedium )


#define n_guid_CLSID_ShellBrowserWindow n_posix_literal( "{c08afd90-f2a1-11d1-8455-00a0c91f3880}" )
#define n_CLSID_ShellBrowserWindow      n_com_guid( n_guid_CLSID_ShellBrowserWindow )


#define n_guid_CLSID_ShellWindows n_posix_literal( "{9BA05972-F6A8-11CF-A442-00A0C90A8F39}" )
#define n_CLSID_ShellWindows      n_com_guid( n_guid_CLSID_ShellWindows )


#define n_guid_CLSID_WebBrowser n_posix_literal( "{8856F961-340A-11D0-A96B-00C04FD705A2}" )
#define n_CLSID_WebBrowser      n_com_guid( n_guid_CLSID_WebBrowser )


#define n_guid_CLSID_WebBrowser_V1 n_posix_literal( "{EAB22AC3-30C1-11CF-A7EB-0000C05BAE0B}" )
#define n_CLSID_WebBrowser_V1      n_com_guid( n_guid_CLSID_WebBrowser_V1 )


#define n_guid_DIID_DWebBrowserEvents2 n_posix_literal( "{34A715A0-6587-11D0-924A-0020AFC7AC4D}" )
#define n_DIID_DWebBrowserEvents2      n_com_guid( n_guid_DIID_DWebBrowserEvents2 )


#define n_guid_IID_IShellWindows n_posix_literal( "{EAB22AC1-30C1-11CF-A7EB-0000C05BAE0B}" )
#define n_IID_IShellWindows      n_com_guid( n_guid_IID_IShellWindows )


#define n_guid_IID_IWebBrowser n_posix_literal( "{85CB6900-4D95-11CF-960C-0080C7F4EE85}" )
#define n_IID_IWebBrowser      n_com_guid( n_guid_IID_IWebBrowser )


#define n_guid_IID_IWebBrowser2 n_posix_literal( "{D30C1661-CDAF-11D0-8A3E-00C04FC9E26E}" )
#define n_IID_IWebBrowser2      n_com_guid( n_guid_IID_IWebBrowser2 )


#define n_guid_IID_IWebBrowserApp n_posix_literal( "{0002DF05-0000-0000-C000-000000000046}" )
#define n_IID_IWebBrowserApp      n_com_guid( n_guid_IID_IWebBrowserApp )


#define n_guid_SID_SInternetExplorer n_guid_IID_IWebBrowserApp
#define n_SID_SInternetExplorer      n_IID_IWebBrowserApp


#define n_guid_SID_SWebBrowserApp    n_guid_IID_IWebBrowserApp
#define n_SID_SWebBrowserApp         n_IID_IWebBrowserApp


//#endif // #ifdef _EXDISP_H




// Htiframe.h : MinGW hasn't this header file


#define n_guid_IID_ITargetContainer n_posix_literal( "{7847EC01-2BEC-11D0-82B4-00A0C90C29C5}" )
#define n_IID_ITargetContainer      n_com_guid( n_guid_IID_ITargetContainer )


//




// mshtmhst.h : MinGW hasn't this header file


#define n_guid_IID_IDocHostUIHandler n_posix_literal( "{BD3F23C0-D43E-11CF-893B-00AA00BDCE1A}" )
#define n_IID_IDocHostUIHandler      n_com_guid( n_guid_IID_IDocHostUIHandler )


#define n_guid_IID_ICustomDoc n_posix_literal( "{3050f3f0-98b5-11cf-bb82-00aa00bdce0b}" )
#define n_IID_ICustomDoc      n_com_guid( n_guid_IID_ICustomDoc )


//




//#ifdef _MSHTML_H


#define n_guid_CLSID_HTMLDocument n_posix_literal( "{25336920-03F9-11cf-8FD0-00AA00686F13}" )
#define n_CLSID_HTMLDocument      n_com_guid( n_guid_CLSID_HTMLDocument )


#define n_guid_IID_IHTMLDocument2 n_posix_literal( "{332C4425-26CB-11D0-B483-00C04FD90119}" )
#define n_IID_IHTMLDocument2      n_com_guid( n_guid_IID_IHTMLDocument2 )


#define n_guid_IID_IHTMLSelectionObject n_posix_literal( "{3050f25A-98b5-11cf-bb82-00aa00bdce0b}" )
#define n_IID_IHTMLSelectionObject      n_com_guid( n_guid_IID_IHTMLSelectionObject )


#define n_guid_IID_IHTMLWindow2   n_posix_literal( "{332C4427-26CB-11D0-B483-00C04FD90119}" )
#define n_IID_IHTMLWindow2        n_com_guid( n_guid_IID_IHTMLWindow2 )


#define n_guid_IID_IHTMLElement2   n_posix_literal( "{3050f434-98b5-11cf-bb82-00aa00bdce0b}" )
#define n_IID_IHTMLElement2        n_com_guid( n_guid_IID_IHTMLElement2 )


#define n_guid_DIID_HTMLDocumentEvents n_posix_literal( "{3050F260-98B5-11CF-BB82-00AA00BDCE0B}" )
#define n_DIID_HTMLDocumentEvents      n_com_guid( n_guid_DIID_HTMLDocumentEvents )


#define n_guid_DIID_HTMLDocumentEvents2 n_posix_literal( "{3050F613-98B5-11CF-BB82-00AA00BDCE0B}" )
#define n_DIID_HTMLDocumentEvents2      n_com_guid( n_guid_DIID_HTMLDocumentEvents2 )


#define n_guid_DIID_HTMLDocumentEvents3 n_posix_literal( "{3050F5A0-98B5-11CF-BB82-00AA00BDCE0B}" )
#define n_DIID_HTMLDocumentEvents3      n_com_guid( n_guid_DIID_HTMLDocumentEvents3 )


#define n_guid_DIID_HTMLFrameSiteEvents  n_posix_literal( "{3050f800-98b5-11cf-bb82-00aa00bdce0b}" )
#define n_DIID_HTMLFrameSiteEvents       n_com_guid( n_guid_DIID_HTMLFrameSiteEvents  )


#define n_guid_DIID_HTMLFrameSiteEvents2 n_posix_literal( "{3050f7ff-98b5-11cf-bb82-00aa00bdce0b}" )
#define n_DIID_HTMLFrameSiteEvents2      n_com_guid( n_guid_DIID_HTMLFrameSiteEvents2 )


#define n_guid_DIID_HTMLWindowEvents n_posix_literal( "{96A0A4E0-D062-11cf-94B6-00AA0060275C}" )
#define n_DIID_HTMLWindowEvents      n_com_guid( n_guid_DIID_HTMLWindowEvents )


//#endif // #ifdef _MSHTML_H




//#ifdef _OAIDL_H


#define n_guid_IID_IDispatch n_posix_literal( "{00020400-0000-0000-C000-000000000046}" )
#define n_IID_IDispatch      n_com_guid( n_guid_IID_IDispatch )


//#endif // #ifdef _OAIDL_H




//#ifdef _OBJIDL_H


#define n_guid_IID_IPersistFile n_posix_literal( "{0000010B-0000-0000-C000-000000000046}" )
#define n_IID_IPersistFile      n_com_guid( n_guid_IID_IPersistFile )


#define n_guid_IID_IStorage n_posix_literal( "{0000000B-0000-0000-C000-000000000046}" )
#define n_IID_IStorage      n_com_guid( n_guid_IID_IStorage )



//#endif // #ifdef _OBJIDL_H




//#ifdef _OCIDL_H


#define n_guid_IID_IConnectionPoint n_posix_literal( "{B196B286-BAB4-101A-B69C-00AA00341D07}" )
#define n_IID_IConnectionPoint      n_com_guid( n_guid_IID_IConnectionPoint )


#define n_guid_IID_IConnectionPointContainer n_posix_literal( "{B196B284-BAB4-101A-B69C-00AA00341D07}" )
#define n_IID_IConnectionPointContainer      n_com_guid( n_guid_IID_IConnectionPointContainer )


#define n_guid_IID_IOleControl n_posix_literal( "{B196B288-BAB4-101A-B69C-00AA00341D07}" )
#define n_IID_IOleControl      n_com_guid( n_guid_IID_IOleControl )


#define n_guid_IID_IPersistStreamInit n_posix_literal( "{7FD52380-4E07-101B-AE2D-08002B2EC713}" )
#define n_IID_IPersistStreamInit      n_com_guid( n_guid_IID_IPersistStreamInit )


#define n_guid_IID_IPropertyNotifySink n_posix_literal( "{9BFBBC02-EFF1-101A-84ED-00AA00341D07}" )
#define n_IID_IPropertyNotifySink      n_com_guid( n_guid_IID_IPropertyNotifySink )


//#endif // #ifdef _OCIDL_H




//#ifdef _OLEIDL_H


#define n_guid_IID_IDataObject n_posix_literal( "{0000010e-0000-0000-C000-000000000046 }" )
#define n_IID_IDataObject      n_com_guid( n_guid_IID_IDataObject )


#define n_guid_IID_IDropSource n_posix_literal( "{00000121-0000-0000-C000-000000000046}" )
#define n_IID_IDropSource      n_com_guid( n_guid_IID_IDropSource )


#define n_guid_IID_IDropTarget n_posix_literal( "{00000122-0000-0000-C000-000000000046}" )
#define n_IID_IDropTarget      n_com_guid( n_guid_IID_IDropTarget )


#define n_guid_IID_IOleClientSite n_posix_literal( "{00000118-0000-0000-C000-000000000046}" )
#define n_IID_IOleClientSite      n_com_guid( n_guid_IID_IOleClientSite )


#define n_guid_IID_IOleContainer n_posix_literal( "{0000011b-0000-0000-C000-000000000046}" )
#define n_IID_IOleContainer      n_com_guid( n_guid_IID_IOleContainer )


#define n_guid_IID_IOleInPlaceFrame n_posix_literal( "{00000116-0000-0000-C000-000000000046}" )
#define n_IID_IOleInPlaceFrame      n_com_guid( n_guid_IID_IOleInPlaceFrame )


#define n_guid_IID_IOleInPlaceUIWindow n_posix_literal( "{00000115-0000-0000-C000-000000000046}" )
#define n_IID_IOleInPlaceUIWindow      n_com_guid( n_guid_IID_IOleInPlaceUIWindow )


#define n_guid_IID_IOleInPlaceObject n_posix_literal( "{00000113-0000-0000-C000-000000000046}" )
#define n_IID_IOleInPlaceObject      n_com_guid( n_guid_IID_IOleInPlaceObject )


#define n_guid_IID_IOleInPlaceSite n_posix_literal( "{00000119-0000-0000-C000-000000000046}" )
#define n_IID_IOleInPlaceSite      n_com_guid( n_guid_IID_IOleInPlaceSite )


#define n_guid_IID_IOleObject n_posix_literal( "{00000112-0000-0000-C000-000000000046}" )
#define n_IID_IOleObject      n_com_guid( n_guid_IID_IOleObject )


#define n_guid_IID_IOleWindow n_posix_literal( "{00000114-0000-0000-C000-000000000046}" )
#define n_IID_IOleWindow      n_com_guid( n_guid_IID_IOleWindow )


//#endif // #ifdef _OLEIDL_H




//#ifdef _SERVPROV_H


#define n_guid_IID_IServiceProvider n_posix_literal( "{6D5140C1-7436-11CE-8034-00AA006009FA}" )
#define n_IID_IServiceProvider      n_com_guid( n_guid_IID_IServiceProvider )


//#endif // #ifdef _SERVPROV_H




// Shdeprecated.h


#define n_guid_IID_IBrowserService n_posix_literal( "{02BA3B52-0547-11D1-B833-00C04FC9B31F}" )
#define n_IID_IBrowserService      n_com_guid( n_guid_IID_IBrowserService )


//




#ifdef _SHLGUID_H


#define n_guid_SID_STopLevelBrowser n_posix_literal( "{4C96BE40-915C-11CF-99D3-00AA004AE837}" )
#define n_SID_STopLevelBrowser      n_com_guid( n_guid_SID_STopLevelBrowser )


#endif // #ifdef _SHLGUID_H




//#ifdef _SHLOBJ_H


#define n_guid_CLSID_Shell n_posix_literal( "{13709620-C279-11CE-A49E-444553540000}" )
#define n_CLSID_Shell      n_com_guid( n_guid_CLSID_Shell )


#define n_guid_CLSID_ShellBrowser n_posix_literal( "{000214E2-0000-0000-C000-000000000046}" )
#define n_CLSID_ShellBrowser      n_com_guid( n_guid_CLSID_ShellBrowser )


#define n_guid_CLSID_ShellLink n_posix_literal( "{00021401-0000-0000-C000-000000000046}" )
#define n_CLSID_ShellLink      n_com_guid( n_guid_CLSID_ShellLink )


#define n_guid_IID_IShellLinkA n_posix_literal( "{000214EE-0000-0000-C000-000000000046}" )
#define n_IID_IShellLinkA      n_com_guid( n_guid_IID_IShellLinkA )


#define n_guid_IID_IShellLinkW n_posix_literal( "{000214F9-0000-0000-C000-000000000046}" )
#define n_IID_IShellLinkW      n_com_guid( n_guid_IID_IShellLinkW )


//#endif // #ifdef _SHLOBJ_H




//#ifdef _UNKNWN_H


#define n_guid_IID_IUnknown n_posix_literal( "{00000000-0000-0000-C000-000000000046}" )
#define n_IID_IUnknown      n_com_guid( n_guid_IID_IUnknown )


//#endif // #ifdef _UNKNWN_H




// urlmon.h : MinGW hasn't this header file


#define n_guid_CLSID_IInternetSecurityManager n_posix_literal( "{7B8A2D94-0AC9-11D1-896C-00C04FB6BFC4}" )
#define n_CLSID_IInternetSecurityManager      n_com_guid( n_guid_CLSID_IInternetSecurityManager )


#define n_guid_IID_IInternetSecurityManager n_posix_literal( "{79EAC9EE-BAF9-11CE-8C82-00AA004BA90B}" )
#define n_IID_IInternetSecurityManager      n_com_guid( n_guid_IID_IInternetSecurityManager )


#define n_guid_SID_SInternetSecurityManager n_guid_IID_IInternetSecurityManager
#define n_SID_SInternetSecurityManager      n_IID_IInternetSecurityManager


//




// ???


#define n_guid_CGID_WebBrowser n_posix_literal( "{ED016940-BD5B-11cf-BA4E-00C04FD70816}" )
#define n_CGID_WebBrowser      n_com_guid( n_guid_CGID_WebBrowser )


//




#endif // _H_NONNON_WIN32_COM_GUID


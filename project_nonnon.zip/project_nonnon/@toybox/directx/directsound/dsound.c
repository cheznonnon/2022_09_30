// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../../nonnon/neutral/posix.c"
#include "../../../nonnon/win32/win.c"

#include "../../../nonnon/game/sound/directsound.c"




void
n_dsound_load( HWND hwnd, n_posix_char *cmdline )
{

	n_wav wav; n_wav_zero( &wav );
	if ( n_wav_load( &wav, cmdline ) )
	{
n_posix_debug_literal( "n_wav_load()" );
		return;
	}


	n_directsound ds; n_directsound_zero( &ds );

	n_directsound_init( &ds, hwnd, &wav );


DSCAPS caps; ZeroMemory( &caps, sizeof( DSCAPS ) ); caps.dwSize = sizeof( DSCAPS );
IDirectSound_GetCaps( ds.ds, &caps );
n_posix_debug_literal
(
	"%d %d %d",
	caps.dwMaxHwMixingAllBuffers,
	caps.dwMaxHwMixingStaticBuffers,
	caps.dwMaxHwMixingStreamingBuffers
);

	n_directsound_loop( &ds );

	n_posix_sleep( N_WAV_MSEC( &wav ) );

	n_directsound_exit( &ds );


	n_wav_free( &wav );


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char cmdline[ N_PATH_MAX ];


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Nonnon Direct Sound Test", "", "" );
		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );
n_posix_debug_literal( "%s", cmdline );

		n_dsound_load( hwnd, cmdline );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


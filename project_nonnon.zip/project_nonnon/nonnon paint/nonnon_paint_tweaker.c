// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_button.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_colorpicker.c"
#include "../nonnon/win32/win_separator.c"

#include "../nonnon/project/macro.c"




LRESULT CALLBACK
n_paint_clearcanvas_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_colorpicker cp;
	static n_win_button      hbtn;


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_colorpicker_on_settingchange( &cp );

		n_win_button_on_settingchange( &hbtn );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_colorpicker_zero( &cp );

		n_win_button_zero( &hbtn );


		// Window

		n_win_init_literal( hwnd, "Clear", "", "" );

		n_win_button_init( &hbtn, hwnd, n_project_string_go, PBS_NORMAL );

		n_win_colorpicker_init( &cp, hwnd );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		if ( n_paint_layer_onoff )
		{
			nwclr_refresh( &cp,   0,255,255,255 );
		} else {
			nwclr_refresh( &cp, 255,255,255,255 );
		}


		// Size

		{

		const n_bool redraw = n_true;


		n_type_gfx ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );

		n_type_gfx pad = m;

		n_type_gfx gap = m * 2;
		n_type_gfx csx = ( ico * 5 ) + ( gap * 4 );
		n_type_gfx csy = ( ctl * ( 4 + 1 ) );

		n_win_set( hwnd, NULL, csx + ( pad * 2 ), csy + ( pad * 2 ), N_WIN_SET_CENTERING );

		n_type_gfx clr = ctl * 4;

		n_type_gfx x = pad;
		n_type_gfx y = pad;

		nwclr_move       ( &cp  , x, ( ctl * 0 ) + y, csx,clr, redraw );
		n_win_button_move( &hbtn, x, ( ctl * 4 ) + y, csx,ctl, redraw );

		}


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, n_false );
		EnableWindow( hwnd_layr, n_false );
		EnableWindow( hwnd_main, n_false );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else

		if ( wparam == N_PAINT_KEY_6 )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hbtn.hwnd )
		{

			u32 color = n_bmp_argb( cp.a, cp.r, cp.g, cp.b );

			n_paint_layer_bmp_flush( color );

			n_paint_refresh_all();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, n_true );
		EnableWindow( hwnd_layr, n_true );
		EnableWindow( hwnd_main, n_true );

		ShowWindow( hwnd, SW_HIDE );


		n_win_colorpicker_exit( &cp );

		n_win_button_exit( &hbtn );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}

	nwclr_proc( hwnd, msg, wparam, lparam, &cp );

	n_win_button_proc( hwnd, msg, wparam, lparam, &hbtn );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
n_paint_alphatweaker_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_button hbtn;
	static n_win_button h_go;
	static n_win_check  hchk[ 2 ];


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_check_on_settingchange( &hchk[ 0 ] );
		n_win_check_on_settingchange( &hchk[ 1 ] );

		n_win_button_on_settingchange( &hbtn );
		n_win_button_on_settingchange( &h_go );

	break;


	case WM_CREATE :


		// Global

		n_win_check_zero( &hchk[ 0 ] );
		n_win_check_zero( &hchk[ 1 ] );

		n_win_ime_disable( hwnd );

		n_win_button_zero( &hbtn );
		n_win_button_zero( &h_go );


		// Window

		n_win_init_literal( hwnd, "Alpha Tweaker", "", "" );

		n_win_button_init( &hbtn, hwnd, N_STRING_EMPTY     , PBS_NORMAL );
		n_win_button_init( &h_go, hwnd, n_project_string_go, PBS_NORMAL );

		n_win_check_init_literal( &hchk[ 0 ], hwnd, "Clear"  , CBS_UNCHECKEDNORMAL );
		n_win_check_init_literal( &hchk[ 1 ], hwnd, "Reverse", CBS_UNCHECKEDNORMAL );

		hbtn.hicon = n_win_icon_init( NULL, N_APPS_ICON_OFFSET_NONNON_PAINT + 1, N_WIN_ICON_INIT_OPTION_RESOURCE );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		// Size

		{

		const n_bool redraw = n_true;


		n_type_gfx ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );
		ico = n_posix_max_n_type_gfx( ico, ctl * 2 );

		n_type_gfx pad = m;


		n_type_gfx csy = ( ctl * 3 );
		n_type_gfx csx = ( csy * 3 );

		n_win_set( hwnd, NULL, csx + ( pad * 2 ), csy + ( pad * 2 ), N_WIN_SET_CENTERING );

		n_type_gfx x = pad;
		n_type_gfx y = pad;

		n_win_button_move( &hbtn          ,         x,             y, ico,ico, redraw );
		n_win_move       (  hchk[ 0 ].hwnd, (2*ico)+x, ( ctl * 0 )+y, csx,ctl, redraw );
		n_win_move       (  hchk[ 1 ].hwnd, (2*ico)+x, ( ctl * 1 )+y, csx,ctl, redraw );
		n_win_button_move( &h_go          ,         x, ( ctl * 2 )+y, csx,ctl, redraw );

		}


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, n_false );
		EnableWindow( hwnd_layr, n_false );
		EnableWindow( hwnd_main, n_false );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

		if ( wparam == N_PAINT_KEY_7 )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == h_go.hwnd )
		{

			if ( n_win_check_is_checked( &hchk[ 0 ] ) )
			{
				n_paint_layer_bmp_alpha( N_PAINT_FILTER_ALPHA_CLR );
			}

			if ( n_win_check_is_checked( &hchk[ 1 ] ) )
			{
				n_paint_layer_bmp_alpha( N_PAINT_FILTER_ALPHA_REV );
			}


			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, n_true );
		EnableWindow( hwnd_layr, n_true );
		EnableWindow( hwnd_main, n_true );

		ShowWindow( hwnd, SW_HIDE );


		n_win_button_exit( &hbtn );
		n_win_button_exit( &h_go );

		n_win_check_exit( &hchk[ 0 ] );
		n_win_check_exit( &hchk[ 1 ] );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	n_win_check_proc( hwnd, msg, wparam, lparam, &hchk[ 0 ] );
	n_win_check_proc( hwnd, msg, wparam, lparam, &hchk[ 1 ] );

	n_win_button_proc( hwnd, msg, wparam, lparam, &hbtn );
	n_win_button_proc( hwnd, msg, wparam, lparam, &h_go );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

LRESULT CALLBACK
n_paint_colorreplacer_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_colorpicker cp_f;
	static n_win_colorpicker cp_t;
	static n_win_button      hbtn;
	static HWND              hhr1;
	static HWND              hhr2;
	static HWND              hhr3;


	static UINT timer_id = 0;


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		if ( timer_id == 0 ) { timer_id = n_win_timer_id_get(); }

		n_win_timer_init( hwnd, timer_id, n_project_settingchange_interval() );

	break;

	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam != timer_id ) { break; }


		n_win_timer_exit( hwnd, timer_id );


		n_project_darkmode();


		n_win_init_background( hwnd );
		n_win_refresh( hwnd, n_true );

		n_win_refresh( hhr1, n_true );
		n_win_refresh( hhr2, n_true );
		n_win_refresh( hhr3, n_true );

		n_win_colorpicker_on_settingchange( &cp_f );
		n_win_colorpicker_on_settingchange( &cp_t );

		n_win_button_on_settingchange( &hbtn );

	break;


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_win_colorpicker_zero( &cp_f );
		n_win_colorpicker_zero( &cp_t );

		n_win_button_zero( &hbtn );


		// Window

		n_win_init_literal( hwnd, "Color Replacer", "", "" );

		n_win_gui_literal( hwnd, CANVAS, "From", &hhr1 );
		n_win_gui_literal( hwnd, CANVAS, "To",   &hhr2 );
		n_win_gui_literal( hwnd, CANVAS, "",     &hhr3 );

		n_win_button_init( &hbtn, hwnd, n_project_string_go, PBS_NORMAL );

		n_win_colorpicker_init( &cp_f, hwnd );
		n_win_colorpicker_init( &cp_t, hwnd );


		// Style

		// [!] : WinXP/Luna : need to set WS_EX_DLGMODALFRAME before WS_*

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW    );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );


		n_win_stdfont_init( &hhr1, 1 );
		n_win_stdfont_init( &hhr2, 1 );
		n_win_stdfont_init( &hhr3, 1 );


		nwclr_refresh( &cp_f, cp.a, cp.r, cp.g, cp.b );
		nwclr_refresh( &cp_t, cp.a, cp.r, cp.g, cp.b );


		// Size

		{

		const n_bool redraw = n_true;


		n_type_gfx ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );

		n_type_gfx pad = m;

		n_type_gfx gap = m * 2;
		n_type_gfx csx = ( ico * 5 ) + ( gap * 4 );
		n_type_gfx csy = ( ctl * ( 1 + 4 + 1 + 4 + 1 + 1 ) );

		n_win_set( hwnd, NULL, csx + ( pad * 2 ), csy + ( pad * 2 ), N_WIN_SET_CENTERING );

		n_type_gfx clr = ctl * 4;

		n_type_gfx x = pad;
		n_type_gfx y = pad;

		n_win_move       (  hhr1, x, ( ctl *  0 ) + y, csx,ctl, redraw );
		nwclr_move       ( &cp_f, x, ( ctl *  1 ) + y, csx,clr, redraw );
		n_win_move       (  hhr2, x, ( ctl *  5 ) + y, csx,ctl, redraw );
		nwclr_move       ( &cp_t, x, ( ctl *  6 ) + y, csx,clr, redraw );
		n_win_move       (  hhr3, x, ( ctl * 10 ) + y, csx,ctl, redraw );
		n_win_button_move( &hbtn, x, ( ctl * 11 ) + y, csx,ctl, redraw );

		}


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, n_false );
		EnableWindow( hwnd_layr, n_false );
		EnableWindow( hwnd_main, n_false );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else

		if ( wparam == N_PAINT_KEY_8 )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == hbtn.hwnd )
		{

			u32 f = n_bmp_argb( cp_f.a, cp_f.r, cp_f.g, cp_f.b );
			u32 t = n_bmp_argb( cp_t.a, cp_t.r, cp_t.g, cp_t.b );

			n_paint_layer_bmp_flush_replacer( f, t );

			n_paint_refresh_all();

			n_win_message_send( hwnd, WM_CLOSE, 0,0 );

		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, n_true );
		EnableWindow( hwnd_layr, n_true );
		EnableWindow( hwnd_main, n_true );

		ShowWindow( hwnd, SW_HIDE );


		n_win_stdfont_exit( &hhr1, 1 );
		n_win_stdfont_exit( &hhr2, 1 );
		n_win_stdfont_exit( &hhr3, 1 );

		n_win_colorpicker_exit( &cp_f );
		n_win_colorpicker_exit( &cp_t );

		n_win_button_exit( &hbtn );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		LRESULT ret = n_win_darkmode_proc( hwnd, msg, wparam, lparam );
		if ( ret ) { return ret; }
	}

	n_win_separator_proc( hwnd, msg, wparam, lparam, hhr1, PS_DOT   );
	n_win_separator_proc( hwnd, msg, wparam, lparam, hhr2, PS_DOT   );
	n_win_separator_proc( hwnd, msg, wparam, lparam, hhr3, PS_SOLID );

	nwclr_proc( hwnd, msg, wparam, lparam, &cp_f );
	nwclr_proc( hwnd, msg, wparam, lparam, &cp_t );

	n_win_button_proc( hwnd, msg, wparam, lparam, &hbtn );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}



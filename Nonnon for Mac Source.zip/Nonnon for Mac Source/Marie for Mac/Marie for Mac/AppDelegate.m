//
//  AppDelegate.m
//  Marie for Mac
//
//  Created by nonnon on 2022/07/05.
//

#import "AppDelegate.h"


#import "../../nonnon/neutral/posix.c"

#import "../../nonnon/neutral/bmp/all.c"
#import "../../nonnon/neutral/curico.c"
#import "../../nonnon/neutral/jpg.c"
#import "../../nonnon/neutral/png.c"

#import "../../nonnon/mac/image.c"
#import "../../nonnon/mac/n_imageview.c"
#import "../../nonnon/mac/n_scrollview.c"
#import "../../nonnon/mac/window.c"




@interface AppDelegate () <NonnonDragAndDrop_delegate>

@property (strong) IBOutlet NSWindow *window;

@property (strong) NonnonImageView  *imageview;
@property (strong) NonnonScrollView *scroll;

@end


@implementation AppDelegate {

	NSString     *n_path;
	n_bmp         n_bmp_drop_here;
	n_bmp         n_bmp;
	n_posix_bool  n_error;
	n_posix_bool  resample_onoff;
	
}




- (void) n_load
{

	n_posix_char *path = n_mac_nsstring2str( n_path );

	if ( n_posix_stat_is_dir( path ) ) { n_error = n_posix_true; return; }

	n_curico curico; n_curico_zero( &curico );

	if (
		( n_png_png2bmp( path, &n_bmp ) )
		&&
		( n_jpg_jpg2bmp( path, &n_bmp ) )
		&&
		( n_curico_load( &curico, &n_bmp, path ) )
		&&
		( n_bmp_load( &n_bmp, path ) )
	)
	{
		n_error = n_posix_true;
	} else {
		n_error = n_posix_false;

		n_bmp_mac( &n_bmp );
	}

}

- (void) n_draw
{

	const n_type_gfx min_size  = 256;
	const double     max_ratio = 0.8;


	n_bmp bmp;

//NSLog( @"%d", n_error );
	if ( n_error )
	{
		n_bmp_carboncopy( &n_bmp_drop_here, &bmp );
	} else {
		n_bmp_carboncopy( &n_bmp          , &bmp );
	}

	if ( resample_onoff )
	{

		CGFloat isx = N_BMP_SX( &bmp );
		CGFloat isy = N_BMP_SY( &bmp );

		CGFloat max_sx = NSWidth ( [ [_window screen] frame ] ) * max_ratio;
		CGFloat max_sy = NSHeight( [ [_window screen] frame ] ) * max_ratio;

		double ratio_x = 1.0;
		double ratio_y = 1.0;

		if ( max_sx < isx )
		{
			ratio_x = max_sx / isx;
		}

		if ( max_sy < isy )
		{
			ratio_y = max_sy / isy;
		}

		double ratio = MIN( ratio_x, ratio_y );

		n_bmp_resampler( &bmp, ratio, ratio );

	}
	
	{
		n_type_gfx rsx = n_posix_max_n_type_gfx( min_size, N_BMP_SX( &bmp ) );
		n_type_gfx rsy = n_posix_max_n_type_gfx( min_size, N_BMP_SY( &bmp ) );

		n_bmp_resizer( &bmp, rsx, rsy, n_bmp_black, N_BMP_RESIZER_CENTER );
	}

	NSImage *nsimage = n_mac_image_nbmp2nsimage( &bmp );


	n_mac_window_image2window( _imageview, nsimage, _window, _scroll, 256, max_ratio );


	// [!] : HiDPI : macOS 10.15 Catalina : not beautiful

	if ( n_error )
	{
		NSString *text  = @"Drop Here";
		NSFont   *font  = [NSFont fontWithName:@"Trebuchet MS" size:32];
		u32       cmain = n_bmp_white;
		u32       ccntr = n_bmp_rgb( 10,10,10 );

		int mode = N_MAC_IMAGE_TEXT_CENTER | N_MAC_IMAGE_TEXT_SINK;
		n_mac_image_text_direct_draw( nsimage, text, font, cmain, ccntr, 2, 0,0,  mode );
	}


	n_mac_window_centering( _window );

}



- (void) NonnonDragAndDrop_dropped:(NSString*)nsstr; {
    
//NSLog( @"dropped : %@", nsstr );

	n_path = [nsstr copy];

	[self n_load];
	[self n_draw];

	n_mac_foreground();

}


- (void) n_marie_drophere
{

	n_error = n_posix_true;


	u32 accent = n_bmp_color_mac( n_mac_nscolor2argb( [NSColor controlAccentColor] ) );

	u32 bg;
	if ( n_mac_is_darkmode() )
	{
		bg = n_bmp_black;
	} else {
		bg = n_bmp_white;
	}

	n_bmp_zero( &n_bmp_drop_here );
	n_bmp_new( &n_bmp_drop_here, 256,256 );
	n_bmp_flush_gradient( &n_bmp_drop_here, bg, accent, N_BMP_GRADIENT_VERTICAL );

	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:@"manekineko_1" ofType:@"png"];
//NSLog( @"%@", path );
//NSLog( @"%s", n_mac_nsstring2str( path ) );

	n_bmp neko; n_bmp_zero( &neko );
	n_png_png2bmp( n_mac_nsstring2str( path ), &neko );
	n_bmp_mac( &neko );
	n_bmp_blendcopy( &neko, &n_bmp_drop_here, 0,0,256,256, 0,0, 0.5 );
	n_bmp_free( &neko );

/*
	NSString *text  = @"Drop Here";
	NSFont   *font  = [NSFont fontWithName:@"Trebuchet MS" size:32];
	u32       cmain = n_bmp_white;
	u32       ccntr = n_bmp_rgb( 10,10,10 );

	int mode = N_MAC_IMAGE_TEXT_CENTER | N_MAC_IMAGE_TEXT_SINK;
	n_mac_image_text( &n_bmp_drop_here, text, font, cmain, ccntr, 2, 0,0,  mode );
*/

// [Needed] : turn sandbox off via "Entitlement"
//
//	saved location
//	File -> Project Settings -> grayed circle -> Finder -> DerivedData

//n_bmp_save_literal( &n_bmp_drop_here, "ret.bmp" );


	return;
}


- (void) mouseUp:(NSEvent*) theEvent
{

	// [x] : rightMouseDown/Up is never called

	if ( [theEvent clickCount] == 2 )
	{

		n_mac_window_centering( _window );

	}

}

- (IBAction)n_marie_menu_onoff:(id)sender {

	if ( resample_onoff )
	{
		resample_onoff = n_posix_false;
		[sender setState:NSControlStateValueOff];
	} else {
		resample_onoff = n_posix_true;
		[sender setState:NSControlStateValueOn];
	}

	[self n_draw];

}




- (void)awakeFromNib
{

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}


- (void)applicationWillFinishLaunching:(NSNotification *)aNotification {

	n_bmp_zero( &n_bmp );

	resample_onoff = n_posix_true;

	[self n_marie_drophere];

	_imageview = n_mac_nonnon_imageview ( self, _window, 0,0,256,256 );
	_scroll    = n_mac_nonnon_scrollview( self, _window, _imageview );

	[self n_draw];

	n_mac_window_centering( _window );

}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


@end

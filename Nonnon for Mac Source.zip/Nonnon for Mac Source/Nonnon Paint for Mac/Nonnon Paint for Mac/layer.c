// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "../../nonnon/mac/n_txtbox.c"




#define N_PAINT_LAYER_INI_FILENAME n_posix_literal( "nonnon_paint.ini" )
#define N_PAINT_LAYER_INI_SECTION  n_posix_literal( "[Nonnon Paint Layer]" )
#define N_PAINT_LAYER_INI_INDEX    n_posix_literal( "index  " )
#define N_PAINT_LAYER_INI_NUMBER   n_posix_literal( "number " )
#define N_PAINT_LAYER_INI_NAME     n_posix_literal( "name   " )
#define N_PAINT_LAYER_INI_VISIBLE  n_posix_literal( "visible" )
#define N_PAINT_LAYER_INI_PERCENT  n_posix_literal( "percent" )
#define N_PAINT_LAYER_INI_BLUR     n_posix_literal( "blur   " )




#define n_paint_layer_ini_read(  i ) n_paint_layer_ini_main( i, TRUE  )
#define n_paint_layer_ini_write( i ) n_paint_layer_ini_main( i, FALSE )

// internal
void
n_paint_layer_ini_main( n_ini *ini, BOOL is_read )
{

	n_paint *p = n_paint_global.paint;


	if ( is_read )
	{
		n_type_int index;

		n_posix_char str[ 100 ];
		n_ini_value_str( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX, N_STRING_EMPTY, str, 100 );
		index = n_posix_atoi( str );
	} else {
		n_ini_new( ini );
	}


	n_type_int i = p->layer_count - 1;
	n_posix_loop
	{

		n_posix_char str_i[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_i, i );

		n_posix_char section[ 100 ];
		n_posix_sprintf_literal( section, "[%s]", str_i );

		n_ini_section_add( ini, section );

		if ( is_read )
		{
			n_posix_char str[ N_PAINT_LAYER_CCH ];
			n_ini_value_str( ini, section, N_PAINT_LAYER_INI_NAME, N_STRING_EMPTY, str, N_PAINT_LAYER_CCH );

			BOOL visible = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_VISIBLE, TRUE );
			int  percent = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_PERCENT,  100 );
			int     blur = n_ini_value_int( ini, section, N_PAINT_LAYER_INI_BLUR   ,    0 );
//NSLog( @"#%lld : %d %d %d", i, visible, percent, blur );
			n_string_copy( str, p->layer_data[ i ].name );

			p->layer_data[ i ].visible = visible;
			p->layer_data[ i ].percent = percent;
			p->layer_data[ i ].blur    = blur;
			p->layer_data[ i ].blend   = (n_type_real) percent * 0.01;
		} else {
			n_posix_char str[ N_PAINT_LAYER_CCH ];
			n_string_copy( p->layer_data[ i ].name, str );
//n_posix_debug_literal( " ini_write() : %s", n_paint_layer_data[ i ].name );

			BOOL visible = p->layer_data[ i ].visible;
			int  percent = p->layer_data[ i ].percent;
			int     blur = p->layer_data[ i ].blur;

			n_ini_key_add_str( ini, section, N_PAINT_LAYER_INI_NAME, str );

			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_VISIBLE, visible );
			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_PERCENT, percent );
			n_ini_key_add_int( ini, section, N_PAINT_LAYER_INI_BLUR   , blur    );
		}

		i--;
		if ( i < 0 ) { break; }
	}


	if ( is_read )
	{
		//
	} else {
		n_ini_section_add( ini, N_PAINT_LAYER_INI_SECTION );
		n_ini_key_add_int( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX , (int) p->layer_index );
		n_ini_key_add_int( ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_NUMBER, (int) p->layer_count );
	}


	return;
}




void
n_paint_layer_config_default( n_paint *p )
{

	n_type_int i = 0;
	n_posix_loop
	{
		p->layer_data[ i ].visible = n_posix_true;
		p->layer_data[ i ].percent = 100;
		p->layer_data[ i ].blend   = 1.0;
		p->layer_data[ i ].blur    =   0;

		i++;
		if ( i >= p->layer_count ) { break; }
	}


	return;
}




void
n_bmp_layer_free( n_paint *p )
{

	n_type_int i = 0;
	n_posix_loop
	{

		n_bmp_free( &p->layer_data[ i ].bmp_data );
		n_bmp_free( &p->layer_data[ i ].bmp_grab );

		i++;
		if ( i >= p->layer_count ) { break; }
	}


	return;
}

n_posix_bool
n_paint_layer_load( n_paint *p, const n_posix_char *cmdline )
{

	n_posix_char *name     = NULL;
	n_posix_char *name_ini = NULL;

	if ( n_posix_stat_is_dir( cmdline ) )
	{
//NSLog( @"Folder" );
		name     = n_string_path_carboncopy( cmdline );
		name_ini = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
	} else
	if ( n_string_path_ext_is_same_literal( ".INI\0\0", cmdline ) )
	{
//NSLog( @"INI" );
		name     = n_string_path_upperfolder_new( cmdline );
		name_ini = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
	}
//NSLog( @"%s : %s", name, name_ini );


	n_ini ini_sniffer; n_ini_zero( &ini_sniffer );
	n_posix_bool ret = n_txt_load_utf8( (void*) &ini_sniffer, name_ini );
//NSLog( @"%d", ret );

	if ( ret == n_posix_false )
	{
		ret = n_ini_section_chk( &ini_sniffer, N_PAINT_LAYER_INI_SECTION );
		if ( ret ) { ret = n_posix_false; } else { ret = n_posix_true; }
	}


//NSLog( @"%d", ret ); ret = TRUE;
	if ( ret == n_posix_false )
	{

		// [!] : prepare for newer data

		n_ini_free( &p->layer_ini );
		n_memory_copy( &ini_sniffer, &p->layer_ini, sizeof( n_ini ) );

		n_paint_layer_ini_read( &p->layer_ini );

		n_bmp_layer_free( p );
		n_memory_free( p->layer_data );

		p->filename = [NSString stringWithFormat:@"%s.lyr", name];

		n_txt_new( &p->layer_txt );


		// [!] : load

		p->layer_count = n_ini_value_int( &p->layer_ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_NUMBER, N_PAINT_LAYER_MAX );
		if ( p->layer_count < N_PAINT_LAYER_MAX ) { p->layer_count = N_PAINT_LAYER_MAX; }
//NSLog( @"Layer Cout : %d", p->layer_count );

		p->layer_data = n_memory_new( sizeof( n_paint_layer ) * p->layer_count );
		n_memory_zero( p->layer_data, sizeof( n_paint_layer ) * p->layer_count );

		n_type_int i = 0;
		n_posix_loop
		{

			n_posix_char str_oy[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_oy, i );

			n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%s.png", str_oy );
			n_posix_char *name_img = n_string_path_make_new( name, str );
//NSLog( @"%s", name_img );

			n_bmp_free_fast( &p->layer_data[ i ].bmp_data );
			n_png_png2bmp( name_img, &p->layer_data[ i ].bmp_data );

//n_posix_bool png_ret = n_png_png2bmp( name_img, &p->layer_data[ i ].bmp_data );
//NSLog( @"%d", png_ret );

			n_bmp_mac_color( &p->layer_data[ i ].bmp_data );

			n_string_path_free( name_img );


			n_posix_char sec[ N_PAINT_LAYER_CCH ]; n_posix_sprintf_literal( sec, "[%lld]", i );
			n_posix_char nam[ N_PAINT_LAYER_CCH ];
			n_ini_value_str( &p->layer_ini, sec, N_PAINT_LAYER_INI_NAME, N_STRING_EMPTY, nam, N_PAINT_LAYER_CCH );

			n_posix_char decor[ N_PAINT_LAYER_CCH * 2 ];
			n_posix_sprintf_literal( decor, "[B]%s", nam );

			n_txt_set( &p->layer_txt, i, decor );

			BOOL visible = n_ini_value_int( &p->layer_ini, sec, N_PAINT_LAYER_INI_VISIBLE, TRUE );
			int  percent = n_ini_value_int( &p->layer_ini, sec, N_PAINT_LAYER_INI_PERCENT,  100 );
			int     blur = n_ini_value_int( &p->layer_ini, sec, N_PAINT_LAYER_INI_BLUR   ,    0 );
//NSLog( @"%s : %s : %d %d %d", sec, nam, visible, percent, blur );

			p->layer_data[ i ].visible = visible;
			p->layer_data[ i ].percent = percent;
			p->layer_data[ i ].blend   = (n_type_real) percent * 0.01;
			p->layer_data[ i ].blur    = blur;


			i++;
			if ( i >= p->layer_count ) { break; }
		}

		p->layer_index = n_ini_value_int( &p->layer_ini, N_PAINT_LAYER_INI_SECTION, N_PAINT_LAYER_INI_INDEX, 0 );
		p->layer_index = n_posix_minmax( 0, p->layer_count - 1, p->layer_index );
//NSLog( @"%d", p->layer_index );

		p->pen_bmp_data = &p->layer_data[ p->layer_index ].bmp_data;
		p->pen_bmp_grab = &p->layer_data[ p->layer_index ].bmp_grab;


		p->layer_onoff = TRUE;

		p->layer_load_as_layer = TRUE;

	} else {

		p->layer_onoff = FALSE;

		p->layer_load_as_layer = FALSE;

		n_bmp_layer_free( p );
		n_memory_free( p->layer_data );

		p->pen_bmp_data = &p->bmp_data;
		p->pen_bmp_grab = &p->bmp_grab;

		n_ini_free( &ini_sniffer );

	}


	n_string_path_free( name     );
	n_string_path_free( name_ini );


	return ret;
}

void
n_paint_layer_save( n_paint *p, const n_posix_char *cmdline )
{

	n_posix_char *name = n_string_path_carboncopy( cmdline );


	if ( p->layer_load_as_layer )
	{

		//
	
	} else {

		p->layer_load_as_layer = TRUE;

		p->layer_onoff = n_posix_true;
		p->layer_count = N_PAINT_LAYER_MAX;

		//p->layer_first_index = 0;

		n_type_gfx bmpsx = N_BMP_SX( &p->bmp_data );
		n_type_gfx bmpsy = N_BMP_SY( &p->bmp_data );
//NSLog( @"%d : %d %d", p->layer_count, bmpsx, bmpsy );

		n_type_int i = 0;
		n_posix_loop
		{
			if ( i == 0 )
			{
				n_bmp_carboncopy( &p->bmp_data, &p->layer_data[ i ].bmp_data );
			} else {
				n_bmp_new_fast( &p->layer_data[ i ].bmp_data, bmpsx, bmpsy );
				n_bmp_flush( &p->layer_data[ i ].bmp_data, n_bmp_white_invisible );
			}

			i++;
			if ( i >= p->layer_count ) { break; }
		}

		n_paint_layer_config_default( p );

		i = 0;
		n_posix_loop
		{

			n_string_truncate( p->layer_data[ i ].name );

			if ( i == 0 )
			{
				n_posix_strcat( p->layer_data[ i ].name, n_posix_literal( "Background" ) );
			} else
			if ( i == ( p->layer_count - 1 ) )
			{
				n_posix_strcat( p->layer_data[ i ].name, n_posix_literal( "Top" ) );
			}

			i++;
			if ( i >= p->layer_count ) { break; }
		}


		n_ini_new( &p->layer_ini );

		n_paint_layer_ini_write( &p->layer_ini );

	}

	//n_paint_layer_name_exit();
	//n_paint_layer_name_init( name );


	n_posix_mkdir( name, 0777 );


	n_posix_char *ini_name = n_string_path_make_new( name, N_PAINT_LAYER_INI_FILENAME );
//n_posix_debug_literal( " %s ", ini_name );

	n_paint_layer_ini_write( &p->layer_ini );

	n_type_int i = 0;
	n_posix_loop
	{//break;

		n_bmp *bmp = &p->layer_data[ i ].bmp_data;

		n_bmp tmp; n_bmp_zero( &tmp ); n_bmp_carboncopy( bmp, &tmp );
//if ( NULL == N_BMP_PTR( &tmp ) ) { NSLog( @"NULL" ); }

		n_bmp_mac_color( &tmp );

		n_png png = n_png_template;

		n_posix_char *path = n_string_new( n_posix_strlen( name ) * 2 );
		n_posix_sprintf_literal( path, "%s/%lld.png", name, i );

		n_png_compress( &png, &tmp );
		n_png_save( &png, path );

		n_png_free( &png );

		n_bmp_free_fast( &tmp );

		i++;
		if ( i >= p->layer_count ) { break; }
	}


	n_ini_save( &p->layer_ini, ini_name );


	n_string_path_free( ini_name );
	n_string_path_free(     name );


	return;
}




u32
n_paint_layer_blur_pixel( n_bmp *bmp, n_type_gfx x, n_type_gfx y, int blur )
{

	u32 ret;


	if ( blur == 0 )
	{
		n_bmp_ptr_get( bmp, x, y, &ret );
	} else
	if ( blur == 1 )
	{
		ret = n_bmp_antialias_pixel( bmp, x, y, 1.0 );
	} else {
		ret = n_bmp_blur_pixel( bmp, x, y, blur, 1, 1.0 );
	}


	return ret;
}

u32
n_paint_layer_blur_pixel_fast( n_bmp *bmp, n_type_gfx x, n_type_gfx y, int blur )
{

	u32 ret;


	if ( blur == 0 )
	{
		n_bmp_ptr_get_fast( bmp, x, y, &ret );
	} else
	if ( blur == 1 )
	{
		ret = n_bmp_antialias_pixel( bmp, x, y, 1.0 );
	} else {
		ret = n_bmp_blur_pixel( bmp, x, y, blur, 1, 1.0 );
	}


	return ret;
}

// internal
void
n_paint_layer_grabber_pixel_get( n_bmp *grab, n_type_gfx tx, n_type_gfx ty, u32 picked, u32 *before, u32 *after, n_type_real blend, n_type_int i )
{

	// [!] : this module is based on n_paint_grabber_pixel_get()


	n_paint *p = n_paint_global.paint;


	u32 color_b, color_a;


	// [x] : don't use _fast()

	if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{

		color_b = n_bmp_antialias_pixel( p->pen_bmp_data, tx,ty, blend );
		color_a = picked;

	} else {

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


		n_type_gfx gx = tx - x;
		n_type_gfx gy = ty - y;

		if ( n_bmp_ptr_is_accessible( grab, gx,gy ) )
		{
			color_b = n_paint_layer_blur_pixel_fast( &p->layer_data[ i ].bmp_grab, gx, gy, p->layer_data[ i ].blur );
		} else {
			color_b = n_paint_layer_blur_pixel     ( &p->layer_data[ i ].bmp_data, tx, ty, p->layer_data[ i ].blur );
		}


		// [!] : Eraser

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( picked ) )
		{
			n_bmp_ptr_get( p->pen_bmp_data, tx,ty, &color_a );
		} else {
			color_a = picked;
		}

	}


	if ( before != NULL ) { (*before) = color_b; }
	if ( after  != NULL ) { (*after ) = color_a; }


	return;
}

u32
n_paint_layer_canvas_grabber_pixel( n_bmp *grab, n_type_gfx tx, n_type_gfx ty, u32 color, n_type_int i )
{

	// [!] : this module is based on n_paint_canvas_grabber_pixel()


	n_paint *p = n_paint_global.paint;

 
	u32 color_grab; n_paint_layer_grabber_pixel_get( grab, tx, ty, 0, &color_grab, NULL, 0.0, i );


	if ( p->grabber_per_pixel_alpha_onoff )
	{

		n_type_gfx x,y; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );

		n_bmp *data = &p->layer_data[ i ].bmp_data;

		n_type_gfx gx = tx - x;
		n_type_gfx gy = ty - y;

		if (
			( n_bmp_ptr_is_accessible( grab, gx,gy ) )
			&&
			( n_bmp_ptr_is_accessible( data, tx,ty ) )
		)
		{
			color_grab = n_bmp_composite_pixel_fast( grab, data, gx,gy, tx,ty, n_posix_false,n_posix_false, n_posix_true, n_posix_true, 0.0, NULL );
		}
	}


	if ( p->grabber_blend )
	{
		color_grab = n_bmp_blend_pixel( color_grab, color, p->grabber_blend_ratio );
	}


	return color_grab;
}

u32
n_bmp_layer_ptr_get( n_paint_layer *p, n_type_gfx tx, n_type_gfx ty, n_posix_bool use_color_bg, u32 color_bg, n_posix_bool is_ui )
{

	n_paint *paint = n_paint_global.paint;


	u32 ret = n_bmp_white_invisible;
//return n_bmp_rgb( 0,200,255 );

	if ( n_posix_false == n_bmp_ptr_is_accessible( &p[ 0 ].bmp_data, tx, ty ) ) { return ret; }


	u32 color_prev = n_paint_layer_blur_pixel_fast( &p[ 0 ].bmp_data, tx, ty, p[ 0 ].blur );

	if ( ( use_color_bg )&&( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( color_prev ) ) )
	{
		ret = color_prev = color_bg;
//return n_bmp_rgb( 0,200,255 );
	} else {
		ret = color_prev;
		if ( n_posix_false == p[ 0 ].visible ) { color_prev = color_bg; }
//return n_bmp_rgb( 255,0,200 );
	}


	n_type_int count = paint->layer_count;


	n_type_int i = 0;
	n_posix_loop
	{//break;

		if ( p[ i ].visible )
		{

			u32 color;

			if ( i == 0 )
			{
				color = color_prev;
			} else {
				color = n_paint_layer_blur_pixel_fast( &p[ i ].bmp_data, tx, ty, p[ i ].blur );
			}

			if ( ( is_ui )&&( paint->grabber_mode ) )
			{
				color = n_paint_layer_canvas_grabber_pixel( &paint->layer_data[ i ].bmp_grab, tx, ty, color, i );
//color = n_bmp_rgb( 0,200,255 );
			}

			ret = n_bmp_composite_pixel_postprocess( color_prev, color, n_bmp_a( color ), n_posix_true, n_posix_true, n_posix_true, 1.0 - p[ i ].blend, NULL );

//if ( n_win_is_input( VK_LBUTTON ) ) { ret = n_bmp_rgb( 0,200,255 ); }

			color_prev = ret;

		} else
		if (
			( paint->layer_whole_preview_onoff )
			&&
			( n_posix_false == n_paint_layer_is_locked( i ) )
		)
		{

			u32 color = n_paint_layer_blur_pixel_fast( &p[ i ].bmp_data, tx, ty, p[ i ].blur );
//color = n_bmp_rgb( 0,200,255 );

			ret = n_bmp_composite_pixel_postprocess( color_prev, color, n_bmp_a( color ), n_posix_true, n_posix_true, n_posix_true, 1.0 - p[ i ].blend, NULL );

			color_prev = ret;

		} else {

			ret = color_prev;

		}


		i++;
		if ( i >= count ) { break; }
	}


	return ret;
}


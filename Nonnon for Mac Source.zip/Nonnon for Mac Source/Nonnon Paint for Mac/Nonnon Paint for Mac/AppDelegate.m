//
//  AppDelegate.m
//  Nonnon Paint for Mac
//
//  Created by のんのん on 2022/09/13.
//

#import "AppDelegate.h"



#include "../../nonnon/neutral/bmp/all.c"
#include "../../nonnon/neutral/curico.c"
#include "../../nonnon/neutral/jpg.c"


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/draw.c"
#include "../../nonnon/mac/image.c"
#include "../../nonnon/mac/window.c"

#include "../../nonnon/mac/n_button.c"
#include "../../nonnon/mac/n_scrollbar.c"




n_posix_inline double
n_posix_min_double( double a, double b )
{
	return a < b ? a : b;
}

n_posix_inline double
n_posix_max_double( double a, double b )
{
	return a > b ? a : b;
}




void
n_paint_flush_reverse( n_bmp *bmp )
{

	n_type_gfx sx = N_BMP_SX( bmp );
	n_type_gfx sy = N_BMP_SY( bmp );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color; n_bmp_ptr_get_fast( bmp, x,y, &color );

		int a =       n_bmp_a( color );
		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		n_bmp_ptr_set_fast( bmp, x,y, n_bmp_argb( a,r,g,b ) );

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}




#define N_PAINT_ID_PENSIZE (  1 )
#define N_PAINT_ID_MIX     (  2 )
#define N_PAINT_ID_BOOST   (  3 )
#define N_PAINT_ID_AIR     (  4 )
#define N_PAINT_ID_ZOOM    (  5 )
#define N_PAINT_ID_COLOR_A (  6 )
#define N_PAINT_ID_COLOR_R (  7 )
#define N_PAINT_ID_COLOR_G (  8 )
#define N_PAINT_ID_COLOR_B (  9 )
#define N_PAINT_ID_BLEND   ( 10 )

#define N_PAINT_ID_RESIZER_ROTATE     ( 100 )
#define N_PAINT_ID_RESIZER_GAMMA      ( 101 )
#define N_PAINT_ID_RESIZER_COLORWHEEL ( 102 )
#define N_PAINT_ID_RESIZER_VIVIDNESS  ( 103 )
#define N_PAINT_ID_RESIZER_SHARPNESS  ( 104 )
#define N_PAINT_ID_RESIZER_CONTRAST   ( 105 )




n_posix_bool
n_paint_load( n_posix_char *path, n_bmp *bmp, n_curico *curico )
{

	if ( n_posix_stat_is_dir( path ) ) { return n_posix_true; }

	if (
		( n_png_png2bmp( path, bmp ) )
		&&
		( n_jpg_jpg2bmp( path, bmp ) )
		&&
		( n_curico_load( curico, bmp, path ) )
		&&
		( n_bmp_load( bmp, path ) )
	)
	{
		return n_posix_true;
	} else {
		n_bmp_mac_color( bmp );
	}

// [!] : for debugging
//n_bmp_scaler_big( bmp, 2 );


	return n_posix_false;
}




#include "canvas.c"




void
n_paint_layer_save_as_one( n_paint *p, n_bmp *bmp_ret )
{

	u32 color_bg = n_bmp_white_invisible;

	n_type_gfx bmpsx = N_BMP_SX( &p->layer_data[ 0 ].bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( &p->layer_data[ 0 ].bmp_data );

	n_bmp_new( bmp_ret, bmpsx, bmpsy );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		u32 color = n_bmp_layer_ptr_get( p->layer_data, x, y, n_posix_true, color_bg, n_posix_false );
		n_bmp_ptr_set_fast( bmp_ret, x, y, color );

		x++;
		if ( x >= bmpsx )
		{

			x = 0;

			y++;
			if ( y >= bmpsy ) { break; }
		}
	}


	return;
}

void
n_paint_save_carboncopy( n_bmp *bmp, n_bmp *bmp_ret )
{

	if ( n_paint_global.paint->layer_onoff )
	{
		n_paint *p = n_paint_global.paint;

		n_paint_layer_save_as_one( p, bmp_ret );
	} else {
		n_bmp_carboncopy( bmp, bmp_ret );
	}

	return;
}

n_posix_bool
n_paint_save( n_posix_char *path, n_bmp *bmp, n_curico *curico )
{

	n_posix_bool ret = n_posix_true;

//n_string_path_ext_mod( ".bmp\0\0", path );

	if ( n_string_path_ext_is_same_literal( ".BMP\0\0", path ) )
	{

		n_bmp tmp; n_paint_save_carboncopy( bmp, &tmp );

		n_bmp_mac_color( &tmp );
		ret = n_bmp_save( &tmp, path );

		n_bmp_free_fast( &tmp );

	} else
	if ( n_string_path_ext_is_same_literal( ".ICO\0\0", path ) )
	{

		n_bmp tmp; n_paint_save_carboncopy( bmp, &tmp );

		n_bmp_mac_color( &tmp );
		ret = n_curico_save( curico, &tmp, path );

		n_bmp_free_fast( &tmp );

	} else
	if ( n_string_path_ext_is_same_literal( ".CUR\0\0", path ) )
	{

		n_bmp tmp; n_paint_save_carboncopy( bmp, &tmp );

		n_bmp_mac_color( &tmp );
		ret = n_curico_save( curico, &tmp, path );

		n_bmp_free_fast( &tmp );

	} else
	if ( n_string_path_ext_is_same_literal( ".JPG\0\0", path ) )
	{

		n_bmp tmp; n_paint_save_carboncopy( bmp, &tmp );

		// [!] : crash

		//n_jpg_quality = 100;
		//ret = n_jpg_bmp2jpg( path, &tmp );

		n_bmp_flush_mirror( &tmp, N_BMP_MIRROR_UPSIDE_DOWN );

		ret = n_mac_image_save( &tmp, path, N_MAC_IMAGE_SAVE_JPG );

		n_bmp_free_fast( &tmp );

	} else
	if ( n_string_path_ext_is_same_literal( ".PNG\0\0", path ) )
	{

		n_bmp tmp; n_paint_save_carboncopy( bmp, &tmp );

		n_bmp_mac_color( &tmp );

		n_png png = n_png_template;

		ret  = n_png_compress( &png, &tmp );
		ret += n_png_save( &png, path );

		n_png_free( &png );

		n_bmp_free_fast( &tmp );

	} else
	if ( n_string_path_ext_is_same_literal( ".LYR\0\0", path ) )
	{
//NSLog( @"Layer" );

		n_paint *p = n_paint_global.paint;

		n_posix_char *str = n_string_path_carboncopy( path );
		n_string_path_ext_del( str );
//NSLog( @"%s", str );

		n_paint_layer_save( p, str );

		ret = n_posix_false;

		n_string_path_free( str );

	} else {
	
		// [!] : default

		n_bmp tmp; n_paint_save_carboncopy( bmp, &tmp );

		n_bmp_mac_color( &tmp );

		n_posix_char *default_name = n_string_path_carboncopy( path );
		n_string_path_ext_mod_literal( ".png\0\0", default_name );

		n_png png = n_png_template;

		ret  = n_png_compress( &png, &tmp );
		ret += n_png_save( &png, default_name );

		n_png_free( &png );

		n_string_path_free( default_name );

		n_bmp_free_fast( &tmp );

	}


	return ret;
}




@interface NonnonPaintColorPreview : NSView

@property u32 *color;

@end

@implementation NonnonPaintColorPreview

@synthesize color;

- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
		color = NULL;
	}

	return self;
}

-(void) drawRect:(NSRect) rect
{
	NSColor *clr = n_mac_argb2nscolor( n_bmp_color_mac( *color ) );
	n_mac_draw_roundrect( clr, rect, 4 );
}

@end




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonPaintCanvas *n_paint_canvas;
@property (weak) IBOutlet NSWindow          *n_toolwindow;

@property (weak) IBOutlet NSTextField     *n_size_value;
@property (weak) IBOutlet NonnonScrollbar *n_size_scrollbar;

@property (weak) IBOutlet NSTextField     *n_mix_value;
@property (weak) IBOutlet NonnonScrollbar *n_mix_scrollbar;

@property (weak) IBOutlet NSTextField     *n_boost_value;
@property (weak) IBOutlet NonnonScrollbar *n_boost_scrollbar;

@property (weak) IBOutlet NSTextField     *n_air_value;
@property (weak) IBOutlet NonnonScrollbar *n_air_scrollbar;

@property (weak) IBOutlet NSTextField     *n_zoom_value;
@property (weak) IBOutlet NonnonScrollbar *n_zoom_scrollbar;

@property (weak) IBOutlet NonnonPaintColorPreview *n_color_preview;

@property (weak) IBOutlet NSTextField     *n_color_a_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_a_scrollbar;

@property (weak) IBOutlet NSTextField     *n_color_r_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_r_scrollbar;

@property (weak) IBOutlet NSTextField     *n_color_g_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_g_scrollbar;

@property (weak) IBOutlet NSTextField     *n_color_b_value;
@property (weak) IBOutlet NonnonScrollbar *n_color_b_scrollbar;

@property (weak) IBOutlet NonnonButton    *n_button_0_0;
@property (weak) IBOutlet NonnonButton    *n_button_1_0;
@property (weak) IBOutlet NonnonButton    *n_button_2_0;
@property (weak) IBOutlet NonnonButton    *n_button_3_0;
@property (weak) IBOutlet NonnonButton    *n_button_4_0;

@property (weak) IBOutlet NonnonButton    *n_button_3_1;
@property (weak) IBOutlet NonnonButton    *n_button_4_1;

@property (weak) IBOutlet NonnonButton    *n_button_0_2;
@property (weak) IBOutlet NonnonButton    *n_button_1_2;
@property (weak) IBOutlet NonnonButton    *n_button_2_2;
@property (weak) IBOutlet NonnonButton    *n_button_4_2;

@property (weak) IBOutlet NSButton        *n_ppa_check;

@property (weak) IBOutlet NSTextField     *n_grabber_blend_label;
@property (weak) IBOutlet NSTextField     *n_grabber_blend_value;
@property (weak) IBOutlet NonnonScrollbar *n_grabber_blend_scrollbar;

@property (weak) IBOutlet NSTextField     *n_status1;
@property (weak) IBOutlet NSTextField     *n_status2;
@property (weak) IBOutlet NSTextField     *n_status3;


// Menu

@property (weak) IBOutlet NSMenuItem *n_menu_grid;
@property (weak) IBOutlet NSMenuItem *n_menu_pixelgrid;


// Resizer

@property (weak) IBOutlet NSWindow        *n_resizer_window;
@property (weak) IBOutlet NSComboBox      *n_resizer_combo;
@property (weak) IBOutlet NSTextField     *n_resizer_sx;
@property (weak) IBOutlet NSTextField     *n_resizer_sy;
@property (weak) IBOutlet NSTextField     *n_resizer_rotate_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_rotate_scrollbar;
@property (weak) IBOutlet NSComboBox      *n_resizer_color_combobox;

@property (weak) IBOutlet NSTextField     *n_resizer_gamma_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_gamma_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_colorwheel_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_colorwheel_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_vividness_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_vividness_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_sharpness_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_sharpness_scrollbar;

@property (weak) IBOutlet NSTextField     *n_resizer_contrast_value;
@property (weak) IBOutlet NonnonScrollbar *n_resizer_contrast_scrollbar;
@property (weak) IBOutlet NSButton        *n_resizer_button_go;

@end


@implementation AppDelegate {

	n_paint paint;

	// Resizer

	n_bmp resizer_bmp;
	int   resizer_rotate;
	int   resizer_gamma;
	BOOL  resizer_is_ok;

}




- (NSString*) n_paint_settings_read : (NSString*) nsstr_key
{

	CFStringRef key = (__bridge CFStringRef) nsstr_key;
	CFStringRef ret = CFPreferencesCopyAppValue( key, kCFPreferencesCurrentApplication );

	return (__bridge NSString*) ret;
}

- (void) n_paint_settings_write : (NSString*) nsstr_key value:(NSString*) nsstr_val
{

	CFStringRef key = (__bridge CFStringRef) nsstr_key;
	CFStringRef val = (__bridge CFStringRef) nsstr_val;

	CFPreferencesSetAppValue( key, val, kCFPreferencesCurrentApplication );

	return;
}

- (void) NonnonSettings : (BOOL) is_read
{

	NSString *str;

	if ( is_read )
	{

		str = [self n_paint_settings_read:@"pensize"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"5"]; }
		paint.pensize = [str intValue];

		str = [self n_paint_settings_read:@"mix"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"10"]; }
		paint.mix = [str intValue];

		str = [self n_paint_settings_read:@"boost"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"0"]; }
		paint.boost = [str intValue];

		str = [self n_paint_settings_read:@"air"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"0"]; }
		paint.air = [str intValue];


		str = [self n_paint_settings_read:@"a"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int a = [str intValue];

		str = [self n_paint_settings_read:@"r"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int r = [str intValue];

		str = [self n_paint_settings_read:@"g"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int g = [str intValue];

		str = [self n_paint_settings_read:@"b"];
		if ( str.length == 0 ) { str = [NSString stringWithFormat:@"255"]; }
		int b = [str intValue];

		paint.color = n_bmp_argb_mac( a,r,g,b );

	} else {

		str = [NSString stringWithFormat:@"%d", paint.pensize];
		[self n_paint_settings_write:@"pensize" value:str];

		str = [NSString stringWithFormat:@"%d", paint.mix];
		[self n_paint_settings_write:@"mix" value:str];

		str = [NSString stringWithFormat:@"%d", paint.boost];
		[self n_paint_settings_write:@"boost" value:str];

		str = [NSString stringWithFormat:@"%d", paint.air];
		[self n_paint_settings_write:@"air" value:str];


		str = [NSString stringWithFormat:@"%d", n_bmp_a( paint.color )];
		[self n_paint_settings_write:@"a" value:str];

		str = [NSString stringWithFormat:@"%d", n_bmp_b( paint.color )];
		[self n_paint_settings_write:@"r" value:str];

		str = [NSString stringWithFormat:@"%d", n_bmp_g( paint.color )];
		[self n_paint_settings_write:@"g" value:str];

		str = [NSString stringWithFormat:@"%d", n_bmp_r( paint.color )];
		[self n_paint_settings_write:@"b" value:str];

	}

}

- (void) NonnonDragAndDrop_dropped : (NSString*) nsstr
{

	if ( paint.readonly ) { return; }


	n_posix_char *str = n_mac_nsstring2str( nsstr );
//NSLog( @"%@", nsstr );

	if ( n_paint_layer_load( &paint, str ) )
	{
		if ( n_paint_load( str, &paint.bmp_data, &paint.curico ) )
		{
			//
		} else {
			paint.filename = nsstr;
			n_bmp_free( &paint.bmp_grab );

			[self NonnonPaintTitle];

			paint.scroll = NSMakePoint( 0, 0 );
			[self NonnonPaintResize];

			[self NonnonPaintResizerReset];
		}
	} else {
//NSLog( @"layer" );

		paint.    bmp_data =  paint.layer_data[ 0 ].bmp_data;
		paint.pen_bmp_data = &paint.layer_data[ paint.layer_index ].bmp_data;

		n_bmp_free( &paint.bmp_grab );


		n_posix_char *newname = n_string_alloccopy( n_posix_strlen( str ) * 2, str );
		n_string_path_ext_add( ".lyr\0\0", newname );
//NSLog( @"%s", newname );

		paint.filename = n_mac_str2nsstring( newname );
		
		n_string_path_free( newname );


		[self NonnonPaintTitle];

		paint.scroll = NSMakePoint( 0, 0 );
		[self NonnonPaintResize];

		[self NonnonPaintResizerReset];

	}
	
	[self NonnonPaintIconDisplay];

	n_string_free( str );

}




- (void) NonnonPaintTitle
{

	n_type_gfx bmpsx = N_BMP_SX( &paint.bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( &paint.bmp_data );

	NSString *title = [NSString stringWithFormat:@"%@ (%d x %d)", paint.filename, bmpsx, bmpsy];
	[_window setTitle:title];

}

- (void) NonnonPaintZoomUI
{

	if ( paint.zoom > 0 )
	{
		[_n_zoom_value setIntegerValue:paint.zoom];
	} else {
		NSString *nsstr = [NSString stringWithFormat:@"1/%d", paint.zoom * -1];
		[_n_zoom_value setStringValue:nsstr];
	}

	[_n_paint_canvas display];

}

- (void) NonnonPaintResize
{

	CGFloat sx = N_BMP_SX( &paint.bmp_data );
	CGFloat sy = N_BMP_SY( &paint.bmp_data );

	CGFloat dsx,dsy; n_mac_desktop_size( &dsx, &dsy );

	{
//NSLog( @"%0.2f %0.2f", dsx, dsy );

		sx = dsx * 0.6;
		sy = dsy * 0.6;

		paint.inner_sx = sx;
		paint.inner_sy = sy;

		paint.margin = n_posix_min_double( dsx, dsy ) * 0.1;

		sx += paint.margin;
		sy += paint.margin;
	}

	[self NonnonPaintZoomUI];

	[_window setContentSize:NSMakeSize( sx,sy )];
	n_mac_window_centering( _window );

	[_n_paint_canvas setFrame:NSMakeRect( 0,0,sx,sy )];
	[_n_paint_canvas display];

}

- (void) NonnonPaintColorSet
{

	int a = n_bmp_a( paint.color );
	int r = n_bmp_r( paint.color );
	int g = n_bmp_g( paint.color );
	int b = n_bmp_b( paint.color );
//NSLog( @"%d %d %d %d", a,r,g,b );

	[_n_color_a_value setIntegerValue:a];
	[_n_color_r_value setIntegerValue:b];
	[_n_color_g_value setIntegerValue:g];
	[_n_color_b_value setIntegerValue:r];

	[_n_color_a_scrollbar n_scrollbar_position_set:a redraw:YES];
	[_n_color_r_scrollbar n_scrollbar_position_set:b redraw:YES];
	[_n_color_g_scrollbar n_scrollbar_position_set:g redraw:YES];
	[_n_color_b_scrollbar n_scrollbar_position_set:r redraw:YES];


	[_n_color_preview display];

}

- (void) NonnonPaintGrabberUIOnOff:(BOOL)onoff
{

	NSColor *color;
	if ( onoff )
	{
		color = [NSColor textColor];
	} else {
		color = [NSColor secondarySelectedControlColor];
	}

	[_n_ppa_check            setEnabled  :onoff];
	[_n_grabber_blend_label  setTextColor:color];
	[_n_grabber_blend_value  setTextColor:color];
	[_n_grabber_blend_scrollbar n_scrollbar_enable:onoff redraw:YES];

}

- (void) NonnonPaintStatus
{
//return;

	n_posix_char str1[ 100 ];
	n_posix_char str2[ 100 ];
	n_posix_char str3[ 100 ];

	if ( paint.tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		n_posix_sprintf_literal( str1, "Pen" );

		NSPoint pt = [_n_paint_canvas n_paint_canvaspos];
		n_posix_sprintf_literal( str2, "X:%0.0f", pt.x );
		n_posix_sprintf_literal( str3, "Y:%0.0f", pt.y );

	} else
	if ( paint.tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		n_posix_sprintf_literal( str1, "Fill" );

		NSPoint pt = [_n_paint_canvas n_paint_canvaspos];
		n_posix_sprintf_literal( str2, "X:%0.0f", pt.x );
		n_posix_sprintf_literal( str3, "Y:%0.0f", pt.y );

	} else
	if ( paint.tooltype == N_PAINT_TOOL_TYPE_GRABBER )
	{

		if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			n_posix_sprintf_literal( str1, "Neutral" );
		} else
		if ( paint.grabber_mode == N_PAINT_GRABBER_SELECTING )
		{
			n_posix_sprintf_literal( str1, "Selecting" );
		} else
		if ( paint.grabber_mode == N_PAINT_GRABBER_DRAG_OK )
		{
			n_posix_sprintf_literal( str1, "Drag OK" );
		} else
		if ( paint.grabber_mode == N_PAINT_GRABBER_DRAGGING )
		{
			n_posix_sprintf_literal( str1, "Dragging" );
		} else {
			n_posix_sprintf_literal( str1, "N/A" );
		}


		n_type_gfx x,y,sx,sy,fx,fy;

		if ( paint.grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			x = y = sx = sy = fx = fy = 0;
		} else {
			n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );
		}

		n_posix_sprintf_literal( str2, "X:%d Y:%d", x,y );
		n_posix_sprintf_literal( str3, "%d x %d", sx,sy );

	}

	[_n_status1 setStringValue:n_mac_str2nsstring( str1 )];
	[_n_status2 setStringValue:n_mac_str2nsstring( str2 )];
	[_n_status3 setStringValue:n_mac_str2nsstring( str3 )];


	return;
}

- (void) NonnonPaintResizerReset
{

	[_n_resizer_combo selectItemAtIndex:2];


	n_type_gfx bmpsx;
	n_type_gfx bmpsy;

//NSLog( @"%d", n_paint_global.paint->grabber_mode );
	if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		bmpsx = N_BMP_SX( paint.pen_bmp_data );
		bmpsy = N_BMP_SY( paint.pen_bmp_data );
	} else {
		bmpsx = N_BMP_SX( paint.pen_bmp_grab );
		bmpsy = N_BMP_SY( paint.pen_bmp_grab );
	}

	NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
	formatter.hasThousandSeparators = NO;

	[_n_resizer_sx setFormatter:formatter];
	[_n_resizer_sy setFormatter:formatter];

	[_n_resizer_sx setStringValue:[NSString stringWithFormat:@"%d", bmpsx]];
	[_n_resizer_sy setStringValue:[NSString stringWithFormat:@"%d", bmpsy]];


	resizer_rotate = 360;

	_n_resizer_rotate_scrollbar.delegate = self;
	[_n_resizer_rotate_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_ROTATE step:1 page:10 max:720 pos:resizer_rotate redraw:n_posix_true];

	[self NonnonScrollbarMessage:N_PAINT_ID_RESIZER_ROTATE value:resizer_rotate];


	[_n_resizer_color_combobox selectItemAtIndex:0];

	resizer_gamma = 10;
	_n_resizer_gamma_scrollbar.delegate = self;
	[_n_resizer_gamma_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_GAMMA step:1 page:5 max:20 pos:resizer_gamma redraw:n_posix_true];
	[_n_resizer_gamma_value setIntegerValue:resizer_gamma];

	[self NonnonScrollbarMessage:N_PAINT_ID_RESIZER_GAMMA value:resizer_gamma];

	_n_resizer_colorwheel_scrollbar.delegate = self;
	[_n_resizer_colorwheel_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_COLORWHEEL step:1 page:10 max:256 pos:128 redraw:n_posix_true];
	[_n_resizer_colorwheel_value setIntegerValue:0];

	_n_resizer_vividness_scrollbar.delegate = self;
	[_n_resizer_vividness_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_VIVIDNESS step:1 page:10 max:200 pos:100 redraw:n_posix_true];
	[_n_resizer_vividness_value setIntegerValue:0];

	_n_resizer_sharpness_scrollbar.delegate = self;
	[_n_resizer_sharpness_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_SHARPNESS step:1 page:10 max:200 pos:100 redraw:n_posix_true];
	[_n_resizer_sharpness_value setIntegerValue:0];

	_n_resizer_contrast_scrollbar.delegate = self;
	[_n_resizer_contrast_scrollbar n_scrollbar_parameter:N_PAINT_ID_RESIZER_CONTRAST step:1 page:10 max:100 pos:0 redraw:n_posix_true];
	[_n_resizer_contrast_value setIntegerValue:0];


	n_paint_global.paint->grabber_rect_resizer = n_paint_global.paint->grabber_rect;


	resizer_is_ok = FALSE;


	return;
}

- (void) NonnonPaintIconSet:(NSString*) rc_name button:(NonnonButton*)button
{

	n_bmp bmp_icon; n_bmp_zero( &bmp_icon );

	n_mac_image_rc_load_bmp( rc_name, &bmp_icon );

	n_mac_button_system_themed( &bmp_icon );

	[button n_icon_set:&bmp_icon];

}

- (void) NonnonPaintIconDisplay
{

	n_posix_char *path = n_mac_nsstring2str( paint.filename );

	if ( n_string_path_ext_is_same_literal( ".BMP\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save"     button:_n_button_4_1];
	} else
	if ( n_string_path_ext_is_same_literal( ".ICO\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/ico" button:_n_button_4_1];
	} else
	if ( n_string_path_ext_is_same_literal( ".CUR\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/cur" button:_n_button_4_1];
	} else
	if ( n_string_path_ext_is_same_literal( ".JPG\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/jpg" button:_n_button_4_1];
	} else
	if ( n_string_path_ext_is_same_literal( ".PNG\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/png" button:_n_button_4_1];
	} else
	if ( n_string_path_ext_is_same_literal( ".LYR\0\0", path ) )
	{
		[self NonnonPaintIconSet:@"rc/save/lyr" button:_n_button_4_1];
	}

	[_n_button_4_1 display];

}


- (void)awakeFromNib
{

	// [!] : Global

	n_bmp_safemode = n_posix_false;


	// [!] : Instance

	n_paint_zero( &paint );

	paint.scroller_size = 12;


	// [!] : Resources

	paint.cursor_arrow = [NSCursor arrowCursor];

	{
		n_bmp bmp; n_bmp_zero( &bmp );
		n_mac_image_rc_load_bmp( @"rc/cursor/pen", &bmp );

		NSImage *img = n_mac_image_nbmp2nsimage( &bmp );

		int hotspot_x = N_BMP_SX( &bmp ) / 2;
		int hotspot_y = N_BMP_SY( &bmp ) / 2;

		paint.cursor_pen_off = [[NSCursor alloc] initWithImage:img hotSpot:NSMakePoint( hotspot_x, hotspot_y )];

		//n_bmp_free_fast( &bmp );
	}

	{
		n_bmp bmp; n_bmp_zero( &bmp );
		n_mac_image_rc_load_bmp( @"rc/cursor/pen_on", &bmp );

		NSImage *img = n_mac_image_nbmp2nsimage( &bmp );

		int hotspot_x = N_BMP_SX( &bmp ) / 2;
		int hotspot_y = N_BMP_SY( &bmp ) / 2;

		paint.cursor_pen_on = [[NSCursor alloc] initWithImage:img hotSpot:NSMakePoint( hotspot_x, hotspot_y )];

		//n_bmp_free_fast( &bmp );
	}


	// [!] : Tool Window : Settings

	paint.color    = n_bmp_rgb_mac( 0,200,255 );
	paint.pensize  = 8;
	paint.mix      = 10;
	paint.boost    = 0;
	paint.air      = 0;

	[self NonnonSettings:YES];


	// [!] : Tool Window

	paint.tooltype = N_PAINT_TOOL_TYPE_PEN;
	//paint.tooltype = N_PAINT_TOOL_TYPE_FILL;
	//paint.tooltype = N_PAINT_TOOL_TYPE_GRABBER;

	paint.zoom     = 1;
	paint.scroll   = NSMakePoint( 0, 0 );

	_n_size_scrollbar.delegate = self;
	[_n_size_scrollbar  n_scrollbar_parameter:N_PAINT_ID_PENSIZE step:1 page:10 max:100 pos:paint.pensize redraw:n_posix_true];
	[_n_size_value  setIntegerValue:paint.pensize];

	_n_mix_scrollbar.delegate = self;
	[_n_mix_scrollbar   n_scrollbar_parameter:N_PAINT_ID_MIX     step:1 page:10 max:100 pos:paint.mix     redraw:n_posix_true];
	[_n_mix_value  setIntegerValue:paint.mix];

	_n_boost_scrollbar.delegate = self;
	[_n_boost_scrollbar n_scrollbar_parameter:N_PAINT_ID_BOOST   step:1 page:10 max:100 pos:paint.boost   redraw:n_posix_true];
	[_n_boost_value  setIntegerValue:paint.boost];

	_n_air_scrollbar.delegate = self;
	[_n_air_scrollbar   n_scrollbar_parameter:N_PAINT_ID_AIR     step:1 page:10 max:100 pos:paint.air     redraw:n_posix_true];
	[_n_air_value  setIntegerValue:paint.air];

	_n_zoom_scrollbar.delegate = self;
	[_n_zoom_scrollbar  n_scrollbar_parameter:N_PAINT_ID_ZOOM    step:1 page:10 max:100 pos:paint.zoom+50 redraw:n_posix_true];
	[_n_zoom_value  setIntegerValue:paint.zoom];


	_n_color_preview.color = &paint.color;

	[self NonnonPaintColorSet];

	_n_color_a_scrollbar.delegate = self;
	_n_color_r_scrollbar.delegate = self;
	_n_color_g_scrollbar.delegate = self;
	_n_color_b_scrollbar.delegate = self;

	[_n_color_a_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_A step:1 page:10 max:255 pos:n_bmp_a( paint.color ) redraw:n_posix_true];
	[_n_color_r_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_R step:1 page:10 max:255 pos:n_bmp_b( paint.color ) redraw:n_posix_true];
	[_n_color_g_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_G step:1 page:10 max:255 pos:n_bmp_g( paint.color ) redraw:n_posix_true];
	[_n_color_b_scrollbar n_scrollbar_parameter:N_PAINT_ID_COLOR_B step:1 page:10 max:255 pos:n_bmp_r( paint.color ) redraw:n_posix_true];

	[_n_color_r_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 255,0,0 )];
	[_n_color_g_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,255,0 )];
	[_n_color_b_scrollbar n_scrollbar_gradient:nil from:n_bmp_black to:n_bmp_rgb_mac( 0,0,255 )];


	{
		[self NonnonPaintIconSet:@"rc/small" button:_n_button_0_0];

		[_n_button_0_0 n_enable:TRUE];

		[_n_button_0_0 n_border:TRUE];
		[_n_button_0_0 n_direct_click:YES];

		_n_button_0_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/large" button:_n_button_1_0];

		[_n_button_1_0 n_enable:TRUE];
		
		[_n_button_1_0 n_border:TRUE];
		[_n_button_1_0 n_direct_click:YES];

		_n_button_1_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/mirror" button:_n_button_2_0];

		[_n_button_2_0 n_enable:TRUE];

		[_n_button_2_0 n_border:TRUE];
		[_n_button_2_0 n_direct_click:YES];

		_n_button_2_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/rotate_left" button:_n_button_3_0];

		[_n_button_3_0 n_enable:TRUE];

		[_n_button_3_0 n_border:TRUE];
		[_n_button_3_0 n_direct_click:YES];

		_n_button_3_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/rotate_right" button:_n_button_4_0];

		[_n_button_4_0 n_enable:TRUE];

		[_n_button_4_0 n_border:TRUE];
		[_n_button_4_0 n_direct_click:YES];

		_n_button_4_0.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/new" button:_n_button_3_1];

		[_n_button_3_1 n_enable:TRUE];

		[_n_button_3_1 n_border:TRUE];
		[_n_button_3_1 n_direct_click:YES];

		_n_button_3_1.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/save/png" button:_n_button_4_1];

		[_n_button_4_1 n_enable:TRUE];

		[_n_button_4_1 n_border:TRUE];
		[_n_button_4_1 n_direct_click:YES];

		_n_button_4_1.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/pen" button:_n_button_0_2];

		[_n_button_0_2 n_enable:TRUE];

		[_n_button_0_2 n_border:TRUE];
		[_n_button_0_2 n_direct_click:YES];

		[_n_button_0_2 n_press:TRUE];

		_n_button_0_2.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/brush" button:_n_button_1_2];

		[_n_button_1_2 n_enable:TRUE];

		[_n_button_1_2 n_border:TRUE];
		[_n_button_1_2 n_direct_click:YES];

		_n_button_1_2.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/grabber" button:_n_button_2_2];

		[_n_button_2_2 n_enable:TRUE];

		[_n_button_2_2 n_border:TRUE];
		[_n_button_2_2 n_direct_click:YES];

		_n_button_2_2.delegate = self;
	}

	{
		[self NonnonPaintIconSet:@"rc/color" button:_n_button_4_2];

		[_n_button_4_2 n_enable:TRUE];

		[_n_button_4_2 n_border:TRUE];
		[_n_button_4_2 n_direct_click:YES];

		_n_button_4_2.delegate = self;
	}

	_n_grabber_blend_scrollbar.delegate = self;
	[_n_grabber_blend_scrollbar n_scrollbar_parameter:N_PAINT_ID_BLEND step:1 page:10 max:100 pos:paint.grabber_blend redraw:n_posix_true];
	[_n_grabber_blend_value setIntegerValue:paint.grabber_blend];

	[self NonnonPaintGrabberUIOnOff:FALSE];


	{
		NSArray      *paths   = NSSearchPathForDirectoriesInDomains( NSDesktopDirectory, NSUserDomainMask, YES );
		NSString     *desktop = [paths objectAtIndex:0];
		n_posix_char  tmpname[ 100 ]; n_string_path_tmpname( tmpname );

		paint.filename = [NSString stringWithFormat:@"%@/%s.png", desktop, tmpname];
//NSLog( @"%@", path );
	}

	n_bmp_new_fast( &paint.bmp_data, 512,512 );
	n_bmp_flush( &paint.bmp_data, n_bmp_white );

	paint.pen_bmp_data = &paint.bmp_data;
	paint.pen_bmp_grab = &paint.bmp_grab;

	_n_paint_canvas.delegate = self;
	_n_paint_canvas.paint    = &paint;

	[self NonnonPaintResize];
	[self NonnonPaintStatus];
	[self NonnonPaintTitle];


	// Resizer

	n_bmp_zero( &resizer_bmp );

	[self NonnonPaintResizerReset];


	// Layer

	paint.layer_onoff = false;
	paint.layer_count = N_PAINT_LAYER_MAX;

	paint.layer_data  = n_memory_new( sizeof( n_paint_layer ) * paint.layer_count );
	n_memory_zero( paint.layer_data, sizeof( n_paint_layer ) * paint.layer_count );

 
 	// Window

 	[_window setAcceptsMouseMovedEvents:YES];

	// [Needed] : set every time
	[_window addChildWindow:_n_toolwindow     ordered:NSWindowAbove];
	[_window addChildWindow:_n_resizer_window ordered:NSWindowAbove];

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

	[_window makeKeyWindow];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[self NonnonSettings:NO];

		[NSApp terminate:self];
	} else
	if ( window == _n_resizer_window )
	{
		paint.readonly = FALSE;

		n_mac_window_show( _n_toolwindow     );
		n_mac_window_hide( _n_resizer_window );

		// [Needed] : set every time
		[_window addChildWindow:_n_toolwindow ordered:NSWindowAbove];

		if ( resizer_is_ok == FALSE )
		{
			n_paint_global.paint->grabber_rect = n_paint_global.paint->grabber_rect_resizer;
		}

		[_n_paint_canvas display];
	}

}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application

//NSRect rect_window = [_window frame];
//NSLog( @"Window : %f %f", NSWidth( rect_window ), NSHeight( rect_window ) );

//NSRect rect_canvas = [_n_paint_canvas frame];
//NSLog( @"Canvas : %f %f", NSWidth( rect_canvas ), NSHeight( rect_canvas ) );

	n_mac_window_centering( _window );
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}




- (IBAction)n_menu_grid_method:(NSMenuItem *)sender {

	NSControlStateValue s = [_n_menu_grid state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_grid setState:NSControlStateValueOn];
		paint.grid_onoff = TRUE;
	} else {
		[_n_menu_grid setState:NSControlStateValueOff];
		paint.grid_onoff = FALSE;
	}

	[_n_paint_canvas display];

}

- (IBAction)n_menu_pixelgrid_method:(id)sender {

	NSControlStateValue s = [_n_menu_pixelgrid state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_grid setState:NSControlStateValueOn];
		paint.pixel_grid_onoff = TRUE;
	} else {
		[_n_menu_grid setState:NSControlStateValueOff];
		paint.pixel_grid_onoff = FALSE;
	}

	[_n_paint_canvas display];

}




- (void) NonnonScrollbarMessage:(int) id  value:(int) v
{

	if ( id == N_PAINT_ID_PENSIZE )
	{
		paint.pensize = v;
		[_n_size_value setIntegerValue:paint.pensize];
	} else
	if ( id == N_PAINT_ID_MIX )
	{
		paint.mix = v;
		[_n_mix_value setIntegerValue:paint.mix];
	} else
	if ( id == N_PAINT_ID_BOOST )
	{
		paint.boost = v;
		[_n_boost_value setIntegerValue:paint.boost];
	} else
	if ( id == N_PAINT_ID_AIR )
	{
		paint.air = v;
		[_n_air_value setIntegerValue:paint.air];
	} else
	if ( id == N_PAINT_ID_ZOOM )
	{
		static int prev = 1;

		paint.zoom = v - 50;

		if ( ( paint.zoom == 0 )||( paint.zoom == -1 ) )
		{
			if ( prev > 0 ) { paint.zoom = -2; } else { paint.zoom = 1; }
		}

		prev = paint.zoom;

		[self NonnonPaintZoomUI];
	} else
	if ( id == N_PAINT_ID_COLOR_A )
	{
		[_n_color_a_value setIntegerValue:v];

		int a = v;
		int r = n_bmp_b( paint.color );
		int g = n_bmp_g( paint.color );
		int b = n_bmp_r( paint.color );

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_COLOR_R )
	{
		[_n_color_r_value setIntegerValue:v];

		int a = n_bmp_a( paint.color );
		int r = v;
		int g = n_bmp_g( paint.color );
		int b = n_bmp_r( paint.color );

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_COLOR_G )
	{
		[_n_color_g_value setIntegerValue:v];

		int a = n_bmp_a( paint.color );
		int r = n_bmp_b( paint.color );
		int g = v;
		int b = n_bmp_r( paint.color );

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_COLOR_B )
	{
		[_n_color_b_value setIntegerValue:v];

		int a = n_bmp_a( paint.color );
		int r = n_bmp_b( paint.color );
		int g = n_bmp_g( paint.color );
		int b = v;

		paint.color = n_bmp_argb_mac( a,r,g,b );

		[_n_color_preview display];
	} else
	if ( id == N_PAINT_ID_BLEND )
	{
		paint.grabber_blend = v;
		[_n_grabber_blend_value setIntegerValue:paint.grabber_blend];

		paint.grabber_blend_ratio = (double) paint.grabber_blend * 0.01;

		[_n_paint_canvas display];
	} else
	if ( id == N_PAINT_ID_RESIZER_ROTATE )
	{
		resizer_rotate = v;

		NSString *nsstr = [NSString stringWithFormat:@"%d°", resizer_rotate-360];
		[_n_resizer_rotate_value setStringValue:nsstr];

		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_GAMMA )
	{
		resizer_gamma = v;

		NSString *nsstr = [NSString stringWithFormat:@"%0.1f", (double) ( resizer_gamma - 10 ) * 0.1];
		[_n_resizer_gamma_value setStringValue:nsstr];

		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_COLORWHEEL )
	{
		[_n_resizer_colorwheel_value setIntegerValue:v - 128];
		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_VIVIDNESS )
	{
		[_n_resizer_vividness_value setIntegerValue:v - 100];
		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_SHARPNESS )
	{
		[_n_resizer_sharpness_value setIntegerValue:v - 100];
		[self n_resizer_go];
	} else
	if ( id == N_PAINT_ID_RESIZER_CONTRAST )
	{
		[_n_resizer_contrast_value setIntegerValue:v];
		[self n_resizer_go];
	}// else

}




- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog(@"mouseUp");

	if ( n_mac_window_is_hovered( _n_button_0_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_SCALE_LIL );
		[_n_paint_canvas display];
		[self NonnonPaintTitle];
	} else
	if ( n_mac_window_is_hovered( _n_button_1_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_SCALE_BIG );
		[_n_paint_canvas display];
		[self NonnonPaintTitle];
	} else
	if ( n_mac_window_is_hovered( _n_button_2_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_MIRROR );
		[_n_paint_canvas display];
	} else
	if ( n_mac_window_is_hovered( _n_button_3_0 ) )
	{
		n_paint_grabber_filter( N_PAINT_FILTER_ROTATE_L );
		[_n_paint_canvas display];
		[self NonnonPaintTitle];
	} else
	if ( n_mac_window_is_hovered( _n_button_4_0 ) )
	{[self NonnonPaintTitle];
		n_paint_grabber_filter( N_PAINT_FILTER_ROTATE_R );
		[_n_paint_canvas display];
		[self NonnonPaintTitle];
	} else

	if ( n_mac_window_is_hovered( _n_button_3_1 ) )
	{

		if ( paint.readonly )
		{
			paint.readonly = FALSE;

			n_mac_window_show( _n_toolwindow     );
			n_mac_window_hide( _n_resizer_window );

			// [Needed] : set every time
			[_window addChildWindow:_n_toolwindow     ordered:NSWindowAbove];
		} else {
			paint.readonly =  TRUE;

			[self NonnonPaintResizerReset];

			n_mac_window_hide( _n_toolwindow     );
			n_mac_window_show( _n_resizer_window );

			// [Needed] : set every time
			[_window addChildWindow:_n_resizer_window ordered:NSWindowAbove];
		}
//NSLog( @"%d", paint.readonly );

	} else
	if ( n_mac_window_is_hovered( _n_button_4_1 ) )
	{

		n_posix_char *path = n_mac_nsstring2str( paint.filename );

		if ( n_paint_save( path, &paint.bmp_data, &paint.curico ) )
		{
			// [!] : when error

			// [x] : crash without "App Sandbox" "User Selected File"

			NSString *name = [paint.filename lastPathComponent];

			NSSavePanel *panel = [NSSavePanel savePanel];
   			[panel setNameFieldStringValue:name];
			[panel beginSheetModalForWindow:_window completionHandler:^(NSInteger result)
			{
				if ( result == NSModalResponseOK )
				{
					NSString     *nsstring = [[panel URL] path];
					n_posix_char *str      = n_mac_nsstring2str( nsstring );
//NSLog( @"Saved : %s", str );
					n_paint_save( str, &self->paint.bmp_data, &self->paint.curico );

					self->paint.filename = nsstring;
					[self NonnonPaintTitle];

					n_string_free( str );
				}

			}];

		}

		n_string_free( path );

	} else

	if ( n_mac_window_is_hovered( _n_button_0_2 ) )
	{
		if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			[self NonnonPaintIconSet:@"rc/grabber" button:_n_button_2_2];

			[self NonnonPaintGrabberUIOnOff:FALSE];
		}

		paint.tooltype = N_PAINT_TOOL_TYPE_PEN;

		[_n_button_0_2 n_press: TRUE]; [_n_button_0_2 display];
		[_n_button_1_2 n_press:FALSE]; [_n_button_1_2 display];
		[_n_button_2_2 n_press:FALSE]; [_n_button_2_2 display];

		[self NonnonPaintStatus];

		[_window makeKeyWindow];
		[_n_paint_canvas resetCursorRects];
	} else
	if ( n_mac_window_is_hovered( _n_button_1_2 ) )
	{
		if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
			[self NonnonPaintIconSet:@"rc/grabber" button:_n_button_2_2];

			[self NonnonPaintGrabberUIOnOff:FALSE];
		}

		paint.tooltype = N_PAINT_TOOL_TYPE_FILL;

		[_n_button_0_2 n_press:FALSE]; [_n_button_0_2 display];
		[_n_button_1_2 n_press: TRUE]; [_n_button_1_2 display];
		[_n_button_2_2 n_press:FALSE]; [_n_button_2_2 display];

		[self NonnonPaintStatus];

		[_window makeKeyWindow];
		[_n_paint_canvas resetCursorRects];
	} else
	if ( n_mac_window_is_hovered( _n_button_2_2 ) )
	{
		[self NonnonPaintIconSet:@"rc/grabber_close" button:_n_button_2_2];

		[self NonnonPaintGrabberUIOnOff:TRUE];

		if ( paint.tooltype == N_PAINT_TOOL_TYPE_GRABBER )
		{
			n_paint_grabber_reset();
		}

		paint.tooltype = N_PAINT_TOOL_TYPE_GRABBER;

		[_n_button_0_2 n_press:FALSE]; [_n_button_0_2 display];
		[_n_button_1_2 n_press:FALSE]; [_n_button_1_2 display];
		[_n_button_2_2 n_press: TRUE]; [_n_button_2_2 display];

		[self NonnonPaintStatus];

		[_window makeKeyWindow];
		[_n_paint_canvas resetCursorRects];
	} else
	if ( n_mac_window_is_hovered( _n_button_4_2 ) )
	{
//NSLog( @"!" );
		NSColorPanel *cp = [NSColorPanel sharedColorPanel];
		[cp setTarget:self];
		cp.showsAlpha = YES;
		[cp orderFront:nil];
		[cp setAction:@selector(colorUpdate:)];

	} //else

}

- (void) rightMouseUp:(NSEvent*) theEvent
{
//NSLog(@"rightMouseUp");

	if ( n_mac_window_is_hovered( _n_button_4_1 ) )
	{

		n_posix_char *path = n_mac_nsstring2str( paint.filename );

		if ( n_string_path_ext_is_same_literal( ".BMP\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".ico\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".ICO\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".cur\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".CUR\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".jpg\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".JPG\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".png\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".PNG\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".lyr\0\0", path );
		} else
		if ( n_string_path_ext_is_same_literal( ".LYR\0\0", path ) )
		{
			n_string_path_ext_mod_literal( ".bmp\0\0", path );
		}

		[self NonnonPaintIconDisplay];

		paint.filename = n_mac_str2nsstring( path );
		n_string_path_free( path );

		[self NonnonPaintTitle];

	}

}

- (void)colorUpdate:(NSColorPanel*)colorPanel{
 
	NSColor *nscolor = colorPanel.color;

	paint.color = n_bmp_color_mac( n_mac_nscolor2argb( nscolor ) );

	[self NonnonPaintColorSet];

}

- (IBAction)n_ppa_method:(NSButton *)sender {

	if ( sender.state == NSControlStateValueOff )
	{
		paint.grabber_per_pixel_alpha_onoff = n_posix_false;
	} else
	if ( sender.state == NSControlStateValueOn )
	{
		paint.grabber_per_pixel_alpha_onoff = n_posix_true;
	}

	[_n_paint_canvas display];

}




// Resizer

- (void) n_resizer_go
{
//return;

	n_bmp_free( &resizer_bmp );
	if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		n_bmp_carboncopy( paint.pen_bmp_data, &resizer_bmp );
	} else {
		n_bmp_carboncopy( paint.pen_bmp_grab, &resizer_bmp );
	}


	n_type_gfx sx = (n_type_gfx) [_n_resizer_sx integerValue];
	n_type_gfx sy = (n_type_gfx) [_n_resizer_sy integerValue];

	int index = (int) [_n_resizer_combo indexOfSelectedItem];

	if ( index == 0 )
	{
		n_bmp_resizer( &resizer_bmp, sx,sy, n_bmp_white, N_BMP_RESIZER_NORMAL );
	} else
	if ( index == 1 )
	{
		n_bmp_resizer( &resizer_bmp, sx,sy, n_bmp_white, N_BMP_RESIZER_TILE );
	} else
	if ( index == 2 )
	{
		n_bmp_resizer( &resizer_bmp, sx,sy, n_bmp_white, N_BMP_RESIZER_CENTER );
	} else
	if ( index == 3 )
	{
		n_bmp_resampler
		(
			&resizer_bmp,
			(n_type_real) sx / N_BMP_SX( &resizer_bmp ),
			(n_type_real) sy / N_BMP_SY( &resizer_bmp )
		);
	} else
	if ( index == 4 )
	{
		n_type_real ratio = (n_type_real) sx / N_BMP_SX( &resizer_bmp );
		n_bmp_resampler( &resizer_bmp, ratio, ratio );
	} else
	if ( index == 5 )
	{
		n_type_real ratio = (n_type_real) sy / N_BMP_SY( &resizer_bmp );
		n_bmp_resampler( &resizer_bmp, ratio, ratio );
	} else
	if ( index == 6 )
	{
		n_bmp_scaler_big_pixelart( &resizer_bmp, 2 );
	} else
	if ( index == 7 )
	{
		n_bmp_scaler_big_pixelart( &resizer_bmp, 3 );
	} else
	if ( index == 8 )
	{
		n_bmp_scaler_big( &resizer_bmp, 2 );
		n_bmp_scaler_big( &resizer_bmp, 2 );

		n_bmp_flush_antialias( &resizer_bmp, 1.0 );
		n_bmp_flush_antialias( &resizer_bmp, 1.0 );
		n_bmp_flush_antialias( &resizer_bmp, 1.0 );
		n_bmp_flush_antialias( &resizer_bmp, 1.0 );

		n_bmp_scaler_lil( &resizer_bmp, 2 );

		n_bmp_flush_sharpen( &resizer_bmp, 0.5 );
	}// else

	n_bmp_matrix_rotate( &resizer_bmp, resizer_rotate, n_bmp_white_invisible, n_posix_true );


	index = (int) [_n_resizer_color_combobox indexOfSelectedItem];
	if ( index == 0 )
	{
		// [!] : "None"
	} else
	if ( index == 1 )
	{
		n_bmp_flush_grayscale( &resizer_bmp );
	} else
	if ( index == 2 )
	{
		n_bmp_flush_monochrome( &resizer_bmp );
	} else
	if ( index == 3 )
	{
		n_paint_flush_reverse( &resizer_bmp );
	}// else


	{ // Gamma

		// [!] : shortcut for performance

		n_type_real g = (n_type_real) resizer_gamma / 10.0;

		if ( g == 0.0 ) { n_bmp_flush( &resizer_bmp, n_bmp_black ); } else
		if ( g == 2.0 ) { n_bmp_flush( &resizer_bmp, n_bmp_white ); } else
		if ( g != 1.0 ) { n_bmp_flush_gamma( &resizer_bmp, g );     }

	}

	//if ( 0 )
	{ // Color Wheel & Vividness

		int clrwh = (int) [_n_resizer_colorwheel_scrollbar n_scrollbar_position_get];
		int vivid = (int) [_n_resizer_vividness_scrollbar  n_scrollbar_position_get];

		int h = clrwh - 128;
		int s = vivid - 100;
		int l = 0;

//NSLog( @"%d %d : %d %d : %f", clrwh, vivid, h, s, _n_resizer_colorwheel_scrollbar.scr.unit_pos );

		n_bmp_flush_tweaker_hsl( &resizer_bmp, h, s, l );

	}

	//if ( 0 )
	{ // Sharpness

		int s = (int) [_n_resizer_sharpness_scrollbar n_scrollbar_position_get];

		s = s - 100;

		if ( s > 0 )
		{
			n_bmp_flush_sharpen  ( &resizer_bmp, (n_type_real) s * 0.01 );
		} else
		if ( s < 0 )
		{
			s *= -1;
			n_bmp_flush_antialias( &resizer_bmp, (n_type_real) s * 0.01 );
		}

	}

	//if ( 0 )
	{ // Contrast

		int ctrst = (int) [_n_resizer_contrast_scrollbar n_scrollbar_position_get];

		n_bmp_flush_contrast( &resizer_bmp, ctrst );

	}


	// [!] : Main

	n_bmp *prev_bmp_data = paint.pen_bmp_data;
	n_bmp *prev_bmp_grab = paint.pen_bmp_grab;

//NSLog( @"%d", n_paint_global.paint->grabber_mode );
	if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		paint.pen_bmp_data = &resizer_bmp;
	} else {
		paint.pen_bmp_grab = &resizer_bmp;

		n_type_gfx gx,gy,gsx,gsy,gfx,gfy;
		n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, &gfx,&gfy );

		gsx = sx;
		gsy = sy;

		n_paint_grabber_system_set( &gx,&gy, &gsx,&gsy, &gfx,&gfy );
	}

	[_n_paint_canvas display];

	paint.pen_bmp_data = prev_bmp_data;
	paint.pen_bmp_grab = prev_bmp_grab;

}

- (IBAction)n_resizer_resize_combobox_method:(id)sender {

	[self n_resizer_go];

}

- (IBAction)n_resizer_sx_method:(id)sender {

//NSLog( @"%ld", [sender integerValue] );

	[self n_resizer_go];

}

- (IBAction)n_resizer_sy_method:(id)sender {

//NSLog( @"%ld", [sender integerValue] );

	[self n_resizer_go];

}

- (IBAction)n_resizer_color_combobox_method:(NSComboBox *)sender {

	[self n_resizer_go];

}

- (IBAction)n_resizer_button_go_method:(NSButton *)sender {

	if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{
		n_bmp_free( paint.pen_bmp_data );
		n_bmp_alias( &resizer_bmp, paint.pen_bmp_data );
	} else {
		n_bmp_free( paint.pen_bmp_grab );
		n_bmp_alias( &resizer_bmp, paint.pen_bmp_grab );

		resizer_is_ok = TRUE;
	}

	[_n_resizer_window close];

}




@end

// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File




#ifndef _H_NONNON_MAC_NONNON_PAINT_CANVAS
#define _H_NONNON_MAC_NONNON_PAINT_CANVAS




#import <Cocoa/Cocoa.h>


#include "../../nonnon/neutral/ini.c"


#include "../../nonnon/mac/_mac.c"
#include "../../nonnon/mac/image.c"




#include "extern.c"




@protocol NonnonPaint_delegate

- (void) NonnonPaintResize;
- (void) NonnonPaintColorSet;
- (void) NonnonPaintStatus;

@end




@interface NonnonPaintCanvas : NSView

@property (nonatomic,assign) id delegate;

@property n_paint *paint;

- (NSPoint) n_paint_canvaspos;
- (int) n_paint_zoom_get_int:(int) zoom;
- (void) n_paint_convert_bitmap2canvas:(void*) zero x:(n_type_gfx*)x y:(n_type_gfx*)y  sx:(n_type_gfx*)sx sy:(n_type_gfx*)sy;

@end




static NonnonPaintCanvas *n_paint_global;




n_posix_bool
n_paint_layer_is_locked( n_type_int i )
{

	n_paint *p = n_paint_global.paint;


	if ( p->layer_onoff == n_posix_false ) { return n_posix_false; }


	return ( p->layer_data[ i ].name[ 3 ] == n_posix_literal( '*' ) );
}




#include "grabber.c"
#include "pen.c"

#include "frame_anim.c"

#include "layer.c"




@implementation NonnonPaintCanvas {

	n_bmp   bmp_canvas;
	NSPoint n_pt;

}


@synthesize delegate;

@synthesize paint;




- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];

		n_bmp_zero( &bmp_canvas );

		n_paint_global = self;
	}

	return self;
}




- (BOOL) isFlipped
{
	return YES;
}

- (BOOL) acceptsFirstMouse:(NSEvent *)event
{
//NSLog( @"acceptsFirstMouse" );

	return YES;
}




- (void) n_paint_draw:(void*) zero sx:(n_type_gfx)sx sy:(n_type_gfx)sy step:(int)step cores:(u32)cores
{

	int zoom = [self n_paint_zoom_get_int:paint->zoom];

	n_type_gfx bmpsx = N_BMP_SX( paint->pen_bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( paint->pen_bmp_data );

	if ( paint->zoom < 0 )
	{
		bmpsx /= zoom;
		bmpsy /= zoom;
	} else {
		bmpsx *= zoom;
		bmpsy *= zoom;
	}

	n_type_gfx fx  = 0;
	n_type_gfx fy  = 0;
	n_type_gfx fsx = bmpsx;
	n_type_gfx fsy = bmpsy;
	n_type_gfx tx  = 0;
	n_type_gfx ty  = 0;


	if ( fsx > paint->inner_sx )
	{
		fx  = paint->scroll.x;
		fsx = paint->inner_sx;
	}

	if ( fsy > paint->inner_sy )
	{
		fy  = paint->scroll.y;
		fsy = paint->inner_sy;
	}

	paint->canvas_offset_x = tx  = ( sx - fsx ) / 2;
	paint->canvas_offset_y = ty  = ( sy - fsy ) / 2;


	// [!] : combined scale copy

	n_type_gfx gx,gy,gsx,gsy; n_paint_grabber_system_get( &gx,&gy, &gsx,&gsy, NULL,NULL );			

	n_type_gfx center_x = N_BMP_SX( paint->pen_bmp_data ) / 2;
	n_type_gfx center_y = N_BMP_SX( paint->pen_bmp_data ) / 2;

	n_type_gfx thread_sy = fsy / cores;
	n_type_gfx thread_ty = thread_sy * step;

	if ( step == -1 )
	{
		thread_sy = fsy;
		thread_ty = 0;
	}

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		n_type_gfx xx,yy;

		if ( paint->zoom < 0 )
		{
			xx = ( fx * zoom ) + (   x               * zoom );
			yy = ( fy * zoom ) + ( ( y + thread_ty ) * zoom );
		} else {
			xx = ( fx / zoom ) + (   x               / zoom );
			yy = ( fy / zoom ) + ( ( y + thread_ty ) / zoom );
		}

		u32 color;//n_bmp_ptr_get_fast( paint->pen_bmp_data, xx,yy, &color );

		if ( paint->layer_onoff )
		{
			color = n_bmp_layer_ptr_get( paint->layer_data, xx,yy, n_posix_false, 0, n_posix_true );
		} else {
			n_paint_grabber_pixel_get( xx,yy, paint->color, &color, NULL, 0.00 );
		}

		// [!] : grabber

		if ( paint->grabber_mode != N_PAINT_GRABBER_NEUTRAL )
		{

#ifdef N_PAINT_FRAME_ANIM

			//

#else  // #ifdef N_PAINT_FRAME_ANIM

			if (
				( ( xx == ( gx -   1 ) )&&( yy >= ( gy - 1 ) )&&( yy <= ( gy + gsy ) ) )
				||
				( ( xx == ( gx + gsx ) )&&( yy >= ( gy - 1 ) )&&( yy <= ( gy + gsy ) ) )
				||
				( ( yy == ( gy -   1 ) )&&( xx >= ( gx - 1 ) )&&( xx <= ( gx + gsx ) ) )
				||
				( ( yy == ( gy + gsy ) )&&( xx >= ( gx - 1 ) )&&( xx <= ( gx + gsx ) ) )
			)
			{
				if ( n_bmp_moire_detect( xx,yy, 1 ) )
				{
					color = n_bmp_rgb_mac( 111,111,111 );
				}
			}

#endif // #ifdef N_PAINT_FRAME_ANIM

			if ( paint->grabber_blend )
			{
				u32 c; n_bmp_ptr_get_fast( paint->pen_bmp_data, xx,yy, &c );
				color = n_bmp_blend_pixel( color, c, paint->grabber_blend_ratio );
			}

		}

		// [!] : center line

		if ( paint->grid_onoff )
		{
			u32 grid_color = 0;
			if ( ( xx == center_x )||( yy == center_y ) )
			{
				grid_color = n_bmp_rgb_mac( 255,0,128 );
			} else
			if ( ( 0 == ( xx % 32 ) )||( 0 == ( yy % 32 ) ) )
			{
				grid_color = n_bmp_rgb_mac( 0,200,255 );
			}

			if ( grid_color != 0 )
			{
				n_type_gfx zx = ( x % zoom );
				n_type_gfx zy = ( y % zoom );

				if ( ( zx == 0 )||( zy == 0 )||( zx == ( zoom - 1  )||( zy == ( zoom - 1 ) ) ) )
				{
					color = n_bmp_blend_pixel( color, grid_color, 0.25 );
				}
			}
		}

		// [!] : pixel grid

		if ( ( paint->pixel_grid_onoff )&&( zoom >= 3 ) )
		{
			n_type_gfx zx = ( x % zoom );
			n_type_gfx zy = ( y % zoom );

			if ( ( zx == 0 )||( zy == 0 )||( zx == ( zoom - 1  )||( zy == ( zoom - 1 ) ) ) )
			{
				color = n_bmp_blend_pixel( color, n_bmp_rgb_mac( 0,200,255 ), 0.25 );
			}
		}

		n_bmp_ptr_set_fast( &bmp_canvas, tx + x, ty + y + thread_ty, color );

		x++;
		if ( x >= fsx )
		{
			x = 0;

			y++;
			if ( y >= thread_sy ) { break; }
		}
	}

}

-(void) drawRect:(NSRect) rect
{
//NSLog( @"drawRect" );

	BOOL is_flushed = FALSE;

	static n_type_gfx prv_sx = -1;
	static n_type_gfx prv_sy = -1;

	n_type_gfx sx = NSWidth ( rect );
	n_type_gfx sy = NSHeight( rect );

	if ( NULL == N_BMP_PTR( &bmp_canvas ) )
	{
		n_bmp_new_fast( &bmp_canvas, sx,sy );

		is_flushed = TRUE;
		n_bmp_flush( &bmp_canvas, n_bmp_rgb_mac( 128,128,128 ) );
	}

	if ( ( prv_sx != sx )||( prv_sy != sy ) )
	{
		if ( is_flushed == FALSE )
		{
			n_bmp_flush( &bmp_canvas, n_bmp_rgb_mac( 128,128,128 ) );
		}
	}

	static BOOL scroll_x_onoff = FALSE;
	static BOOL scroll_y_onoff = FALSE;

	BOOL prv_scroll_x_onoff = scroll_x_onoff;
	BOOL prv_scroll_y_onoff = scroll_y_onoff;

	{

		// [!] : Fake Scroller : Calc Only : Horizontal

		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat csx              = sx;
		CGFloat items_per_canvas = paint->inner_sx;
		CGFloat max_count        = (CGFloat) N_BMP_SX( paint->pen_bmp_data ) * zoom;

		if ( trunc( items_per_canvas ) < max_count )
		{
//NSLog( @"1" );

			scroll_x_onoff = TRUE;

			CGFloat shaft = csx - paint->scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsx = n_posix_max_double( paint->scroller_size, ( items_per_canvas / page ) + paint->margin - paint->scroller_size );
			CGFloat scrsy = paint->scroller_size;
			CGFloat scr_x = ( paint->scroll.x / max_count ) * items_per_canvas;
			CGFloat scr_y = sy - scrsy;
//NSLog( @"%f %f %f %f", scr_x, scr_y, scrsx, scrsy );

			// [!] : for hit test

			paint->scroller_x_rect_shaft = NSMakeRect(     0, scr_y, shaft, scrsy );
			paint->scroller_x_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );

		} else {
//NSLog( @"2" );
			scroll_x_onoff = FALSE;
			paint->scroll.x  = 0;

		}

	}

	{

		// [!] : Fake Scroller : Calc Only : Vertical

		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat csy              = sy;
		CGFloat items_per_canvas = paint->inner_sy;
		CGFloat max_count        = (CGFloat) N_BMP_SY( paint->pen_bmp_data ) * zoom;

		if ( trunc( items_per_canvas ) < max_count )
		{

			scroll_y_onoff = TRUE;

			CGFloat shaft = csy - paint->scroller_size;
			CGFloat page  = max_count / items_per_canvas;

			CGFloat scrsx = paint->scroller_size;
			CGFloat scrsy = n_posix_max_double( paint->scroller_size, ( items_per_canvas / page ) + paint->margin - paint->scroller_size );
			CGFloat scr_x = sx - scrsx;
			CGFloat scr_y = ( paint->scroll.y / max_count ) * items_per_canvas;


			// [!] : for hit test

			paint->scroller_y_rect_shaft = NSMakeRect( scr_x,     0, scrsx, shaft );
			paint->scroller_y_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx, scrsy );

		} else {

			scroll_y_onoff = FALSE;
			paint->scroll.y  = 0;

		}

	}

	if (
		( prv_scroll_x_onoff != scroll_x_onoff )
		||
		( prv_scroll_y_onoff != scroll_y_onoff )
	)
	{
		if ( is_flushed == FALSE )
		{
			n_bmp_flush( &bmp_canvas, n_bmp_rgb_mac( 128,128,128 ) );
		}
	}

	// [!] : combined scale copy

	{
//NSLog( @"zoom in" );

		// [!] : simple but too bad performance

		//n_bmp_free_fast( &bmp_zoom );
		//n_bmp_carboncopy( p->pen_bmp_data, &bmp_zoom )
		//n_bmp_scaler_big( &bmp_zoom, zoom );

		//n_bmp_fastcopy( &bmp_zoom, &canvas, fx,fy,fsx,fsy, tx,ty );


		//[self n_paint_draw:nil sx:sx sy:sy step:-1];


		n_posix_bool prv = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;

		NSOperationQueue *q = [[NSOperationQueue alloc] init];

		u32 cores = n_posix_cpu_count();
//NSLog( @"%d", (int) cores );

		int i = 0;
		n_posix_loop
		{
			NSOperation *o = [NSBlockOperation blockOperationWithBlock:^{

				[self n_paint_draw:nil sx:sx sy:sy step:i cores:cores];

			}];
			[q addOperation:o];

			i++;
			if ( i >= cores ) { break; }
		}

		[q waitUntilAllOperationsAreFinished];

		n_bmp_is_multithread = prv;

	}

	if ( scroll_x_onoff )
	{
//NSLog( @" 1 " );

		// [!] : Fake Scroller : Draw : Horizontal


		// [!] : shaft

		{
			n_type_gfx  x = paint->scroller_x_rect_shaft.origin.x;
			n_type_gfx  y = paint->scroller_x_rect_shaft.origin.y;
			n_type_gfx sx = paint->scroller_x_rect_shaft.size.width;
			n_type_gfx sy = paint->scroller_x_rect_shaft.size.height;
//NSLog( @"Shaft : %d %d %d %d", x,y,sx,sy );

			u32 color_shaft = n_bmp_rgb_mac( 244,244,244 );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_shaft, 50 );
		}


		// [!] : thumb / knob

		int alpha_fade_bg;
		int alpha_fade_fg;
		if ( paint->scroller_fade.color_fg == n_bmp_white )
		{
			alpha_fade_bg = 64;
			alpha_fade_fg = 96;
		} else {
			alpha_fade_bg = 96;
			alpha_fade_fg = 64;
		}
		int alpha = 255;//n_bmp_blend_channel( alpha_fade_bg, alpha_fade_fg, (double) fade_scroll.percent * 0.01 );
//NSLog( @"%d", fade.percent );

		{
			n_type_gfx  x = paint->scroller_x_rect_thumb.origin.x;
			n_type_gfx  y = paint->scroller_x_rect_thumb.origin.y;
			n_type_gfx sx = paint->scroller_x_rect_thumb.size.width;
			n_type_gfx sy = paint->scroller_x_rect_thumb.size.height;
//NSLog( @"Thumb : %d %d %d %d", x,y,sx,sy );

			u32 color       = n_bmp_rgb_mac( 200,200,200 );
			u32 color_thumb = n_bmp_alpha_replace_pixel( color, alpha );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_thumb, 50 );
		}

	}

	if ( scroll_y_onoff )
	{

		// [!] : Fake Scroller : Draw : Vertical


		// [!] : shaft

		{
			n_type_gfx  x = paint->scroller_y_rect_shaft.origin.x;
			n_type_gfx  y = paint->scroller_y_rect_shaft.origin.y;
			n_type_gfx sx = paint->scroller_y_rect_shaft.size.width;
			n_type_gfx sy = paint->scroller_y_rect_shaft.size.height;

			u32 color_shaft = n_bmp_rgb_mac( 244,244,244 );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_shaft, 50 );
		}


		// [!] : thumb / knob

		int alpha_fade_bg;
		int alpha_fade_fg;
		if ( paint->scroller_fade.color_fg == n_bmp_white )
		{
			alpha_fade_bg = 64;
			alpha_fade_fg = 96;
		} else {
			alpha_fade_bg = 96;
			alpha_fade_fg = 64;
		}
		int alpha = 255;//n_bmp_blend_channel( alpha_fade_bg, alpha_fade_fg, (double) fade_scroll.percent * 0.01 );
//NSLog( @"%d", fade.percent );

		{
			n_type_gfx  x = paint->scroller_y_rect_thumb.origin.x;
			n_type_gfx  y = paint->scroller_y_rect_thumb.origin.y;
			n_type_gfx sx = paint->scroller_y_rect_thumb.size.width;
			n_type_gfx sy = paint->scroller_y_rect_thumb.size.height;

			u32 color       = n_bmp_rgb_mac( 200,200,200 );
			u32 color_thumb = n_bmp_alpha_replace_pixel( color, alpha );
			n_bmp_roundrect( &bmp_canvas, x,y,sx,sy, color_thumb, 50 );
		}

	}

/*
	if ( paint->grabber_mode )
	{

		n_type_gfx frame_fx, frame_fy, frame_tx, frame_ty;
		n_paint_grabber_system_get( &frame_fx, &frame_fy, &frame_tx, &frame_ty, NULL,NULL );

		frame_fx += paint->canvas_offset_x;
		frame_fy += paint->canvas_offset_y;

n_bmp_box( &bmp_canvas, frame_fx, frame_fy, frame_tx, frame_ty, n_bmp_rgb_mac( 0,200,255 ) );

	}
*/

#ifdef N_PAINT_FRAME_ANIM

	if ( paint->grabber_mode )
	{

		n_type_gfx bitmap_sx = N_BMP_SX( paint->pen_bmp_data );
		n_type_gfx bitmap_sy = N_BMP_SY( paint->pen_bmp_data );


		n_type_gfx frame_fx, frame_fy, frame_tx, frame_ty;
		n_paint_grabber_system_get( &frame_fx, &frame_fy, &frame_tx, &frame_ty, NULL,NULL );

		// [!] : canvas_offset_x/y : valid after combined scale copy

		frame_tx += frame_fx;
		frame_ty += frame_fy;

		// [!] : animated frame
		n_paint_frame_anim_init( bitmap_sx,bitmap_sy, frame_fx, frame_fy, frame_tx, frame_ty );

		n_paint_frame_anim_exit( paint, &bmp_canvas );

	}

#endif // #ifdef N_PAINT_FRAME_ANIM


	rect = NSMakeRect( 0,0,sx,sy );
	n_mac_image_nbmp_direct_draw( &bmp_canvas, &rect, NO );

}




- (CGFloat) n_paint_zoom_get_ratio:(CGFloat) zoom
{
	if ( zoom < 0 ) { zoom = 1.0 / ( zoom * -1 ); }

//NSLog( @"%0.2f", zoom );
	return zoom;
}

- (int) n_paint_zoom_get_int:(int) zoom
{
	if ( zoom < 0 ) { zoom *= -1; }

//NSLog( @"%d", zoom );
	return zoom;
}

- (NSPoint) n_paint_canvaspos
{

	NSPoint pt = n_mac_cursor_position_get( self );

	pt.x -= paint->margin / 2;
	pt.y -= paint->margin / 2;


	CGFloat ratio = [self n_paint_zoom_get_ratio:paint->zoom];


	CGFloat bmpsx = N_BMP_SX( paint->pen_bmp_data ) * ratio;
	CGFloat bmpsy = N_BMP_SY( paint->pen_bmp_data ) * ratio;
	
//NSLog( @"Metrics : %0.2f %0.2f %0.2f", pt.x, (*n_inner_sx), bmpsx );

	if ( paint->inner_sx > bmpsx )
	{
		pt.x -= ( paint->inner_sx - bmpsx ) / 2;
	}

	if ( paint->inner_sy > bmpsy )
	{
		pt.y -= ( paint->inner_sy - bmpsy ) / 2;
	}

	pt.x /= ratio;
	pt.y /= ratio;


	pt.x += paint->scroll.x / ratio;
	pt.y += paint->scroll.y / ratio;


	return pt;
}

- (void) n_paint_convert_bitmap2canvas:(void*) zero x:(n_type_gfx*)x y:(n_type_gfx*)y  sx:(n_type_gfx*)sx sy:(n_type_gfx*)sy
{

	if ( paint->zoom > 0 )
	{

		CGFloat ratio = [self n_paint_zoom_get_ratio:paint->zoom];

		if (  x != NULL ) { (* x) = paint->canvas_offset_x + ( (*x) * ratio ) - trunc( paint->scroll.x ); }
		if (  y != NULL ) { (* y) = paint->canvas_offset_y + ( (*y) * ratio ) - trunc( paint->scroll.y ); }
		if ( sx != NULL ) { (*sx) = (*sx) * ratio; }
		if ( sy != NULL ) { (*sy) = (*sy) * ratio; }

	} else {
	
		CGFloat ratio = [self n_paint_zoom_get_ratio:paint->zoom];
//NSLog( @"%f", ratio );

		if (  x != NULL ) { (* x) = paint->canvas_offset_x + ( (*x) * ratio ) - trunc( paint->scroll.x ); }
		if (  y != NULL ) { (* y) = paint->canvas_offset_y + ( (*y) * ratio ) - trunc( paint->scroll.y ); }
		if ( sx != NULL ) { (*sx) = (*sx) * ratio; }
		if ( sy != NULL ) { (*sy) = (*sy) * ratio; }

	}

}




- (void) n_paint_scroll_clamp
{

	if ( paint->scroll.x < 0 ) { paint->scroll.x = 0; }
	if ( paint->scroll.y < 0 ) { paint->scroll.y = 0; }

	CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

	CGFloat max_sx = ( N_BMP_SX( paint->pen_bmp_data ) * zoom ) - paint->inner_sx;
	CGFloat max_sy = ( N_BMP_SY( paint->pen_bmp_data ) * zoom ) - paint->inner_sy;

	if ( paint->scroll.x >= max_sx ) { paint->scroll.x = max_sx; }
	if ( paint->scroll.y >= max_sy ) { paint->scroll.y = max_sy; }

}




#ifdef N_PAINT_FRAME_ANIM

- (void) n_paint_frame_anim_timer_method
{
//NSLog( @"n_paint_frame_anim_timer_method" );

	if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { return; }

	if (
		( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_DRAGGING )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
		||
		( paint->grabber_mode == N_PAINT_GRABBER_STRETCH_TRANSFORM )
	)
	{
		static u32 timer = 0;
		if ( n_game_timer( &timer, N_PAINT_FRAME_ANIM_INTERVAL ) )
		{
			n_paint_frame_anim_step++;

			n_paint_grabber_resync_auto();
		}
	}

}

- (void) n_paint_frame_anim_on
{
//NSLog( @"n_paint_frame_anim_on" );

	n_paint_frame_anim_timer = n_mac_timer_init( n_paint_global, @selector( n_paint_frame_anim_timer_method ), 1 );

	n_paint_frame_anim_step = 0;

	n_paint_frame_anim_onoff = n_posix_true;

}

- (void) n_paint_frame_anim_off
{

	n_mac_timer_exit( n_paint_frame_anim_timer );

	n_paint_frame_anim_onoff = n_posix_false;

}

#endif // #ifdef N_PAINT_FRAME_ANIM




- (void) updateTrackingAreas
{
//return;

	int options = (
		NSTrackingMouseEnteredAndExited |
		NSTrackingMouseMoved            |
		NSTrackingActiveAlways          |
		NSTrackingActiveInActiveApp
	);

	NSTrackingArea *trackingArea = [
		[NSTrackingArea alloc]
			initWithRect:[self bounds]
			     options:options
			       owner:self
			    userInfo:nil
	];
	
	[self addTrackingArea:trackingArea];

}

- (void) resetCursorRects
{
//NSLog(@"resetCursorRects");

	// [x] : buggy : maybe impossible to implement accurate behavior
	//
	//	[cursor set]     : applied globally
	//	mouseMoved       : delay will occur
	//	at launch time   : always arrow cursor
	//	push/pop         : more complicated behavior happens
	//	resetCursorRects : not refreshed on inactive window

	//return;


	// [Patch]

	NSRect rect = NSMakeRect(
		self.bounds.origin.x    +   paint->scroller_size,
		self.bounds.origin.y    +   paint->scroller_size,
		self.bounds.size.width  - ( paint->scroller_size * 2 ),
		self.bounds.size.height - ( paint->scroller_size * 2 )
	);

	//[self discardCursorRects];

	[self removeCursorRect:rect cursor:paint->cursor_arrow  ];
	[self removeCursorRect:rect cursor:paint->cursor_pen_on ];
	[self removeCursorRect:rect cursor:paint->cursor_pen_off];

	//[self.window invalidateCursorRectsForView:self];
	//[self.window invalidateCursorRectsForView:self];

	if ( paint->readonly )
	{
		[self addCursorRect:rect cursor:paint->cursor_arrow];
	} else
	if ( paint->cursor_grab_n_drag_onoff )
	{
		[[NSCursor closedHandCursor] set];
	} else
	if ( paint->tooltype == N_PAINT_TOOL_TYPE_PEN )
	{
		if ( paint->pen_start )
		{
			[self addCursorRect:rect cursor:paint->cursor_pen_on ];
		} else {
			[self addCursorRect:rect cursor:paint->cursor_pen_off];
		}
	} else {
		[self addCursorRect:rect cursor:paint->cursor_arrow];
	}

}

- (void) mouseEntered:(NSEvent *)theEvent
{
//NSLog(@"mouseEntered");

	// [Needed] : NSTrackingMouseEnteredAndExited

	//[self resetCursorRects];

}

- (void) mouseExited:(NSEvent *)theEvent
{
//NSLog(@"mouseExited");

	// [Needed] : NSTrackingMouseEnteredAndExited

}

- (void) mouseMoved:(NSEvent *)theEvent
{
//NSLog( @"mouseMoved" );

	// [Needed] : NSTrackingMouseMoved

	[n_paint_global.delegate NonnonPaintStatus];

}




- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );


	paint->scroller_thumb_is_captured = FALSE;

	paint->scroller_x_offset = -1;
	paint->scroller_y_offset = -1;


	if ( paint->readonly ) { return; }

	NonnonPaintPen_mouseUp( paint );
	NonnonPaintGrabber_mouseUp( paint );

	[self resetCursorRects];

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

//NSPoint pt = [self n_paint_canvaspos];
//NSLog( @"%0.2f %0.2f", pt.x, pt.y );
//n_bmp_circle( paint->pen_bmp_data, pt.x-16,pt.y-16,32,32, n_bmp_rgb_mac( 0,200,255 ) );
//[self display];

	paint->scroller_x_thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_x_rect_thumb );
	paint->scroller_x_shaft_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_x_rect_shaft );
	paint->scroller_y_thumb_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_y_rect_thumb );
	paint->scroller_y_shaft_is_hovered = n_mac_window_is_hovered_offset_by_rect( self, paint->scroller_y_rect_shaft );


	NSPoint pt_cur = n_mac_cursor_position_get( self );

	if ( paint->scroller_x_thumb_is_hovered )
	{
		paint->scroller_x_offset = pt_cur.x - paint->scroller_x_rect_thumb.origin.x;
	} else {
		paint->scroller_x_offset = -1;
	}

	if ( paint->scroller_y_thumb_is_hovered )
	{
		paint->scroller_y_offset = pt_cur.y - paint->scroller_y_rect_thumb.origin.y;
	} else {
		paint->scroller_y_offset = -1;
	}


	if ( ( paint->scroller_x_thumb_is_hovered )||( paint->scroller_y_thumb_is_hovered ) )
	{
		paint->scroller_thumb_is_captured = TRUE;
	} else
	if ( paint->scroller_x_shaft_is_hovered )
	{
		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat items_per_canvas = paint->inner_sx;
		CGFloat max_count        = (CGFloat) N_BMP_SX( paint->pen_bmp_data ) * zoom;

		paint->scroll.x = pt_cur.x - ( NSWidth( paint->scroller_x_rect_thumb )/ 2 );
		paint->scroll.x = ( paint->scroll.x / items_per_canvas ) * max_count;

		[self n_paint_scroll_clamp];

		[self display];
	} else
	if ( paint->scroller_y_shaft_is_hovered )
	{
		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		CGFloat items_per_canvas = paint->inner_sy;
		CGFloat max_count        = (CGFloat) N_BMP_SY( paint->pen_bmp_data ) * zoom;

		paint->scroll.y = pt_cur.y - ( NSHeight( paint->scroller_y_rect_thumb )/ 2 );
		paint->scroll.y = ( paint->scroll.y / items_per_canvas ) * max_count;

		[self n_paint_scroll_clamp];

		[self display];
	} else {
		if ( paint->readonly ) { return; }

		NonnonPaintPen_mouseDown( paint );
		NonnonPaintGrabber_mouseDown( paint, theEvent );

		n_paint_frame_mouseDown( paint );

		[self resetCursorRects];

#ifdef N_PAINT_FRAME_ANIM

		[self n_paint_frame_anim_on];
		
#endif // #ifdef N_PAINT_FRAME_ANIM
	}

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog( @"mouseDragged" );

	if ( paint->scroller_thumb_is_captured )
	{
		NSPoint pt_cur = n_mac_cursor_position_get( self );

		CGFloat zoom = [self n_paint_zoom_get_ratio:paint->zoom];

		if ( paint->scroller_x_thumb_is_hovered )
		{
			CGFloat items_per_canvas = paint->inner_sx;
			CGFloat max_count        = (CGFloat) N_BMP_SX( paint->pen_bmp_data ) * zoom;

			paint->scroll.x = pt_cur.x - paint->scroller_x_offset;
			paint->scroll.x = ( paint->scroll.x / items_per_canvas ) * max_count;
		}

		if ( paint->scroller_y_thumb_is_hovered )
		{
			CGFloat items_per_canvas = paint->inner_sy;
			CGFloat max_count        = (CGFloat) N_BMP_SY( paint->pen_bmp_data ) * zoom;

			paint->scroll.y = pt_cur.y - paint->scroller_y_offset;
			paint->scroll.y = ( paint->scroll.y / items_per_canvas ) * max_count;
		}

		[self n_paint_scroll_clamp];

		[self display];
	} else {
		if ( paint->readonly ) { return; }

		NonnonPaintPen_mouseDragged( paint );
		NonnonPaintGrabber_mouseDragged( paint );
	}

}

- (void)rightMouseDown:(NSEvent *)theEvent
{

	if ( paint->readonly ) { return; }

	NonnonPaintPen_rightMouseDown( paint );
	NonnonPaintGrabber_rightMouseDown( paint );

	[self.delegate NonnonPaintColorSet];

#ifdef N_PAINT_FRAME_ANIM

	[self n_paint_frame_anim_on];
		
#endif // #ifdef N_PAINT_FRAME_ANIM
}


- (void)scrollWheel:(NSEvent *)theEvent
{

	// [!] : lower is faster response but not harder
	static u32 timer = 0;
	if ( n_posix_false == n_game_timer( &timer, 200 ) ) { return; }


	CGFloat delta = 0;

//NSLog( @"%f", [theEvent scrollingDeltaY] );
	if ( [theEvent scrollingDeltaY] == 0 )
	{
		//
	} else {
		if ( [theEvent scrollingDeltaY] < 0 )
		{
			delta = -1;
		} else {
			delta =  1;
		}
	}


	n_type_gfx p_zoom = paint->zoom;

	paint->zoom += delta;


	static int prev = 1;

	if ( ( paint->zoom == 0 )||( paint->zoom == -1 ) )
	{
		if ( prev > 0 ) { paint->zoom = -2; } else { paint->zoom = 1; }
	}

	if ( paint->zoom < -100 ) { paint->zoom = -100; } else
	if ( paint->zoom >  100 ) { paint->zoom =  100; }

	prev = paint->zoom;


	// [!] : Smart Zoom

	NSPoint pt = n_mac_cursor_position_get( self );

	n_type_gfx p_z = [self n_paint_zoom_get_int:     p_zoom];
	n_type_gfx c_z = [self n_paint_zoom_get_int:paint->zoom];

	if ( ( p_zoom > 0 )&&( paint->zoom > 0 ) )
	{

		paint->scroll.x = paint->scroll.x + pt.x;
		paint->scroll.x = paint->scroll.x / p_z;
		paint->scroll.x = paint->scroll.x * c_z;
		paint->scroll.x = paint->scroll.x - pt.x;

		paint->scroll.y = paint->scroll.y + pt.y;
		paint->scroll.y = paint->scroll.y / p_z;
		paint->scroll.y = paint->scroll.y * c_z;
		paint->scroll.y = paint->scroll.y - pt.y;
	} else {
		paint->scroll.x = paint->scroll.x + pt.x;
		paint->scroll.x = paint->scroll.x * p_z;
		paint->scroll.x = paint->scroll.x / c_z;
		paint->scroll.x = paint->scroll.x - pt.x;

		paint->scroll.y = paint->scroll.y + pt.y;
		paint->scroll.y = paint->scroll.y * p_z;
		paint->scroll.y = paint->scroll.y / c_z;
		paint->scroll.y = paint->scroll.y - pt.y;
	}

	[self n_paint_scroll_clamp];

	[self.delegate NonnonPaintResize];


}




- (void) otherMouseUp:(NSEvent*) theEvent
{
//NSLog( @"otherMouseUp : %ld", (long) [theEvent buttonNumber] );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		paint->cursor_grab_n_drag_onoff = FALSE;
		[self resetCursorRects];

	}

}

- (void) otherMouseDown:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDown : %ld", (long) [theEvent buttonNumber] );

	// [!] : Grab N Drag

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		n_pt = [NSEvent mouseLocation];

		paint->cursor_grab_n_drag_onoff = TRUE;
		[self resetCursorRects];

	}

}

- (void) otherMouseDragged:(NSEvent*) theEvent
{
//NSLog( @"otherMouseDragged" );

	if ( [theEvent buttonNumber] == 2 )
	{

		// [!] : middle button

		CGPoint pt_cur = [NSEvent mouseLocation];

		CGFloat dx = n_pt.x - pt_cur.x;
		CGFloat dy = n_pt.y - pt_cur.y;

		n_pt = pt_cur;

		paint->scroll.x += dx;
		paint->scroll.y -= dy;


		[self n_paint_scroll_clamp];


		[self display];

	}

}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d", event.keyCode );

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_ARROW_UP :

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_ARROW_DOWN :

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_ARROW_LEFT :

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		NonnonPaintGrabber_keyDown_arrow( paint, event.keyCode );

	break;

	case N_MAC_KEYCODE_COPY: 

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			if ( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
			{
				n_paint_grabber_copy();
			}
		}

	break;

	case N_MAC_KEYCODE_PASTE: 

		if ( paint->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { break; }

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			if ( paint->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
			{
				n_paint_grabber_paste();
			}
		}

	break;

	case N_MAC_KEYCODE_F2: 

		[self.delegate keyDown:event];

	break;

	} // switch

}




-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	// [!] : call when dropped

	//NSArray *array = [[sender draggingPasteboard] propertyListForType:NSPasteboardTypeFileURL];

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstr      = [[NSURL URLFromPasteboard:pasteboard] path];

//NSLog( @"%@", nsstr );

	n_bmp_free( &bmp_canvas );

	[self.delegate NonnonDragAndDrop_dropped:nsstr];

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	return NSDragOperationCopy;
}

@end




#endif // _H_NONNON_MAC_NONNON_PAINT_CANVAS


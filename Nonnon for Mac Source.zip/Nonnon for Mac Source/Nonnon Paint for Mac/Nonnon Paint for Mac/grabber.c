// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_paint_grabber_system_get( n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy, n_type_gfx *fx, n_type_gfx *fy )
{

	// [!] : Why is this messy?
	//
	//	a : for reserving namespace
	//	b : for avoiding silent reference to global variables

	n_paint *p = n_paint_global.paint;
	n_rect   r = p->grabber_rect;
	
	if ( x  != NULL ) { *x  = r.x ; }
	if ( y  != NULL ) { *y  = r.y ; }
	if ( sx != NULL ) { *sx = r.sx; }
	if ( sy != NULL ) { *sy = r.sy; }
	if ( fx != NULL ) { *fx = p->grabber_fx; }
	if ( fy != NULL ) { *fy = p->grabber_fy; }


	return;
}

// internal
void
n_paint_grabber_system_set( n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy, n_type_gfx *fx, n_type_gfx *fy )
{

	n_paint *p = n_paint_global.paint;

	if ( x  != NULL ) { p->grabber_rect.x  = *x ; }
	if ( y  != NULL ) { p->grabber_rect.y  = *y ; }
	if ( sx != NULL ) { p->grabber_rect.sx = *sx; }
	if ( sy != NULL ) { p->grabber_rect.sy = *sy; }
	if ( fx != NULL ) { p->grabber_fx      = *fx; }
	if ( fy != NULL ) { p->grabber_fy      = *fy; }


	return;
}

// internal
void
n_paint_grabber_system_zero( void )
{

	n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	x = y = sx = sy = fx = fy = 0;

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	return;
}

// internal
void
n_paint_grabber_init( void )
{

	n_paint *p = n_paint_global.paint;


	p->grabber_mode = N_PAINT_GRABBER_NEUTRAL;

	n_paint_grabber_system_zero();


	return;
}

// internal
void
n_paint_grabber_resync( n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool reset_scrl )
{
	[n_paint_global display];

	return;
}

void
n_paint_grabber_resync_auto( void )
{
	[n_paint_global display];

	return;
}

void
n_paint_grabber_resync_auto_fast( void )
{
	[n_paint_global display];

	return;
}




// internal
void
n_paint_grabber_pixel_get( n_type_gfx tx, n_type_gfx ty, u32 picked, u32 *before, u32 *after, n_type_real blend )
{

	n_paint *p = n_paint_global.paint;


	u32 color_b, color_a;


	// [x] : don't use _fast()

	if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{

		//n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &color_b );

		color_b = n_bmp_antialias_pixel( p->pen_bmp_data, tx,ty, blend );
		color_a = picked;

	} else {

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


		n_type_gfx gx = tx - x;
		n_type_gfx gy = ty - y;

		if ( n_bmp_ptr_is_accessible( n_paint_global.paint->pen_bmp_grab, gx,gy ) )
		{
			color_b = n_bmp_antialias_pixel( p->pen_bmp_grab, gx,gy, blend );
		} else {
			color_b = n_bmp_antialias_pixel( p->pen_bmp_data, tx,ty, blend );
		}


		// [!] : Eraser

		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE == n_bmp_a( picked ) )
		//if ( n_false )
		{
			n_bmp_ptr_get( p->pen_bmp_data, tx,ty, &color_a );
		} else {
			color_a = picked;
		}

	}


	if ( before != NULL ) { (*before) = color_b; }
	if ( after  != NULL ) { (*after ) = color_a; }


	return;
}

// internal
void
n_paint_grabber_pixel_set( n_type_gfx tx, n_type_gfx ty, u32 before, u32 after )
{

	n_paint *p = n_paint_global.paint;


	if ( before == after ) { return; }


	if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{

		n_bmp_ptr_set( p->pen_bmp_data, tx,ty, after );

	} else {

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

/*
		int a = n_bmp_a( before );

		if ( a == N_BMP_ALPHA_CHANNEL_INVISIBLE )
		{
			n_bmp_ptr_get( n_paint_bmp_data, tx,ty, &after );
		}
*/

		n_type_gfx grab_x = tx - x;
		n_type_gfx grab_y = ty - y;

		n_bmp_ptr_set( p->pen_bmp_grab, grab_x,grab_y, after );

	}


	return;
}

// internal
void
n_paint_grabber_fill( n_type_gfx tx, n_type_gfx ty, u32 color )
{

	n_paint *p = n_paint_global.paint;


	if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
	{

		n_bmp_fill( p->pen_bmp_data, tx, ty, color );

	} else {

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

		n_type_gfx grab_x = tx - x;
		n_type_gfx grab_y = ty - y;

		n_bmp_fill( p->pen_bmp_grab, grab_x,grab_y, color );

	}


	return;
}




// internal
void
n_paint_grabber_composition( n_bmp *grab, n_bmp *target, n_posix_bool finalize, n_posix_bool frame )
{

	n_paint *p = n_paint_global.paint;


	if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL ) { return; }


	n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );

//return;
	if ( p->grabber_per_pixel_alpha_onoff )
	{
		n_bmp_blendcopy_all( grab, target, 0,0,sx,sy, x,y, n_posix_false,n_posix_false, finalize, n_paint_global.paint->grabber_blend_ratio );
	} else
	if ( p->grabber_blend )
	{
		n_bmp_blendcopy_all( grab, target, 0,0,sx,sy, x,y, n_posix_true ,n_posix_false, finalize, n_paint_global.paint->grabber_blend_ratio );
	} else {
		n_bmp_fastcopy( grab, target, 0,0,sx,sy, x,y );
	}


	return;
}

// internal
void
n_paint_grabber_reset( void )
{

	n_paint *p = n_paint_global.paint;


	if ( p->layer_onoff )
	{
//NSLog( @"n_paint_grabber_reset()" );

		n_type_int i = 0;
		n_posix_loop
		{

			n_bmp_free( &p->layer_data[ i ].bmp_grab );

			i++;
			if ( i >= p->layer_count ) { break; }
		}

	} else {

		n_bmp_free( p->pen_bmp_grab );

	}

	n_paint_grabber_init();

	n_paint_grabber_resync_auto();


	p->grabber_per_pixel_alpha_onoff = FALSE;
	p->grabber_blend                 = 0;
	p->grabber_blend_ratio           = 0;


	return;
}

// internal
void
n_paint_grabber_finish( void )
{

	n_paint *p = n_paint_global.paint;


	if ( p->layer_whole_grab_onoff )
	{

		n_type_int i = 0;
		n_posix_loop
		{
			if ( p->layer_data[ i ].visible )
			{
				n_paint_grabber_composition
				(
					&p->layer_data[ i ].bmp_grab,
					&p->layer_data[ i ].bmp_data,
					n_posix_true,//n_paint_grabber_is_rotated,
					n_posix_false
				);
			}

			i++;
			if ( i >= p->layer_count ) { break; }
		}

	} else
	if ( p->layer_onoff )
	{

		n_type_int i = p->layer_index;

		if ( p->layer_data[ i ].visible )
		{
			n_paint_grabber_composition
			(
				&p->layer_data[ i ].bmp_grab,
				&p->layer_data[ i ].bmp_data,
				n_posix_true,//n_paint_grabber_is_rotated,
				n_posix_false
			);
		}

	} else {
	
		n_paint_grabber_composition( p->pen_bmp_grab, n_paint_global.paint->pen_bmp_data, n_posix_true, n_posix_false );

	}


	if ( p->layer_onoff )
	{

		n_type_int i = 0;
		n_posix_loop
		{
			n_bmp_free( &p->layer_data[ i ].bmp_grab );

			i++;
			if ( i >= p->layer_count ) { break; }
		}

	} else {

		n_bmp_free( p->pen_bmp_grab );

	}

	n_paint_grabber_init();

	[n_paint_global.delegate NonnonPaintStatus];


	n_paint_grabber_resync_auto();


	//n_paint_grabber_is_rotated = n_false;


	return;
}

// internal
void
n_paint_grabber_select( n_bmp *b, n_posix_bool redraw )
{

	n_paint *p = n_paint_global.paint;


	n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, &sx,&sy, NULL,NULL );


	if ( p->layer_whole_grab_onoff )
	{

		n_type_int i = 0;
		n_posix_loop
		{

			if ( b == NULL )
			{

				n_bmp_new_fast( &p->layer_data[ i ].bmp_grab, sx,sy );
				n_bmp_fastcopy( &p->layer_data[ i ].bmp_data, &p->layer_data[ i ].bmp_grab, x,y,sx,sy, 0,0 );

			} else {

				p->pen_bmp_data = &p->layer_data[ i ].bmp_data;
				p->pen_bmp_grab = &p->layer_data[ i ].bmp_grab;

				n_bmp_free( &p->layer_data[ i ].bmp_grab );
				n_bmp_carboncopy( b, &p->layer_data[ i ].bmp_grab );

				sx = N_BMP_SX( b );
				sy = N_BMP_SY( b );

			}

			i++;
			if ( i >= p->layer_count ) { break; }
		}

	} else
	if ( p->layer_onoff )
	{

		if ( b == NULL )
		{
//NSLog( @" 2-0 : %d ", p->layer_index );

			n_bmp_new_fast( p->pen_bmp_grab, sx,sy );
			n_bmp_fastcopy( p->pen_bmp_data, p->pen_bmp_grab, x,y,sx,sy, 0,0 );

		} else {
//NSLog( @" 2-1 " );

			n_type_int y = p->layer_index;

			p->pen_bmp_data = &p->layer_data[ y ].bmp_data;
			p->pen_bmp_grab = &p->layer_data[ y ].bmp_grab;

			n_bmp_free( p->pen_bmp_grab );
			n_bmp_carboncopy( b, p->pen_bmp_grab );

			sx = N_BMP_SX( b );
			sy = N_BMP_SY( b );

		}

	} else {
//n_posix_debug_literal( " 3 " );

		if ( b == NULL )
		{

			n_bmp_new_fast( p->pen_bmp_grab, sx,sy );
			n_bmp_fastcopy( p->pen_bmp_data, n_paint_global.paint->pen_bmp_grab, x,y,sx,sy, 0,0 );

		} else {

			n_bmp_free( p->pen_bmp_grab );
			n_bmp_carboncopy( b, p->pen_bmp_grab );

			sx = N_BMP_SX( b );
			sy = N_BMP_SY( b );

		}

	}

	n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );


	if ( redraw ) { n_paint_grabber_resync_auto(); }


	return;
}

void
n_paint_grabber_position_reset( void )
{

	if ( n_paint_global.paint->grabber_mode == N_PAINT_GRABBER_NEUTRAL ) { return; }


	n_type_gfx x,y, fx,fy; n_paint_grabber_system_get( &x,&y, NULL,NULL, &fx,&fy );

	x = fx;
	y = fy;

	n_paint_grabber_system_set( &x,&y, NULL,NULL, &fx,&fy );

	n_paint_grabber_resync_auto();


	return;
}

// internal
void
n_paint_grabber_filter_sync_calc( n_bmp *bmp_base, int filter_type )
{

	n_type_gfx psx = N_BMP_SX( bmp_base );
	n_type_gfx psy = N_BMP_SY( bmp_base );


	n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );
//NSLog( @"Before : %d %d %d %d ", x, y, sx, sy );

	n_type_gfx px = x;
	n_type_gfx py = y;

	if ( filter_type == N_PAINT_FILTER_SCALE_LIL )
	{
		 x =  x / 2;
		 y =  y / 2;
		sx = sx / 2;
		sy = sy / 2;
	} else
	if ( filter_type == N_PAINT_FILTER_SCALE_BIG )
	{
//NSLog( @"N_PAINT_FILTER_SCALE_BIG" );
		 x =  x * 2;
		 y =  y * 2;
		sx = sx * 2;
		sy = sy * 2;
	} else
	if ( filter_type == N_PAINT_FILTER_MIRROR    )
	{
		x = psx - ( x + sx );
	} else
	if ( filter_type == N_PAINT_FILTER_ROTATE_L  )
	{
		x = py;
		y = psx - ( px + sx );
	} else
	if ( filter_type == N_PAINT_FILTER_ROTATE_R  )
	{
		x = psy - ( py + sy );
		y = px;
	}

	fx = x;
	fy = y;

//NSLog( @"After : %d %d %d %d ", x, y, sx, sy );

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	return;
}

void
n_paint_grabber_filter_go( n_bmp *b, int mode )
{

	const int mirror = N_BMP_MIRROR_LEFTSIDE_RIGHT;


	if ( mode == N_PAINT_FILTER_SCALE_LIL ) { n_bmp_scaler_lil(    b, 2                  ); } else
	if ( mode == N_PAINT_FILTER_SCALE_BIG ) { n_bmp_scaler_big(    b, 2                  ); } else
	if ( mode == N_PAINT_FILTER_MIRROR    ) { n_bmp_flush_mirror(  b, mirror             ); } else
	if ( mode == N_PAINT_FILTER_ROTATE_L  ) { n_bmp_rotate(        b, N_BMP_ROTATE_LEFT  ); } else
	if ( mode == N_PAINT_FILTER_ROTATE_R  ) { n_bmp_rotate(        b, N_BMP_ROTATE_RIGHT ); } else
	if ( mode == N_PAINT_FILTER_ALPHA_CLR ) { n_bmp_alpha_visible( b                     ); } else
	if ( mode == N_PAINT_FILTER_ALPHA_REV ) { n_bmp_alpha_reverse( b                     ); }// else


	return;
}

// internal
n_posix_bool
n_paint_grabber_filter_sync( int filter_type, n_posix_bool calc, n_posix_bool refresh )
{

	n_paint *p = n_paint_global.paint;


	if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL ) { return n_posix_false; }


	if ( p->tooltype != N_PAINT_TOOL_TYPE_GRABBER )
	{
		n_paint_grabber_filter_go( p->pen_bmp_data, filter_type );
	}


	if ( calc )
	{
		n_paint_grabber_filter_sync_calc( p->pen_bmp_data, filter_type );
	}


	n_bmp b; n_bmp_carboncopy( p->pen_bmp_grab, &b );

	n_paint_grabber_filter_go( &b, filter_type );

//n_paint_grabber_select( &b, n_false );

	{
		n_bmp_free( p->pen_bmp_grab );
		n_bmp_alias( &b, p->pen_bmp_grab );

		if ( calc )
		{
			n_type_gfx sx = N_BMP_SX( &b );
			n_type_gfx sy = N_BMP_SY( &b );

			n_paint_grabber_system_set( NULL,NULL, &sx,&sy, NULL,NULL );
		}

		if ( refresh ) { n_paint_grabber_resync_auto(); }
	}


	[n_paint_global.delegate NonnonPaintStatus];


	return n_posix_true;
}

#define N_PAINT_GRABBER_LOAD_FILE   ( 1 )
#define N_PAINT_GRABBER_LOAD_FILTER ( 2 )

#define n_paint_grabber_file(   f ) n_paint_grabber_load(    f, N_PAINT_GRABBER_LOAD_FILTER, 0 )
#define n_paint_grabber_filter( f ) n_paint_grabber_load( NULL, N_PAINT_GRABBER_LOAD_FILTER, f )

// internal
n_posix_bool
n_paint_grabber_load( n_posix_char *name, int mode, int filter_type )
{

	n_paint *p = n_paint_global.paint;


	n_bmp b; n_bmp_zero( &b );


	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{

		if ( p->tooltype != N_PAINT_TOOL_TYPE_GRABBER )
		{
			if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
			{
				return n_posix_false;
			} else {
				return n_posix_true;
			}
		}


		if ( p->layer_onoff )
		{
			if ( n_paint_layer_is_locked( p->layer_index ) ) { return n_posix_true; }
		}


		n_curico c; n_curico_zero( &c );

		if ( n_paint_load( name, &b, &c ) )
		{
			n_mac_window_dialog_ok( "Please Check" );

			return n_posix_true;
		}


		if ( p->layer_onoff )
		{
			n_type_int y = p->layer_index;

			p->pen_bmp_data = &p->layer_data[ y ].bmp_data;
			p->pen_bmp_grab = &p->layer_data[ y ].bmp_grab;
		}


#ifdef N_PAINT_FRAME_ANIM

		p->frame_anim_lock = n_posix_true;
		p->frame_anim_on();

#endif // #ifdef N_PAINT_FRAME_ANIM

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{

		if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{

			if ( p->layer_onoff )
			{
				n_type_int i = 0;
				n_posix_loop
				{
					n_paint_grabber_filter_go( &p->layer_data[ i ].bmp_data, filter_type );

					i++;
					if ( i >= p->layer_count ) { break; }
				}
			} else {
				n_paint_grabber_filter_go( p->pen_bmp_data, filter_type );
			}

			return n_posix_false;
		}

		if ( p->layer_onoff )
		{
//NSLog( @"grabbed" );

			if ( p->tooltype == N_PAINT_TOOL_TYPE_GRABBER )
			{
				n_paint_grabber_filter_sync( filter_type, n_posix_true, n_posix_true );
			} else {
				n_paint_grabber_filter_sync_calc( &p->layer_data[ 0 ].bmp_data, filter_type );

				n_type_int i = 0;
				n_posix_loop
				{//break;

					n_paint_grabber_filter_go( &p->layer_data[ i ].bmp_data, filter_type );
					n_paint_grabber_filter_go( &p->layer_data[ i ].bmp_grab, filter_type );

					i++;
					if ( i >= p->layer_count ) { break; }
				}

				n_paint_grabber_resync_auto();
			}


			return n_posix_false;

		} else {

			if ( p->tooltype == N_PAINT_TOOL_TYPE_GRABBER )
			{
				n_bmp_carboncopy( p->pen_bmp_grab, &b );
				n_paint_grabber_filter_go( &b, filter_type );
			} else {
				return n_paint_grabber_filter_sync( filter_type, n_posix_true, n_posix_true );
			}

		}

	} else { return n_posix_false; }


	p->grabber_mode = N_PAINT_GRABBER_DRAG_OK;


	n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );


	if ( mode == N_PAINT_GRABBER_LOAD_FILE )
	{

		x = y = 0;

		fx = x;
		fy = y;

	} else
	if ( mode == N_PAINT_GRABBER_LOAD_FILTER )
	{

		//

	}

	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	n_paint_grabber_select( &b, n_posix_true );


	n_bmp_free( &b );


	[n_paint_global.delegate NonnonPaintStatus];


	return n_posix_true;
}

void
n_paint_grabber_select_all( void )
{

	n_paint *p = n_paint_global.paint;

	if ( p->layer_onoff )
	{

		n_type_int i = 0;
		n_posix_loop
		{
			n_bmp_free( &p->layer_data[ i ].bmp_grab );

			i++;
			if ( i >= p->layer_count ) { break; }
		}

	} else {

		n_bmp_free( p->pen_bmp_grab );

	}

	n_paint_grabber_init();

	n_paint_grabber_select( p->pen_bmp_data, n_posix_true );


	n_paint_global.paint->grabber_mode = N_PAINT_GRABBER_DRAG_OK;
	[n_paint_global.delegate NonnonPaintStatus];


	return;
}

void
n_paint_grabber_copy( void )
{

	n_type_gfx x,y,fx,fy; n_paint_grabber_system_get( &x,&y, NULL,NULL, &fx,&fy );

	n_bmp_flush( n_paint_global.paint->pen_bmp_grab, n_bmp_white_invisible );
	n_paint_grabber_select( NULL, n_posix_false );

	fx = x;
	fy = y;

	n_paint_grabber_system_set( &x,&y, NULL,NULL, &fx,&fy );
	[n_paint_global.delegate NonnonPaintStatus];

	n_paint_grabber_resync_auto();


	return;
}

void
n_paint_grabber_paste( void )
{

	// [Needed] : n_bmp_flush() for out-of-bound

	n_paint_grabber_composition( n_paint_global.paint->pen_bmp_grab, n_paint_global.paint->pen_bmp_data, n_posix_true, n_posix_false );
	n_bmp_flush( n_paint_global.paint->pen_bmp_grab, n_bmp_white_invisible );

	n_paint_grabber_select( NULL, n_posix_false );

	n_paint_grabber_resync_auto();


	return;
}




void
NonnonPaintGrabber_mouseDown( n_paint *p, NSEvent *theEvent )
{

	if ( p->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { return; }


	if ( [theEvent clickCount] == 2 )
	{

		if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{
//n_win_text_set_literal( hwnd, "Grabber : NEUTRAL : WM_LBUTTONDBLCLK" );

			n_paint_grabber_select_all();

		} else

		if ( p->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
		{
//n_win_text_set_literal( hwnd, "Grabber : DRAG_OK : WM_LBUTTONDBLCLK" );

			n_paint_grabber_position_reset();

		}
		
	} else
	if ( [theEvent clickCount] == 1 )
	{

		if ( p->grabber_mode == N_PAINT_GRABBER_NEUTRAL )
		{

			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			{

				const n_type_gfx maxsx = N_BMP_SX( p->pen_bmp_data ) - 1;
				const n_type_gfx maxsy = N_BMP_SY( p->pen_bmp_data ) - 1;

				NSPoint pt = [n_paint_global n_paint_canvaspos];
				x = pt.x;
				y = pt.y;

				if ( x < 0 ) { x = 0; } else if ( x > maxsx ) { x = maxsx; }
				if ( y < 0 ) { y = 0; } else if ( y > maxsy ) { y = maxsy; }

			}


			p->grabber_drag_fx = fx = x;
			p->grabber_drag_fy = fy = y;

			sx = sy = 0;

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			p->grabber_mode = N_PAINT_GRABBER_SELECTING;

		} else

		if ( p->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
		{

			// Phase 1 : starting position and size

			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );


			// Phase 2 : switching to DnD mode

			n_type_gfx canvas_x,canvas_y;

			NSPoint pt = [n_paint_global n_paint_canvaspos];
			canvas_x = pt.x;
			canvas_y = pt.y;

			if (
				( canvas_x < x )||( canvas_x >= ( x + sx ) )
				||
				( canvas_y < y )||( canvas_y >= ( y + sy ) )
			)
			{
				return;
			}

//n_win_text_set_literal( hwnd, "Selected" );


			if ( FALSE == ( theEvent.modifierFlags & NSEventModifierFlagCommand ) )
			{

				p->grabber_mode = N_PAINT_GRABBER_DRAGGING;

				p->grabber_drag_ox = canvas_x - x;
				p->grabber_drag_oy = canvas_y - y;

			} else {

				if ( theEvent.modifierFlags & NSEventModifierFlagShift )
				{
					p->grabber_mode = N_PAINT_GRABBER_STRETCH_TRANSFORM;
				} else {
					p->grabber_mode = N_PAINT_GRABBER_STRETCH_PROPORTIONAL;
					p->grabber_stretch_ratio = (n_type_real) sx / sy;
				}


				// [!] : Backup

				if ( p->layer_whole_grab_onoff )
				{
					//p->grabber_stretch_bmp = n_memory_new( sizeof( n_bmp ) * p->layer_count );
					//n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_BACKUP, stretch_bmp, 0,0 );
				} else
				if ( p->layer_onoff )
				{
					p->grabber_stretch_bmp = n_memory_new( sizeof( n_bmp ) );
					n_bmp_carboncopy( p->pen_bmp_grab, p->grabber_stretch_bmp );
				} else {
					p->grabber_stretch_bmp = n_memory_new( sizeof( n_bmp ) );
					n_bmp_carboncopy( p->pen_bmp_grab, p->grabber_stretch_bmp );
				}

				p->grabber_stretch_px = x;
				p->grabber_stretch_py = y;


				// [!] : Init

				p->grabber_stretch_sx = sx;
				p->grabber_stretch_sy = sy;
				p->grabber_stretch_ox =  x + ( p->grabber_stretch_sx / 2 );
				p->grabber_stretch_oy =  y + ( p->grabber_stretch_sy / 2 );

				//n_paint_grabber_cursor_automove( x,y, sx,sy );


				NSPoint pt = [n_paint_global n_paint_canvaspos];
				p->grabber_stretch_fx = pt.x;
				p->grabber_stretch_fy = pt.y;

				[n_paint_global.delegate NonnonPaintStatus];

			}
		}

	}


	return;
}

void
NonnonPaintGrabber_mouseDragged( n_paint *p )
{

	if ( p->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { return; }


	if ( p->grabber_mode == N_PAINT_GRABBER_RESELECT )
	{
//NSLog( @"N_PAINT_GRABBER_RESELECT" );

		n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

		extern n_posix_bool n_paint_frame_is_hovered( n_paint *p, int index );

		if ( n_paint_frame_is_hovered( p, 0 ) )
		{
			x = p->grabber_drag_fx = x + sx;
			y = p->grabber_drag_fy = y + sy;
		} else 
		if ( n_paint_frame_is_hovered( p, 1 ) )
		{
			x = p->grabber_drag_fx = x;
			y = p->grabber_drag_fy = y + sy;
		} else 
		if ( n_paint_frame_is_hovered( p, 2 ) )
		{
			x = p->grabber_drag_fx = x;
			y = p->grabber_drag_fy = y;
		} else 
		if ( n_paint_frame_is_hovered( p, 3 ) )
		{
			x = p->grabber_drag_fx = x + sx;
			y = p->grabber_drag_fy = y;
		}

		n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );

		p->grabber_mode = N_PAINT_GRABBER_SELECTING;

		p->grabber_is_resel = n_posix_true;

	} else

	if ( p->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
	{

	} else

	if ( p->grabber_mode == N_PAINT_GRABBER_SELECTING )
	{

		// Phase 1 : init

		n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

		{

			const n_type_gfx maxsx = N_BMP_SX( p->pen_bmp_data ) - 1;
			const n_type_gfx maxsy = N_BMP_SY( p->pen_bmp_data ) - 1;

			NSPoint pt = [n_paint_global n_paint_canvaspos];
			x = pt.x;
			y = pt.y;

			if ( x < 0 ) { x = 0; } else if ( x > maxsx ) { x = maxsx; }
			if ( y < 0 ) { y = 0; } else if ( y > maxsy ) { y = maxsy; }

		}


		// Phase 2 : size : +1 for including outer

		sx = abs( p->grabber_drag_fx - x ) + 1;
		sy = abs( p->grabber_drag_fy - y ) + 1;


		// Phase 3 : position : top-left

		fx = x = n_posix_min_n_type_gfx( p->grabber_drag_fx, x );
		fy = y = n_posix_min_n_type_gfx( p->grabber_drag_fy, y );


		n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


		// [!] : selection is delayed : see WM_LBUTTONUP below
		//
		//	n_paint_grabber_resync_auto() adds a frame automatically

		if ( p->grabber_is_resel )
		{
			n_paint_grabber_select( NULL, n_posix_true );
		} else {
			n_paint_grabber_resync_auto_fast();
		}

	} else

	if ( p->grabber_mode == N_PAINT_GRABBER_DRAGGING )
	{
//n_win_text_set_literal( hwnd, "Grabber : DRAGGING : WM_MOUSEMOVE" );


		n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

		NSPoint pt = [n_paint_global n_paint_canvaspos];
		x = pt.x;
		y = pt.y;

		x -= p->grabber_drag_ox;
		y -= p->grabber_drag_oy;

		n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


		n_paint_grabber_resync_auto();

	} else

	if (
		( p->grabber_mode == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
		||
		( p->grabber_mode == N_PAINT_GRABBER_STRETCH_TRANSFORM )
	)
	{

		// Phase 1 : init

		n_type_gfx x,y,sx,sy; n_paint_grabber_system_get( &x,&y, NULL,NULL, NULL,NULL );


		// [!] : don't clip for usability

		NSPoint pt = [n_paint_global n_paint_canvaspos];
		x = pt.x;
		y = pt.y;

		if ( ( p->grabber_stretch_fx == x )&&( p->grabber_stretch_fy == y ) ) { return; }

		p->grabber_stretch_fx = x;
		p->grabber_stretch_fy = y;


		// Phase 2 : size

		if ( p->grabber_mode == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
		{
			sy = ( abs( p->grabber_stretch_oy - y ) * 2 );
			sx = (n_type_gfx) ( (n_type_real) sy * p->grabber_stretch_ratio );
		} else {
			sx = ( abs( p->grabber_stretch_ox - x ) * 2 );
			sy = ( abs( p->grabber_stretch_oy - y ) * 2 );
		}

		if ( sx == 0 ) { sx = 1; }
		if ( sy == 0 ) { sy = 1; }

//n_win_hwndprintf_literal( hwnd, "%d : %d", (int) sx, (int) sy );


		// Phase 3 : position

		x = p->grabber_stretch_ox - ( sx / 2 );
		y = p->grabber_stretch_oy - ( sy / 2 );


		n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );


		{ // n_paint_grabber_transform()

		n_type_real ratio_x = (n_type_real) sx / p->grabber_stretch_sx;
		n_type_real ratio_y = (n_type_real) sy / p->grabber_stretch_sy;

		if ( ( ratio_x * p->grabber_stretch_sx ) == 0 ) { return; }
		if ( ( ratio_y * p->grabber_stretch_sy ) == 0 ) { return; }

		if ( p->layer_whole_grab_onoff )
		{
/*
			n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESAMPLE, stretch_bmp, ratio_x,ratio_y );

			sx = 0;
			sy = 0;

			int i = 0;
			n_posix_loop
			{

				sx = n_posix_max_n_type_gfx( sx, N_BMP_SX( &p->layer_data[ i ].bmp_grab ) );
				sy = n_posix_max_n_type_gfx( sy, N_BMP_SY( &p->layer_data[ i ].bmp_grab ) );

				i++;
				if ( i >= p->layer_count ) { break; }
			}

			n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );
			n_paint_grabber_resync_auto();
*/
		} else
		if ( p->layer_onoff )
		{

			n_bmp b; n_bmp_carboncopy( p->grabber_stretch_bmp, &b );

			n_bmp_resampler( &b, ratio_x,ratio_y );
			n_paint_grabber_select( &b, n_posix_true );

			n_bmp_free( &b );

		} else {

			n_bmp b; n_bmp_carboncopy( p->grabber_stretch_bmp, &b );

			n_bmp_resampler( &b, ratio_x,ratio_y );
			n_paint_grabber_select( &b, n_posix_true );

			n_bmp_free( &b );

		}

		} // n_paint_grabber_transform()

	}// else


	[n_paint_global.delegate NonnonPaintStatus];

}

void
NonnonPaintGrabber_mouseUp( n_paint *p )
{

	if ( p->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { return; }


	if ( p->grabber_mode == N_PAINT_GRABBER_SELECTING )
	{
//n_win_text_set_literal( hwnd, "Grabber : SELECTING : WM_LBUTTONUP" );


		p->grabber_is_resel = n_posix_false;


		n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

//n_win_hwndprintf_literal( hwnd, "%d : %d", (int) sx, (int) sy );


		if ( ( sx <= 0 )&&( sy <= 0 ) )
		{

			p->grabber_mode = N_PAINT_GRABBER_NEUTRAL;

			return;
		}


		// position : use the last position
		// size     : use the last size


		// [!] : delayed
		n_paint_grabber_select( NULL, n_posix_true );


		p->grabber_mode = N_PAINT_GRABBER_DRAG_OK;

	} else

	if ( p->grabber_mode == N_PAINT_GRABBER_DRAGGING )
	{
//n_win_text_set_literal( hwnd, "Grabber : DRAGGING : WM_LBUTTONUP" );

		p->grabber_mode = N_PAINT_GRABBER_DRAG_OK;

	} else

	if (
		( p->grabber_mode == N_PAINT_GRABBER_STRETCH_PROPORTIONAL )
		||
		( p->grabber_mode == N_PAINT_GRABBER_STRETCH_TRANSFORM )
	)
	{
//n_win_text_set_literal( hwnd, "Grabber : STRETCHING : WM_LBUTTONUP" );


		n_posix_bool ret = 1;//n_paint_dialog_yesno( n_project_string_really_ok );
		if ( ret )
		{

			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			fx = x;
			fy = y;

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );

		} else {

			// [!] : reselect an area before stretching

			n_type_gfx x,y,sx,sy,fx,fy; n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

			x = p->grabber_stretch_px;
			y = p->grabber_stretch_py;

			n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


			if ( p->layer_whole_grab_onoff )
			{
/*
				//n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_RESET, stretch_bmp, 0,0 );

				sx = 0;
				sy = 0;

				int i = 0;
				n_posix_loop
				{

					sx = n_posix_max_n_type_gfx( sx, N_BMP_SX( &p->layer_data[ i ].bmp_grab ) );
					sy = n_posix_max_n_type_gfx( sy, N_BMP_SY( &p->layer_data[ i ].bmp_grab ) );

					i++;
					if ( i >= p->layer_count ) { break; }
				}

				n_paint_grabber_system_set( &x,&y, &sx,&sy, NULL,NULL );
				n_paint_grabber_resync_auto();
*/
			} else
			if ( p->layer_onoff )
			{
				n_paint_grabber_select( p->grabber_stretch_bmp, n_posix_true );
			} else {
				n_paint_grabber_select( p->grabber_stretch_bmp, n_posix_true );
			}

		}


		if ( p->layer_whole_grab_onoff )
		{
			//n_paint_grabber_wholegrb_stretch( N_PAINT_GRABBER_WHOLEGRAB_STRETCH_FREE, stretch_bmp, 0,0 );
		} else
		if ( p->layer_onoff )
		{
			n_bmp_free( p->grabber_stretch_bmp );
		} else {
			n_bmp_free( p->grabber_stretch_bmp );
		}

		n_memory_free( p->grabber_stretch_bmp );


		p->grabber_mode = N_PAINT_GRABBER_DRAG_OK;


		n_paint_grabber_resync_auto_fast();

	}



	return;
}




void
NonnonPaintGrabber_rightMouseDown( n_paint *p )
{

	if ( p->tooltype != N_PAINT_TOOL_TYPE_GRABBER ) { return; }


	if ( p->grabber_mode == N_PAINT_GRABBER_DRAG_OK )
	{
		n_paint_grabber_finish();
	}

	return;
}




void
NonnonPaintGrabber_keyDown_arrow( n_paint *p, int keyCode )
{

	if ( p->grabber_mode != N_PAINT_GRABBER_DRAG_OK ) { return; }

	n_type_gfx x,y,sx,sy,fx,fy;
	n_paint_grabber_system_get( &x,&y, &sx,&sy, &fx,&fy );

	switch( keyCode ) {

	case N_MAC_KEYCODE_ARROW_UP :
	
		y--;
	
	break;

	case N_MAC_KEYCODE_ARROW_DOWN :

		y++;

	break;


	case N_MAC_KEYCODE_ARROW_LEFT :

		x--;

	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:

		x++;

	break;

	} // switch
			
	n_paint_grabber_system_set( &x,&y, &sx,&sy, &fx,&fy );


	n_paint_grabber_resync_auto();

	[n_paint_global.delegate NonnonPaintStatus];


	return;
}



// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@implementation NonnonTxtbox (NonnonTxtboxKeyboard)


- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}




- (BOOL) n_is_full_stop
{

	BOOL ret = FALSE;

	if (
		( caret_fr.cch.x == 0 )&&( caret_fr.cch.y == 0 )
		&&
		( caret_to.cch.x == 0 )&&( caret_to.cch.y == 0 )

	)
	{
		ret = TRUE;
	}

	return ret;
}

- (void) n_detect_key_move:(void*) zero ud:(n_type_int)ud lr:(n_type_int)lr 
{
//NSLog( @"%f", n_focus );


	// [!] : unselect

	if ( ( caret_fr.pxl.x != caret_to.pxl.x )&&( caret_fr.cch.y != caret_to.cch.y ) )
	{
		caret_fr = caret_to;
	}


	n_focus += ud;
	if ( n_focus < 0 )
	{
		if ( n_focus <= -1 ) { caret_fr.cch.x = 0; }
		n_focus = 0;
	}
	if ( n_focus >= n_txt->sy ) { n_focus = n_txt->sy - 1; }


	if ( ud )
	{
		NSRect r = NSMakeRect( padding, offset, [self frame].size.width - ( offset * 2 ), font_size.height );

		caret_fr = n_txtbox_caret_detect_pixel2caret
		(
			n_txt,
			n_focus,
			r,
			font,
			font_size,
			NSMakePoint( padding + caret_fr.pxl.x, caret_fr.cch.y + font_size.height )
		);
//NSLog( @"%0.2f", caret_fr.pxl.x );

		// [!] : Win32 compatible behavior 
		if ( caret_fr.pxl.x == 0 ) { caret_fr.cch.x = 0; }
	}


	if ( lr != 0 )
	{
		n_posix_char *s = n_txt_get( n_txt, n_focus );
		if ( lr < 0 )
		{
			if ( caret_fr.cch.x == 0 )
			{
				if ( n_focus != 0 )
				{
					n_focus--;
					caret_fr.cch.x = caret_to.cch.x = n_posix_strlen( n_txt_get( n_txt, n_focus ) );
				}
			} else {
				caret_fr.cch.x = caret_to.cch.x = n_mac_txtbox_caret_move( s, caret_fr.cch.x, YES, N_MAC_TXTBOX_CARET_MOVE_L );	
			}
		} else {
			if ( caret_fr.cch.x == n_posix_strlen( n_txt_get( n_txt, n_focus ) ) )
			{
				n_type_int max_sy = n_txt->sy - 1;
				if ( n_focus < max_sy )
				{
					n_focus++;
					caret_fr.cch.x = 0;
				}
			} else {
				caret_fr.cch.x = n_mac_txtbox_caret_move( s, caret_fr.cch.x, YES, N_MAC_TXTBOX_CARET_MOVE_R );	
			}
		}
	}


	caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		caret_fr.cch.x
	);


	return;
}

- (n_caret) n_detect_key_shift_selection:(void*)zero lr:(n_type_int)lr cch:(n_type_int)cch
{
//NSLog( @"%f", n_focus );

	n_posix_char *s = n_txt_get( n_txt, n_focus );
	if ( lr < 0 )
	{
		cch = n_mac_txtbox_caret_move( s, cch, YES, N_MAC_TXTBOX_CARET_MOVE_L );
	} else {
		cch = n_mac_txtbox_caret_move( s, cch, YES, N_MAC_TXTBOX_CARET_MOVE_R );
	}
//NSLog( @"%lld", (*cch) );

	n_caret caret = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		cch
	);


	return caret;
}




- (void)n_txtbox_input_method:(NSEvent*)event
{
//return;

#ifdef N_TXTBOX_IME_ENABLE

	if ( ime_onoff )
	{
		[self display];

		return;
	}

#endif

	n_edited = TRUE;
	[self.delegate NonnonTxtbox_delegate_edited:n_edited];


	n_mac_txtbox_del( n_txt, &n_focus, &caret_fr, &caret_to );
//return;

	[self n_caret_out_of_canvas_lr];
//return;

	n_posix_char *line_f = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
	n_posix_char *line_m = n_mac_nsstring2str( [event characters] );
	n_posix_char *line_t = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );

	line_f[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;
	n_posix_sprintf_literal( line_t, "%s", &line_t[ caret_fr.cch.x ] );

	n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( line_m ) + n_posix_strlen( line_t );
	n_posix_char *s   = n_string_new( cch );
	n_posix_sprintf_literal( s, "%s%s%s", line_f, line_m, line_t );
//NSLog( @"%s : %s : %s", line_f, line_m, line_t );

	//NSString *tmp = [[NSString alloc] initWithUTF8String:s];
//NSLog( @"%@", tmp );

	n_txt_mod( n_txt, n_focus, s );


	caret_fr.cch.x = caret_to.cch.x = n_posix_strlen( line_f ) + n_posix_strlen( line_m );

	caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
	(
		n_txt,
		n_focus,
		font,
		font_size,
		caret_fr.cch.x
	);


	n_string_free( s );


	n_string_free( line_f );
	n_string_free( line_m );
	n_string_free( line_t );


	[self n_undo:N_TXTBOX_UNDO_SUSPEND];


	[self display];

}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d : Chars %@", event.keyCode, event.characters );


	caret_blink_force_onoff = TRUE;


#ifdef N_TXTBOX_IME_ENABLE

//NSLog( @"IME On/Off : %@ : %d", ime_nsstr, ime_onoff );

	ime = [NSTextInputContext currentInputContext];
	[ime handleEvent:event];

	if ( ime_onoff )
	{
		if ( event.keyCode == N_MAC_KEYCODE_BACKSPACE )
		{
//NSLog( @"%@ %d", ime_nsstr, (int) [ime_nsstr length] );

			NSUInteger cch = [ime_nsstr length];

			if ( ime_freed )
			{
				[ime discardMarkedText];
				ime_nsstr = @"";
				ime_onoff = FALSE;
				ime_freed = FALSE;
				cch       = 0;
			}

			if ( cch == 1 )
			{
				ime_freed = TRUE;
			}

			[self display];

			return;
		} else
		if ( event.keyCode != N_MAC_KEYCODE_ENTER )
		{
			[self display];

			return;
		}
	}

#endif


	switch( event.keyCode ) {

	case N_MAC_KEYCODE_HOME:
	case N_MAC_KEYCODE_END:
	case N_MAC_KEYCODE_DELETE:
	case N_MAC_KEYCODE_PRTSCN:
	case N_MAC_KEYCODE_F1:
	case N_MAC_KEYCODE_F2:
	//case N_MAC_KEYCODE_F3: // see below
	case N_MAC_KEYCODE_F4:
	case N_MAC_KEYCODE_F5:
	case N_MAC_KEYCODE_F6:
	case N_MAC_KEYCODE_F7:
	case N_MAC_KEYCODE_F8:
	case N_MAC_KEYCODE_F9:
	case N_MAC_KEYCODE_F10:
	case N_MAC_KEYCODE_F12:
	{
	
		//

	}
	break;

	case N_MAC_KEYCODE_ARROW_UP :
	{
//NSLog( @"Up" );

		if ( event.modifierFlags & NSEventModifierFlagShift )
		{
		
			n_caret caret = caret_fr;

			[self n_detect_key_move:nil ud:-1 lr:0];

			caret_fr = caret;

		} else {

			[self n_detect_key_move:nil ud:-1 lr:0];

		}

		[self n_caret_out_of_canvas_ud];

		// [!] : [self display] paints gray on all contents(client) area
		//redraw_fy = caret_fr.cch.y;
		//redraw_ty = redraw_fy + 2;

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ARROW_DOWN:
	{
//NSLog( @"Down" );

		if ( event.modifierFlags & NSEventModifierFlagShift )
		{

			n_caret caret = caret_fr;

			[self n_detect_key_move:nil ud:1 lr:0];

			caret_fr = caret;

		} else {

			[self n_detect_key_move:nil ud:1 lr:0];

		}

		[self n_caret_out_of_canvas_ud];

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ARROW_LEFT:
	{
//NSLog( @"Left" );

		[self n_caret_out_of_canvas_lr];

		if ( event.modifierFlags & NSEventModifierFlagShift )
		{
			if ( caret_fr.cch.x == caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					shift_selection_is_tail = FALSE;
				}
				caret_to = [self n_detect_key_shift_selection:nil lr:-1 cch:caret_to.cch.x];
			} else
			if ( caret_fr.cch.x < caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					caret_to = [self n_detect_key_shift_selection:nil lr:-1 cch:caret_to.cch.x];
				} else {
					//
				}
			} else
			if ( caret_fr.cch.x > caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
				} else {
					caret_to = [self n_detect_key_shift_selection:nil lr:-1 cch:caret_to.cch.x];
				}
			}
		} else
		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			[self n_detect_doubleclick];
			caret_to = caret_fr;

			n_posix_char *line = n_txt_get( n_txt, n_focus );
			caret_to.cch.x = caret_fr.cch.x = n_mac_txtbox_caret_move( line, caret_to.cch.x, YES, N_MAC_TXTBOX_CARET_MOVE_L );
		} else {
			[self n_detect_key_move:nil ud:0 lr:-1];
		}

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ARROW_RIGHT:
	{
//NSLog( @"Right" );

		[self n_caret_out_of_canvas_lr];

		if ( event.modifierFlags & NSEventModifierFlagShift )
		{
			if ( caret_fr.cch.x == caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					//
				} else {
					shift_selection_is_tail = TRUE;
				}
				caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
			} else
			if ( caret_fr.cch.x < caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
				} else {
					caret_fr = [self n_detect_key_shift_selection:nil lr:1 cch:caret_fr.cch.x];
				}
			} else
			if ( caret_fr.cch.x > caret_to.cch.x )
			{
				if ( shift_selection_is_tail )
				{
					caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
				} else {
					caret_to = [self n_detect_key_shift_selection:nil lr:1 cch:caret_to.cch.x];
				}
			}
		} else
		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			[self n_detect_doubleclick];
			caret_fr = caret_to;
		} else {
			[self n_detect_key_move:nil ud:0 lr:1];
		}

		[self display];
	}
	break;

	case N_MAC_KEYCODE_ENTER:
	{

		if ( n_txt->readonly ) { break; }


#ifdef N_TXTBOX_IME_ENABLE

		if ( ime_onoff )
		{
//NSLog( @"modified cch : %lld", ime_caret_fr.cch.x );

			n_mac_txtbox_del( n_txt, &n_focus, &caret_fr, &caret_to );
//n_caret_debug_cch( caret_fr, caret_to );

			n_posix_char *line = n_txt_get( n_txt, n_focus );

			n_posix_char *line_f = n_string_carboncopy( line );
			n_posix_char *line_m = n_mac_nsstring2str( ime_nsstr );
			n_posix_char *line_t = n_string_carboncopy( line );

//NSLog( @"modified : %s : %@", line_f, n_mac_str2nsstring( line_t ) );


			n_type_int cch_f = n_posix_strlen( line_f );
			n_type_int cch_m = n_posix_strlen( line_m );
			n_type_int cch_t = n_posix_strlen( line_t );


			n_posix_char *mod = n_string_new( cch_f + cch_m + cch_t );

			if ( ime_caret_fr.cch.x < cch_f )
			{
				line_f[ ime_caret_fr.cch.x ] = N_STRING_CHAR_NUL;
			}
//NSLog( @"%s", line_f );

			n_type_int cch_cut = ime_caret_to.cch.x;
//NSLog( @"cch_cut : %lld", cch_cut );

			if ( ( cch_cut >= 0 )&&( cch_cut < cch_f ) )
			{
				n_posix_sprintf_literal( line_t, "%s", &line_t[ cch_cut ] );
			} else {
				n_string_truncate( line_t );
			}

			n_posix_sprintf_literal( mod, "%s%s%s", line_f, line_m, line_t );

			n_txt_mod_fast( n_txt, n_focus, mod );


			n_string_free( line_f );
			n_string_free( line_m );
			n_string_free( line_t );


			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				ime_caret_fr.cch.x + cch_m
			);

			ime_caret_fr = caret_fr;
			ime_caret_to = caret_to;


			[ime discardMarkedText];
			ime_nsstr = @"";
			ime_onoff = FALSE;


			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];


			[self n_undo:N_TXTBOX_UNDO_SUSPEND];
			[self display];


			return;
			
		}

#endif

		if ( n_mac_txtbox_del( n_txt, &n_focus, &caret_fr, &caret_to ) )
		{

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				caret_fr.cch.x
			);

			[self n_caret_out_of_canvas_ud];

//n_caret_debug_cch( caret_fr ,caret_to );

		} else {
//NSLog( @"divide" );
			n_posix_char *line = n_txt_get( n_txt, n_focus );
			n_posix_char *s    = n_string_carboncopy( line );

			n_txt_add( n_txt, n_focus + 1, &s[ caret_fr.cch.x ] );
			line[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;

			n_string_free( s );


			n_focus++;
			caret_fr = caret_to = NonnonMakeCaret( 0, n_focus * font_size.height, 0, n_focus );


			CGFloat f = ( ( n_focus - scroll ) * font_size.height ) + font_size.height;
			CGFloat t = [self frame].size.height - ( offset * 2 );
			if ( f >= t ) { scroll += font_size.height; }

		}

		[self n_undo:N_TXTBOX_UNDO_SUSPEND];

		n_edited = TRUE;
		[self.delegate NonnonTxtbox_delegate_edited:n_edited];

		[self display];

	}
	break;

	case N_MAC_KEYCODE_BACKSPACE:
	{

		if ( n_txt->readonly ) { break; }


		if ( [self n_is_full_stop] ) { break; }


		if ( event.modifierFlags & NSEventModifierFlagShift )
		{

			n_type_int count = llabs( caret_fr.cch.y - caret_to.cch.y ) + 1;
			n_type_int min_y =   MIN( caret_fr.cch.y,  caret_to.cch.y );

			n_type_int y = 0;
			n_posix_loop
			{
				if ( y >= count ) { break; }

				n_posix_char *line = n_txt_get( n_txt, min_y + y );

				if ( line[ 0 ] == N_STRING_CHAR_TAB )
				{
					n_posix_char *str = n_string_new( n_posix_strlen( line ) );
					n_posix_sprintf_literal( str, "%s", &line[ 1 ] );

					n_txt_mod_fast( n_txt, min_y + y, str );
				}

				y++;
			}

			caret_fr.cch.x--;
			caret_to.cch.x--;

			n_type_int cch;
			if ( shift_selection_is_tail )
			{
				cch = caret_to.cch.x;
			} else {
				cch = caret_fr.cch.x;
			}

			n_type_int fr_cch_y = caret_fr.cch.y;
			n_type_int to_cch_y = caret_to.cch.y;

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				cch
			);

			caret_fr.cch.y = fr_cch_y;
			caret_to.cch.y = to_cch_y;

			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];

			[self display];

			break;		
		}

		[self n_caret_out_of_canvas_lr];

//n_caret_debug_cch( caret_fr ,caret_to );// break;

		BOOL grow = ( caret_fr.cch.y < caret_to.cch.y );

		if ( n_mac_txtbox_del( n_txt, &n_focus, &caret_fr, &caret_to ) )
		{
//NSLog( @"Backspace : deleted : %0.2f %lld %lld", n_focus, caret_fr.cch.y, caret_to.cch.y );

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				caret_fr.cch.x
			);

			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];

			[self display];

			break;
		}

		if ( caret_fr.cch.x == 0 )
		{
//NSLog( @"Backspace : zero" );

			if ( n_focus == 0 )
			{
				// [!] : for select all
				caret_fr = caret_to = NonnonMakeCaret( 0,0,0,0 );
				[self display];
				break;
			}


			n_posix_char *line_1 = n_txt_get( n_txt, n_focus - 1 );
			n_posix_char *line_2 = n_txt_get( n_txt, n_focus     );

			n_type_int    cch = n_posix_strlen( line_1 ) + n_posix_strlen( line_2 );
			n_posix_char *s   = n_string_new( cch );
			n_posix_sprintf_literal( s, "%s%s", line_1, line_2 );

			n_txt_del( n_txt, n_focus );
			n_txt_mod( n_txt, n_focus - 1, s );

			caret_fr.cch.x = caret_to.cch.x = n_posix_strlen( line_1 );

			n_focus--;

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				caret_fr.cch.x
			);

			n_string_free( s );

		} else {
//NSLog( @"Backspace : normal" );

			n_posix_char *line = n_txt_get( n_txt, n_focus );
			n_type_int     cch = n_mac_txtbox_caret_move( line, caret_fr.cch.x, NO, N_MAC_TXTBOX_CARET_MOVE_L );

			n_posix_sprintf_literal( &line[ cch ], "%s", &line[ caret_fr.cch.x ] );

			if ( grow ) { n_focus = caret_fr.cch.y; }

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				cch
			);

		}

		[self n_undo:N_TXTBOX_UNDO_SUSPEND];

		n_edited = TRUE;
		[self.delegate NonnonTxtbox_delegate_edited:n_edited];

		[self display];

	}
	break;

	case N_MAC_KEYCODE_TAB:
	{

		// [x] : you cannot use Ctrl + Tab : system uses

		//if ( event.modifierFlags & NSEventModifierFlagCommand )
		if ( event.modifierFlags & NSEventModifierFlagShift )
		{

			n_type_int count = llabs( caret_fr.cch.y - caret_to.cch.y ) + 1;
			n_type_int min_y =   MIN( caret_fr.cch.y,  caret_to.cch.y );

			n_type_int y = 0;
			n_posix_loop
			{
				if ( y >= count ) { break; }

				n_posix_char *line = n_txt_get( n_txt, min_y + y );

				if ( n_posix_false == n_string_is_empty( line ) )
				{
					n_posix_char *str = n_string_new( n_posix_strlen( line ) + 1 );
					n_posix_sprintf_literal( str, "%s%s", N_STRING_TAB, line );

					n_txt_mod_fast( n_txt, min_y + y, str );
				}

				y++;
			}

			caret_fr.cch.x++;
			caret_to.cch.x++;

			n_type_int cch;
			if ( shift_selection_is_tail )
			{
				cch = caret_to.cch.x;
			} else {
				cch = caret_fr.cch.x;
			}

			n_type_int fr_cch_y = caret_fr.cch.y;
			n_type_int to_cch_y = caret_to.cch.y;

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				cch
			);

			caret_fr.cch.y = fr_cch_y;
			caret_to.cch.y = to_cch_y;

			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];

			[self display];
		} else {
			[self n_txtbox_input_method:event];
		}
	
	}
	break;

	case N_MAC_KEYCODE_CUT:
	{

		if ( n_txt->readonly ) { break; }


		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			[self n_undo:N_TXTBOX_UNDO_RESET];

			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];


			NSString *s = n_mac_txtbox_copy( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );

			NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
			[pasteboard clearContents];
			[pasteboard writeObjects:@[ s ]];

			n_mac_txtbox_del( n_txt, &n_focus, &caret_fr, &caret_to );

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				caret_fr.cch.x
			);

			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}
	}
	break;

	case N_MAC_KEYCODE_COPY: 
	{
		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			NSString *s = n_mac_txtbox_copy( n_txt, caret_fr.cch.x, caret_fr.cch.y, caret_to.cch.x, caret_to.cch.y );
//NSLog( @"%@", s );
			NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
			[pasteboard clearContents];
			[pasteboard writeObjects:@[ s ]];
		} else {
			[self n_txtbox_input_method:event];
		}
	}
	break;

	case N_MAC_KEYCODE_PASTE:
	{

		if ( n_txt->readonly ) { break; }


		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			[self n_undo:N_TXTBOX_UNDO_RESET];

			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];

			n_mac_txtbox_del( n_txt, &n_focus, &caret_fr, &caret_to );

			NSPasteboard *p = [NSPasteboard generalPasteboard];
			NSString     *s = [p stringForType:NSPasteboardTypeString];
			n_posix_char *c = n_mac_nsstring2str( s );
//NSLog( @"%@", s );
//NSLog( @"%s", c );
			n_txt t; n_txt_zero( &t ); n_txt_load_utf8_onmemory( &t, c, n_posix_strlen( c ) );
//NSLog( @"%lld", t.sy );

			if ( t.sy == 1 )
			{

				n_posix_char *line_f = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				n_posix_char *line_m = n_string_carboncopy( n_txt_get(    &t,       0 ) );
				n_posix_char *line_t = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				
				line_f[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;
				sprintf( line_t, "%s", &line_t[ caret_fr.cch.x ] );
//NSLog( @"%s", line_f );
//NSLog( @"%s", line_t );

				n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( line_m ) + n_posix_strlen( line_t );
				n_posix_char *str = n_string_new( cch );
				n_posix_sprintf_literal( str, "%s%s%s", line_f, line_m, line_t );

				n_txt_mod( n_txt, n_focus, str );

				n_string_free( str );


				caret_fr.cch.x = caret_to.cch.x = caret_fr.cch.x + n_posix_strlen( line_m );

				caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
				(
					n_txt,
					n_focus,
					font,
					font_size,
					caret_fr.cch.x
				);


				n_string_free( line_f );
				n_string_free( line_m );
				n_string_free( line_t );

			} else {
//break;
				n_posix_char *line_f = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				n_posix_char *line_t = n_string_carboncopy( n_txt_get( n_txt, n_focus ) );
				
				line_f[ caret_fr.cch.x ] = N_STRING_CHAR_NUL;
				sprintf( line_t, "%s", &line_t[ caret_fr.cch.x ] );
//NSLog( @"%s", line_f );

				{
					n_type_int    cch = n_posix_strlen( line_f ) + n_posix_strlen( n_txt_get( &t, 0 ) );
					n_posix_char *str = n_string_new( cch );

					n_posix_sprintf_literal( str, "%s%s", line_f, n_txt_get( &t, 0 ) );
					n_txt_mod_fast( n_txt, n_focus, str );
				}


				n_type_int i = 1;
				n_posix_loop
				{//break;
					if ( i >= t.sy ) { break; }
					
					n_txt_add( n_txt, n_focus + i, n_txt_get( &t, i ) );
					
					i++;
				}

				{
					n_type_int    cch = n_posix_strlen( n_txt_get( &t, i - 1 ) ) + n_posix_strlen( line_t );
					n_posix_char *str = n_string_new( cch );

					n_posix_sprintf_literal( str, "%s%s", n_txt_get( &t, i - 1 ), line_t );
					n_txt_mod_fast( n_txt, n_focus + i - 1, str );
				}


				n_focus = n_focus + i - 1;

				caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
				(
					n_txt,
					n_focus,
					font,
					font_size,
					n_posix_strlen( n_txt_get( &t, i - 1 ) )
				);


				CGFloat csy              = self.frame.size.height - ( offset * 2 );
				CGFloat items_per_canvas = csy / font_size.height;

				if ( n_focus > ( scroll + items_per_canvas ) )
				{
					scroll = n_focus - items_per_canvas + 1 + 1; // [!] : fmod() may be needed
				}


				n_string_free( line_f );
				n_string_free( line_t );

			}

			n_txt_free( &t );


			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}

	}
	break;

	case N_MAC_KEYCODE_SELECT_ALL:
	{

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			caret_fr = NonnonMakeCaret( 0, 0, 0, 0 );

			n_caret caret = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_txt->sy - 1,
				font,
				font_size,
				n_posix_strlen( n_txt_get( n_txt, n_txt->sy - 1 ) )
			);

			caret_to = NonnonMakeCaret
			(
				caret.pxl.x,
				( (CGFloat) n_txt->sy - 1 ) * font_size.height,
				caret.cch.x,
				n_txt->sy - 1
			);

			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}

	}
	break;

	case N_MAC_KEYCODE_UNDO:
	{

		if ( n_txt->readonly ) { break; }


		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{

			[self n_undo:N_TXTBOX_UNDO_RESTORE];

			[self display];

		} else {

			[self n_txtbox_input_method:event];

		}

	}
	break;

	case N_MAC_KEYCODE_FIND:
	{

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			[self.delegate NonnonTxtbox_delegate_find];
		} else {
			[self n_txtbox_input_method:event];
		}

	}
	break;

	case N_MAC_KEYCODE_SAVE:
	{

		if ( n_txt->readonly ) { break; }


		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			//if ( n_txt_save_utf8( n_txt, n_mac_nsstring2str( n_path ) ) )
			{
//NSLog( @"n_txt_save_utf8() failed : %s", n_mac_nsstring2str( path ) );
			}
		} else {
			[self n_txtbox_input_method:event];
		}

	}
	break;

	case N_MAC_KEYCODE_F3:
	{

		n_posix_char *str = n_mac_nsstring2str( n_query );

		[self n_search:str];
		
		n_string_free( str );

	}
	break;

	case N_MAC_KEYCODE_NUMBER_5:
	{

		// [x] : function keys used by system globally

		if ( n_txt->readonly ) { break; }

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			n_posix_char str[ 100 ];

			n_txtbox_date( str, 100 );

			n_txt_add( n_txt, n_focus, str );

			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				n_posix_strlen( n_txt_get( n_txt, n_focus ) )
			);

			[self display];
		} else {
			[self n_txtbox_input_method:event];
		}

	}
	break;

	case N_MAC_KEYCODE_NUMBER_6:
	{

		// [x] : function keys used by system globally

		if ( n_txt->readonly ) { break; }

		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			n_posix_char str[ 100 ];

			n_txtbox_day_of_week( str, 100 );

			n_txt_add( n_txt, n_focus, str );

			n_edited = TRUE;
			[self.delegate NonnonTxtbox_delegate_edited:n_edited];

			caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
			(
				n_txt,
				n_focus,
				font,
				font_size,
				n_posix_strlen( n_txt_get( n_txt, n_focus ) )
			);

			[self display];
		} else {
			[self n_txtbox_input_method:event];
		}

	}
	break;

	default :

		if ( n_txt->readonly ) { break; }


		if ( event.modifierFlags & NSEventModifierFlagCommand )
		{
			//
		} else {
			[self n_txtbox_input_method:event];
		}
	
	break;

	} // switch

}


@end


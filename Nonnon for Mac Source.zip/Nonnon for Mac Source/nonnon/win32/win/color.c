// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_COLOR
#define _H_NONNON_WIN32_WIN_COLOR




COLORREF
n_win_color_blend( COLORREF f, COLORREF t, n_type_real blend )
{

	if ( f == t ) { return t; }

	if ( blend <= 0.0 ) { return f; }
	if ( blend >= 1.0 ) { return t; }


	n_type_real blend_1 = 1.0 - blend;
	n_type_real blend_2 =       blend;


	n_type_real r1 = (n_type_real) GetRValue( f ) * blend_1;
	n_type_real g1 = (n_type_real) GetGValue( f ) * blend_1;
	n_type_real b1 = (n_type_real) GetBValue( f ) * blend_1;
	n_type_real r2 = (n_type_real) GetRValue( t ) * blend_2;
	n_type_real g2 = (n_type_real) GetGValue( t ) * blend_2;
	n_type_real b2 = (n_type_real) GetBValue( t ) * blend_2;
	n_type_real r  = ( r1 + r2 );
	n_type_real g  = ( g1 + g2 );
	n_type_real b  = ( b1 + b2 );


	return RGB( r,g,b );
}

n_posix_bool
n_win_color_is_highcontrast( void )
{

	n_posix_bool ret = n_posix_false;


	if ( n_sysinfo_version_vista_or_later() )
	{

		// [!] : XP or earlier : HCF_HIGHCONTRASTON is not supported

		HIGHCONTRAST hc; ZeroMemory( &hc, sizeof( HIGHCONTRAST ) );
		hc.cbSize = sizeof( HIGHCONTRAST );
		SystemParametersInfo( SPI_GETHIGHCONTRAST, 0, &hc, 0 );

//n_posix_debug_literal( "%d : %s", hc.dwFlags, hc.lpszDefaultScheme );


		ret = ( hc.dwFlags & HCF_HIGHCONTRASTON );

	} else {

		if ( GetSysColor( COLOR_BTNFACE ) == GetSysColor( COLOR_WINDOW ) )
		{
			ret = n_posix_true;
		}

	}


	return ret;
}




#endif // _H_NONNON_WIN32_WIN_COLOR


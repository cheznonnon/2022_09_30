// Nonnon GDI+
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : see @toybox/gdiplus for details


// [ Mechanism ]
//
//
//	[ WM_CREATE and WM_CLOSE ]
//
//	n_gdiplus_init()
//	n_gdiplus_exit()




#ifndef _H_NONNON_WIN32_GAME_GDIPLUS
#define _H_NONNON_WIN32_GAME_GDIPLUS




#include "../win32/sysinfo/version.c"


#include "../neutral/bmp/all.c"




typedef struct {

	HMODULE hmod;
	FARPROC init;
	FARPROC exit;
	FARPROC draw;
	FARPROC fast;

} n_gdiplus;


static n_gdiplus n_gdiplus_instance = { NULL, NULL,NULL,NULL };




#define n_gdiplus_zero( p ) n_memory_zero( p, sizeof( n_gdiplus ) )

#define n_gdiplus_is_on() ( n_gdiplus_instance.hmod != NULL )

void
n_gdiplus_exit( void )
{

	if ( n_gdiplus_instance.exit ) { n_gdiplus_instance.exit(); }
	FreeLibrary( n_gdiplus_instance.hmod );

	n_gdiplus_zero( &n_gdiplus_instance );


	return;
}

void
n_gdiplus_init( void )
{

	n_gdiplus_zero( &n_gdiplus_instance );


	// [!] : Version Checker

	if ( n_posix_false == n_sysinfo_version_xp_or_later() ) { return; }


	n_gdiplus_instance.hmod = LoadLibrary( n_posix_literal( "Nonnon GDIPlus DLL.dll" ) );
	n_gdiplus_instance.init = GetProcAddress( n_gdiplus_instance.hmod, "n_gdiplus_init" );
	n_gdiplus_instance.exit = GetProcAddress( n_gdiplus_instance.hmod, "n_gdiplus_exit" );
	n_gdiplus_instance.draw = GetProcAddress( n_gdiplus_instance.hmod, "n_gdiplus_draw" );
	n_gdiplus_instance.fast = GetProcAddress( n_gdiplus_instance.hmod, "n_gdiplus_draw_fast" );


	n_posix_bool error = n_posix_false;

	if ( n_gdiplus_instance.hmod == NULL ) { error = n_posix_true; }
	if ( n_gdiplus_instance.init == NULL ) { error = n_posix_true; }
	if ( n_gdiplus_instance.exit == NULL ) { error = n_posix_true; }
	if ( n_gdiplus_instance.draw == NULL ) { error = n_posix_true; }
	if ( n_gdiplus_instance.fast == NULL ) { error = n_posix_true; }

	if ( error ) { n_gdiplus_exit(); } else { n_gdiplus_instance.init(); }


	return;
}




void
n_gdiplus_draw( HDC hdc, u32 *ptr, int sx, int sy )
{

	if ( n_gdiplus_instance.draw ) { n_gdiplus_instance.draw( hdc, ptr, sx,sy ); }

	return;
}

void
n_gdiplus_draw_fast( HDC hdc, u32 *ptr, int sx, int sy )
{

	if ( n_gdiplus_instance.fast ) { n_gdiplus_instance.fast( hdc, ptr, sx,sy ); }

	return;
}
/*
void
n_gdiplus_draw( HDC hdc, HBITMAP hbmp, int x, int y )
{

	if ( n_gdiplus_instance.draw ) { n_gdiplus_instance.draw( hdc, hbmp, x,y ); }

	return;
}
*/


#endif // _H_NONNON_WIN32_GAME_GDIPLUS


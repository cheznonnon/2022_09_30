//
//  AppDelegate.m
//  CatPad for Mac
//
//  Created by のんのん on 2022/08/14.
//


#import "AppDelegate.h"


#include "../../nonnon/mac/n_txtbox.c"
#include "../../nonnon/mac/sound.c"
#include "../../nonnon/mac/n_button.c"


#include "catpad_filter.c"




static AVAudioPlayer *player;




@interface AppDelegate : NSObject <NSApplicationDelegate, NonnonTxtbox_delegate>
@end


@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonTxtbox *n_txtbox;

@property (weak) IBOutlet NonnonButton *n_button_top;
@property (weak) IBOutlet NonnonButton *n_button_save;
@property (weak) IBOutlet NonnonButton *n_button_calc;
@property (weak) IBOutlet NonnonButton *n_button_dump;

@property (weak) IBOutlet NonnonTxtbox *n_search;


@property n_txt n_txt_data;
@property n_txt n_txt_search_data;


@end




@implementation AppDelegate {

	BOOL topmost_onoff;
	BOOL   ndump_onoff;

}


@synthesize n_txt_data;
@synthesize n_txt_search_data;




- (instancetype)init
{
	self = [super init];
	if ( self )
	{
		n_txt_zero( &n_txt_data );

		n_txt_data.unicode = N_TXT_UNICODE_UTF8_NO_BOM;
		n_txt_data.newline = N_TXT_NEWLINE_LF;

		n_txt_utf8_new( &n_txt_data );

		n_txt_zero( &n_txt_search_data );
		n_txt_utf8_new( &n_txt_search_data );
	}
	
	return self;
}




- (void) NonnonCatPadSettings : (BOOL) is_read
{

	NSString *nsstr;

	if ( is_read )
	{

		nsstr = n_mac_settings_read( @"find" );
		if ( nsstr.length == 0 ) { nsstr = [NSString stringWithFormat:@""]; }

		n_posix_char *str = n_mac_nsstring2str( nsstr );

		n_txt_set( _n_search.n_txt_data, 0, str );

		[_n_search n_caret_tail_set];

		n_string_free( str );

	} else {

		nsstr = [NSString stringWithFormat:@"%s", n_txt_get( _n_search.n_txt_data, 0 )];
		n_mac_settings_write( @"find", nsstr );

	}

}




- (void) n_neko_alternation:(BOOL) onoff
{

	n_bmp bmp_icon; n_bmp_zero( &bmp_icon );

	if ( onoff )
	{
		n_mac_image_rc_load_bmp( @"neko", &bmp_icon );
	} else {
		n_mac_image_rc_load_bmp( @"neko_sleeping", &bmp_icon );
	}

	[_n_button_save n_icon_set:&bmp_icon];
	[_n_button_save n_enable:onoff];

}

- (void) n_catpad_title
{
	NSString *nsstr = [NSString stringWithFormat:@"%@ - CatPad for Mac", _n_txtbox.n_path];
	[_window setTitle:nsstr];
}




- (void)awakeFromNib
{

	{
		n_bmp bmp_icon; n_bmp_zero( &bmp_icon );
		n_mac_image_rc_load_bmp( @"top", &bmp_icon );
		n_mac_button_system_themed( &bmp_icon );

		[_n_button_top n_icon_set:&bmp_icon];
		[_n_button_top n_enable:TRUE];

		_n_button_top.delegate = self;

		topmost_onoff = FALSE;
	}

	{
		[self n_neko_alternation:FALSE];

		_n_button_save.delegate = self;
	}

	{
		n_bmp bmp_icon; n_bmp_zero( &bmp_icon );
		n_mac_image_rc_load_bmp( @"calc_nonnon", &bmp_icon );
		n_mac_button_system_themed( &bmp_icon );

		[_n_button_calc n_icon_set:&bmp_icon];
		[_n_button_calc n_enable:TRUE];
		
		_n_button_calc.delegate = self;
	}

	{
		n_bmp bmp_icon; n_bmp_zero( &bmp_icon );
		n_mac_image_rc_load_bmp( @"ndump", &bmp_icon );
		n_mac_button_system_themed( &bmp_icon );

		[_n_button_dump n_icon_set:&bmp_icon];
		[_n_button_dump n_enable:FALSE];
		
		_n_button_dump.delegate = self;

		ndump_onoff = FALSE;
	}


	_n_txtbox.delegate            = self;
	_n_txtbox.n_txt_data          = &n_txt_data;
	_n_txtbox.n_mode              = N_MAC_TXTBOX_MODE_EDITBOX;
	_n_txtbox.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;

	[[_n_txtbox window] makeFirstResponder:_n_txtbox];

	[_n_txtbox n_reset];


	_n_search.delegate            = self;
	_n_search.n_txt_data          = &n_txt_search_data;
	_n_search.n_mode              = N_MAC_TXTBOX_MODE_ONELINE;
	_n_search.n_focus             = 0;
	_n_search.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_NONE;

	NSFont *font = [NSFont systemFontOfSize:15 weight:NSFontWeightRegular];

	[_n_search n_font_change:font];

	{
		n_bmp bmp; n_bmp_zero( &bmp );
		n_mac_image_rc_load_bmp( @"search_64", &bmp );
		n_posix_loop
		{
			if ( _n_search.frame.size.height >= N_BMP_SY( &bmp ) ) { break; }
	
			n_bmp_flush_antialias( &bmp, 1.0 );
			n_bmp_scaler_lil     ( &bmp, 2   );
		}

		n_bmp_flush_mirror( &bmp, N_BMP_MIRROR_UPSIDE_DOWN );

		_n_search.n_oneline_bmp_icon = n_mac_image_nbmp2nsimage( &bmp );

		n_bmp_free_fast( &bmp );
	}

	[_n_search n_reset];

	[self NonnonCatPadSettings:YES];


	[[_n_txtbox window] makeFirstResponder:nil];


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}



- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog(@"mouseUp");

//NSLog( @"mouseUp : %@", _n_txtbox.n_path );

	if ( n_mac_window_is_hovered( _n_button_top ) )
	{
//NSLog(@"mouseUp");

		if ( topmost_onoff )
		{
			topmost_onoff = FALSE;
		} else {
			topmost_onoff = TRUE;
		}

		n_mac_topmost( _window, topmost_onoff );

		[_n_button_top n_press:topmost_onoff];
		[_n_button_top display];

	} else
	if ( n_mac_window_is_hovered( _n_button_save ) )
	{

		n_posix_char *fname = n_mac_nsstring2str( _n_txtbox.n_path );

		if ( n_txt_save_utf8( &n_txt_data, fname ) )
		{
//NSLog( @"not saved" );
			// [!] : error

			// [x] : crash without "App Sandbox" "User Selected File"

			NSString *name = [_n_txtbox.n_path lastPathComponent];

			NSSavePanel *panel = [NSSavePanel savePanel];
   			[panel setNameFieldStringValue:name];
			[panel beginSheetModalForWindow:_window completionHandler:^(NSInteger result)
			{
				if ( result == NSModalResponseOK )
				{
					NSString     *nsstring = [[panel URL] path];
					n_posix_char *str      = n_mac_nsstring2str( nsstring );

					n_posix_bool ret = n_txt_save_utf8( &self->n_txt_data, str );
					if ( ret == n_posix_false )
					{
						self->_n_txtbox.n_path = nsstring;
	
						player = n_mac_sound_wav_init( @"Cat Meow" );
						n_mac_sound_play( player );

						[self n_catpad_title];
					}

					self->n_txt_data.readonly = FALSE;

					n_string_free( str );

					[self n_neko_alternation:FALSE];
					[self->_n_button_save display];

					[self->_n_button_dump n_enable:TRUE];
					[self->_n_button_dump display];
				}

			}];

		} else {

			[self n_neko_alternation:FALSE];
			[_n_button_save display];

			[_n_button_dump n_enable:TRUE];
			[_n_button_dump display];
	
			player = n_mac_sound_wav_init( @"Cat Meow" );
			n_mac_sound_play( player );

			[self n_catpad_title];

		}

		n_string_free( fname );

	} else
	if ( n_mac_window_is_hovered( _n_button_calc ) )
	{

		NSArray *args = [NSArray arrayWithObjects:@"-a", @"Calculator", nil];
		NSTask  *task = [NSTask new];
		[task setLaunchPath:@"/usr/bin/open"];
		[task setArguments:args];

		[task launch];

	} else
	if ( n_mac_window_is_hovered( _n_button_dump ) )
	{

		if ( [_n_button_save n_is_enabled] ) { return; }

		if ( ndump_onoff )
		{
			ndump_onoff = FALSE;

			[_n_button_dump n_press:ndump_onoff];
			[_n_button_dump display];

			n_posix_char *str = n_mac_nsstring2str( _n_txtbox.n_path );

			n_txt_load_utf8( &n_txt_data, str );

			[_n_txtbox n_reset];
			[_n_txtbox n_undo:N_TXTBOX_UNDO_RESET];

			n_string_free( str );

			n_txt_data.readonly = n_posix_false;

			[_n_txtbox display];
		} else {
			ndump_onoff = TRUE;

			[_n_button_dump n_press:ndump_onoff];
			[_n_button_dump display];

			n_catpad_ntxt_dump( &n_txt_data, n_mac_nsstring2str( _n_txtbox.n_path ) );

			n_txt_data.readonly = n_posix_true;

			[_n_txtbox display];
		}

	}

}

- (void) rightMouseUp:(NSEvent*) theEvent
{
//NSLog(@"rightMouseUp");
}




- (void) NonnonTxtbox_delegate_dropped
{

	ndump_onoff = FALSE;

	[_n_button_dump n_enable:TRUE];
	[_n_button_dump display];

	n_txt_data.readonly = n_posix_false;


	[self n_catpad_title];

}

- (void) NonnonTxtbox_delegate_edited:(NonnonTxtbox*)txtbox onoff:(BOOL)onoff
{

	if ( txtbox == _n_txtbox )
	{

		[self n_neko_alternation:onoff];
		[_n_button_save display];


		ndump_onoff = FALSE;

		[_n_button_dump n_enable:ndump_onoff];
		[_n_button_dump display];

	} else {

		if ( _n_search.n_is_enter_pressed )
		{
			[self NonnonCatPadSettings:NO];

			n_posix_char *str = n_txt_get( _n_search.n_txt_data, 0 );
			[_n_txtbox n_search:str];
		}

	}

}

- (void) NonnonTxtbox_delegate_find:(NonnonTxtbox*)txtbox
{
//NSLog( @"NonnonTxtbox_delegate_find" );

	// [!] : Ctrl + F

	if ( txtbox == _n_txtbox )
	{
		[[_n_search window] makeFirstResponder:_n_search];
	} else {
		[[_n_txtbox window] makeFirstResponder:_n_txtbox];
	}

}

- (void) NonnonTxtbox_delegate_F3:(NonnonTxtbox*)txtbox
{
//NSLog( @"NonnonTxtbox_delegate_F3" );

	n_posix_char *str = n_txt_get( _n_search.n_txt_data, 0 );

	[_n_txtbox n_search:str];

	[self NonnonCatPadSettings:NO];

}




- (IBAction)n_info:(id)sender
{

	n_posix_char *unicode = n_posix_literal( "Unknown Format" );

	if ( n_txt_data.unicode == N_TXT_UNICODE_UTF8_NO_BOM )
	{
		unicode = n_posix_literal( "UTF-8 without BOM" );
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_UTF )
	{
		unicode = n_posix_literal( "UTF-8 with BOM" );
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_LIL )
	{
		unicode = n_posix_literal( "Unicode Little Endian" );
	} else
	if ( n_txt_data.unicode == N_TXT_UNICODE_BIG )
	{
		unicode = n_posix_literal( "Unicode Big Endian" );
	}


	n_posix_char *newline = n_posix_literal( "Binary" );

	if ( n_txt_data.newline == N_TXT_NEWLINE_CRLF )
	{
		newline = n_posix_literal( "CRLF" );
	} else
	if ( n_txt_data.newline == N_TXT_NEWLINE_CR )
	{
		newline = n_posix_literal( "CR" );
	} else
	if ( n_txt_data.newline == N_TXT_NEWLINE_LF )
	{
		newline = n_posix_literal( "LF" );
	}


	n_posix_char *pth = n_mac_nsstring2str( _n_txtbox.n_path );
	n_type_int    cch = n_posix_strlen( pth ) + 1024;
	n_posix_char *str = n_string_new( cch );

	n_posix_sprintf_literal( str, "%s\n\n%s (%s)", pth, unicode, newline );

	n_mac_window_dialog_ok( str );

	n_string_free( str );
	n_string_free( pth );

}




@end
